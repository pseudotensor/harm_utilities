public class FlopInfo {
  public float real_time;
  public float proc_time;
  public long flpops;
  public float mflops;
}
