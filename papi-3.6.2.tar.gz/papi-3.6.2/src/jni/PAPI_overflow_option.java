public class PAPI_overflow_option {
  public int type;

  public PAPI_overflow_option() {
    // do nothing
  }

  public PAPI_overflow_option(int t) {
    type=t;
  }
}
