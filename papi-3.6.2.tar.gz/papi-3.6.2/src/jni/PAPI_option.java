public class PAPI_option {
  PAPI_preload_info preload;
  PAPI_debug_option debug;
  PAPI_inherit_option inherit;
  PAPI_granularity_option granularity; 
  PAPI_granularity_option defgranularity; 
  PAPI_domain_option domain; 
  PAPI_domain_option defdomain; 
  PAPI_multiplex_option multiplex;
  PAPI_hw_info hw_info;
  PAPI_shlib_info shlib_info;
  PAPI_exe_info exe_info;
  PAPI_overflow_option ovf_info;
  PAPI_substrate_info sub_info;
}
