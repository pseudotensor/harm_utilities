public class FlipInfo {
  public float real_time;
  public float proc_time;
  public long flpins;
  public float mflips;
}
