/* 
* File:    overflow_single_event.c
* CVS:     $Id: overflow_force_software.c,v 1.17 2008-07-11 04:15:49 mucci Exp $
* Author:  Kevin London
*          london@cs.utk.edu
* Mods:    Maynard Johnson
*          maynardj@us.ibm.com
*          Philip Mucci
*	   mucci@cs.utk.edu
*	   <your name here>
*          <your email address>
*/

/* This file performs the following test: overflow dispatch of an eventset
   with just a single event. Using both Hardware and software overflows

     The Eventset contains:
     + PAPI_FP_INS (overflow monitor)

   - Start eventset 1
   - Do flops
   - Stop and measure eventset 1
   - Set up overflow on eventset 1
   - Start eventset 1
   - Do flops
   - Stop eventset 1
   - Set up forced software overflow on eventset 1
   - Start eventset 1
   - Do flops
   - Stop eventset 1
*/

#include "papi_test.h"

#ifdef _CRAYT3E
#define OVER_FMT	"handler(%d) Overflow at %x! overflow_vector=0x%x!\n"
#define OUT_FMT		"%-12s : %16lld%16d%16lld\n"
#elif defined(_WIN32)
#define OVER_FMT	"handler(%d) Overflow at %p! overflow_vector=0x%x!\n"
#define OUT_FMT		"%-12s : %16I64d%16d%16I64d\n"
#else
#define OVER_FMT	"handler(%d) Overflow at %p overflow_vector=0x%llx!\n"
#define OUT_FMT		"%-12s : %16lld%16d%16lld\n"
#endif

#define HARD_TOLERANCE 0.25
#define SOFT_TOLERANCE 0.90
#define MY_NUM_TESTS 5

static int total[MY_NUM_TESTS] = {0,};                  /* total overflows */
static int use_total=0;                                 /* which total field to bump */
static long_long values[MY_NUM_TESTS] = { 0,};
   
void handler(int EventSet, void *address, long_long overflow_vector, void *context)
{
   if (!TESTS_QUIET) {
      fprintf(stderr, OVER_FMT, EventSet, address, overflow_vector);
   }

   total[use_total]++;
}

int main(int argc, char **argv)
{
   int EventSet=PAPI_NULL;
   long_long hard_min, hard_max, soft_min, soft_max;
   int retval;
   int PAPI_event=0, mythreshold=THRESHOLD;
   char event_name[PAPI_MAX_STR_LEN];
   PAPI_option_t  opt;
   PAPI_event_info_t info;
   PAPI_option_t itimer; 

   tests_quiet(argc, argv);     /* Set TESTS_QUIET variable */

   retval = PAPI_library_init(PAPI_VER_CURRENT);
   if (retval != PAPI_VER_CURRENT)
      test_fail(__FILE__, __LINE__, "PAPI_library_init", retval);

   retval = PAPI_get_opt(PAPI_SUBSTRATEINFO, &opt);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_get_opt(PAPI_SUBSTRATEINFO)", retval);

   /* query and set up the right instruction to monitor */
  if (PAPI_query_event(PAPI_FP_INS) == PAPI_OK) {
     if (PAPI_query_event(PAPI_FP_INS) == PAPI_OK) {
        PAPI_get_event_info(PAPI_FP_INS, &info);
        if ( info.count == 1 || !strcmp(info.derived, "DERIVED_CMPD"))
           PAPI_event = PAPI_FP_INS;
     }
  } 
  if ( PAPI_event == 0 ) {
     if (PAPI_query_event(PAPI_FP_OPS) == PAPI_OK) {
        PAPI_get_event_info(PAPI_FP_OPS, &info);
        if ( info.count == 1 || !strcmp(info.derived, "DERIVED_CMPD"))
           PAPI_event = PAPI_FP_OPS;
     }
  }
  if ( PAPI_event == 0 ) {
     if (PAPI_query_event(PAPI_TOT_INS) == PAPI_OK) {
        PAPI_get_event_info(PAPI_TOT_INS, &info);
        if ( info.count == 1 || !strcmp(info.derived, "DERIVED_CMPD"))
           PAPI_event = PAPI_TOT_INS;
     }	
  }

   if ( PAPI_event == 0 )
      test_fail(__FILE__, __LINE__, "No suitable event for this test found!", 0);
   
   retval = PAPI_create_eventset(&EventSet);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_create_eventset", retval);

   retval = PAPI_add_event(EventSet, PAPI_event);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_add_event", retval);

   do_stuff();

   /* Do reference count */

   retval = PAPI_start(EventSet);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_start", retval);

   do_stuff();

   retval = PAPI_stop(EventSet, &values[use_total]);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_stop", retval);
   use_total++;

   /* Now do hardware overflow reference count */

   retval = PAPI_overflow(EventSet, PAPI_event, mythreshold, 0, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

   retval = PAPI_start(EventSet);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_start", retval);

   do_stuff();

   retval = PAPI_stop(EventSet, &values[use_total]);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_stop", retval);
   use_total++;

   retval = PAPI_overflow(EventSet, PAPI_event, 0, 0, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

   /* Now do software overflow reference count, uses SIGPROF */
   
   retval = PAPI_overflow(EventSet, PAPI_event, mythreshold, PAPI_OVERFLOW_FORCE_SW, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

   retval = PAPI_start(EventSet);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_start", retval);

   do_stuff();

   retval = PAPI_stop(EventSet, &values[use_total]);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_stop", retval);
   use_total++;

   retval = PAPI_overflow(EventSet, PAPI_event, 0, PAPI_OVERFLOW_FORCE_SW, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

  /* Now do software overflow with SIGVTALRM */

   memset(&itimer,0,sizeof(itimer));
   itimer.itimer.itimer_num = ITIMER_VIRTUAL; 
   itimer.itimer.itimer_sig = SIGVTALRM; 

   if (PAPI_set_opt(PAPI_DEF_ITIMER,&itimer) != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_set_opt", retval);
 
   retval = PAPI_overflow(EventSet, PAPI_event, mythreshold, PAPI_OVERFLOW_FORCE_SW, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

   retval = PAPI_start(EventSet);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_start", retval);

   do_stuff();

   retval = PAPI_stop(EventSet, &values[use_total]);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_stop", retval);
   use_total++;

   retval = PAPI_overflow(EventSet, PAPI_event, 0, PAPI_OVERFLOW_FORCE_SW, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

   /* Now do software overflow with SIGALRM */
   
   memset(&itimer,0,sizeof(itimer));
   itimer.itimer.itimer_num = ITIMER_REAL; 
   itimer.itimer.itimer_sig = SIGALRM; 
   if (PAPI_set_opt(PAPI_DEF_ITIMER,&itimer) != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_set_opt", retval);
 
   retval = PAPI_overflow(EventSet, PAPI_event, mythreshold, PAPI_OVERFLOW_FORCE_SW, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

   retval = PAPI_start(EventSet);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_start", retval);

   do_stuff();

   retval = PAPI_stop(EventSet, &values[use_total]);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_stop", retval);
   use_total++;

   retval = PAPI_overflow(EventSet, PAPI_event, 0, PAPI_OVERFLOW_FORCE_SW, handler);
   if (retval != PAPI_OK)
      test_fail(__FILE__, __LINE__, "PAPI_overflow", retval);

   if (!TESTS_QUIET) {
      if ((retval = PAPI_event_code_to_name(PAPI_event, event_name)) != PAPI_OK)
         test_fail(__FILE__, __LINE__, "PAPI_event_code_to_name", retval);

      printf("Test case: Software overflow of various types with 1 event in set.\n");
      printf("-----------------------------------------------\n");
      printf("Threshold for overflow is: %d\n", mythreshold);
      printf("-----------------------------------------------\n");

      printf("Test type    : %16s%16s%16s%16s%16s\n", "Reference", "Hardware", "ITIMER_PROF", "ITIMER_VIRTUAL", "ITIMER_REAL");
      printf("%-13s: %16lld%16lld%16lld%16lld%16lld\n",info.symbol,values[0],values[1],values[2],values[3],values[4]);
      printf("Overflows    : %16d%16d%16d%16d%16d\n", total[0],total[1],total[2],total[3],total[4]);
      printf("-----------------------------------------------\n");

      printf("Verification:\n");
     
      printf("Overflow in Column 2 greater than or equal to overflows in column 3\n");
      printf("Overflow in Column 3 greater than 0\n");
   }

   hard_min = (long_long) ((values[0] * (1.0 - HARD_TOLERANCE)) / (long_long) mythreshold);
   hard_max = (long_long) ((values[0] * (1.0 + HARD_TOLERANCE)) / (long_long) mythreshold);
   soft_min = (long_long) ((values[0] * (1.0 - SOFT_TOLERANCE)) / (long_long) mythreshold);
   soft_max = (long_long) ((values[0] * (1.0)) / (long_long) mythreshold);
   if (total[1] > hard_max || total[1] < hard_min)
      test_fail(__FILE__, __LINE__, "Hardware Overflows", 1);

   if (total[2] > soft_max || total[2] < soft_min)
      test_fail(__FILE__, __LINE__, "Software Overflows", 1);

   test_pass(__FILE__, NULL, 0);
   exit(1);
}
