#include "papi.h"
#include "papi_internal.h"
#include "papi_vector.h"
#include "papi_memory.h"
#include "papi_protos.h"

/* Dummy *
 *
 * Should put Irix code not tied to a processor here *if it becomes an issue
 */

