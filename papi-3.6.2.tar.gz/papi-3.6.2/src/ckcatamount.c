#ifdef __LIBCATAMOUNT__
  #error IS_CATAMOUNT
#else
  #error NOT_CATAMOUNT
#endif

