#include <stdio.h>
#include <link.h>
int main(int argc, char **argv)
{
	printf("_r_debug=%p\n", _r_debug);
	printf("_r_debug.rbrk=%p\n", _r_debug.r_brk);
	return 0;
}

