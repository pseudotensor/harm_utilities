/*
 * pfmon_symbols.c  - management of symbol tables
 *
 * Copyright (c) 2002-2006 Hewlett-Packard Development Company, L.P.
 * Contributed by Stephane Eranian <eranian@hpl.hp.com>
 * Parts contributed by Andrzej Nowak (CERN)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 * 02111-1307 USA
 *
 *                   module_map_list_t
 *                  -------------------
 * sdesc ->syms -->|               map |--\
 *                  -------------------   |
 *                                        |
 *          module_map_t                  |
 *       ----------------- <--------------/
 *      |            mod  |
 *      |             pid |
 *       -----------------        module_symbols_t
 *      |            mod  |-->  --------------------        symbol_t
 *      |            pid  |    |        sym_tab[0]  | -->  ---------- 
 *       -----------------     |        sym_tab[1]  |     |    name  |--> foo
 *      |           NULL  |    |          nsyms[0]  |     |   value  |
 *      |             -1  |    |          nsyms[1]  |      ----------
 *       -----------------      --------------------      |    name  |--> bar
 *                                                        |   value  |
 *                                                         ----------
 *
 * module_map_list_t is shared between threads of the same process
 * sym_tab[0] = text symbols
 * sym_tab[1] = data symbols
 * nsyms[0] = number of text symbols
 * nsyms[1] = number of data symbols
 */
#include <ctype.h>
#include <fcntl.h>
#include <libelf.h>

#include "pfmon.h"

#define PFMON_KALLSYMS		"/proc/kallsyms"

#define PFMON_NM_CMD    "sh -c \"nm -f sysv -v -C --defined -D %s 2>/dev/null; nm -a -f sysv -v -C --defined %s 2>/dev/null\" | sort -t'|' -k 2 | uniq"
#define NTOK 8

#define KERNEL_MOD_ID	(~0UL)

static module_symbols_t *module_list;
static pthread_mutex_t  module_list_lock = PTHREAD_MUTEX_INITIALIZER;

void
show_module_syms(void)
{
	module_symbols_t *p;
	
	pthread_mutex_lock(&module_list_lock);
	for(p = module_list; p ; p = p ->next)
		printf("%lu %"PRIu64" %s\n", p->refcnt, p->id, p->name);
	pthread_mutex_unlock(&module_list_lock);
}

/*
 * find module_symbol by id
 * caller must have module_list_lock held
 *
 * by having caller control lock, we make it possible to
 * atomically find and add new module_symbols
 */
static module_symbols_t *
find_module_syms(uint64_t id)
{
	module_symbols_t *p;
	
	for(p = module_list; p ; p = p ->next) {
		if (p->id == id) {
			p->refcnt++;
			break;
		}
	}
	return p;
}

/*
 * add module_symbol p to module list
 * caller must have module_list_lock held
 */
static void
add_module_syms(module_symbols_t *p)
{
	DPRINT(("module added %s\n", p->name));

	if (module_list)
		module_list->prev = p;

	p->next = module_list;
	p->prev = NULL;

	module_list = p;
}

/*
 * pseudo module_symbols have no filesystem backing. They cover in-memory
 * only sections of the address space such as stack, vdso, vsyscalls, head.
 * Note that unnamed sections of the address space are not covered
 *
 * In multi-threaded processes, pseudo symbols are shared except for stacks.
 *
 */
static module_symbols_t *
create_pseudo_module_syms(pfmon_sdesc_t *sdesc, char *name, int type, module_map_t *map)
{
	module_symbols_t *mod;

	mod = calloc(1, sizeof(module_symbols_t));
	if (!mod)
		return NULL;

	mod->sym_tab[type] = calloc(1, sizeof(symbol_t));
	if (!mod->sym_tab[type]) {
		free(mod);
		return NULL;
	}
	mod->id = 0; /* pseudo id */
	mod->name = strdup(sdesc->cmd);
	mod->refcnt = 1;

	mod->sym_tab[type][0].value = map->base[type];
	mod->sym_tab[type][0].size = map->max[type] - map->base[type];
	mod->sym_tab[type][0].name = strdup(name);
	mod->nsyms[type] = 1;

	return mod;
}

static int
symcmp(const void *a, const void *b)
{
	symbol_t *ap = (symbol_t *)a;
	symbol_t *bp = (symbol_t *)b;

	return ap->value > bp->value;
}

static inline int is_text(char *s)
{
	return !strncmp(s, ".text", 5)
	    || !strncmp(s, ".init", 5)
	    || !strncmp(s, ".fini", 5)
	    || !strncmp(s, ".plt", 4); /* program linkage table */
}

static inline int is_data(char *s)
{
	return !strncmp(s, ".bss", 4)
	    || strstr(s, "data")
	    || !strncmp(s, ".dynamic", 8);
}

/*
 * add kernel module_map in p for sdesc
 */
static int
add_kernel_module_map(pfmon_sdesc_t *sdesc, unsigned int version, module_map_t *p)
{
	module_symbols_t *mod;

	mod = find_module_syms(KERNEL_MOD_ID);
	if (!mod)
		return -1;

	DPRINT(("[%d] ADD KERNEL refcnt=%lu\n", sdesc->tid, mod->refcnt));

	/* add kernel to map */
	p->mod = mod;
	p->path = strdup("kernel");
	p->version = version;
	p->pid = sdesc->pid;

	p->base[0] = 0; /* kernel addresses are absolute */
	p->base[1] = 0; /* kernel addresses are absolute */

	if (mod->nsyms[0])
		p->max[0]  = mod->sym_tab[0][mod->nsyms[0]-1].value
			+ mod->sym_tab[0][mod->nsyms[0]-1].size;
	else
		p->max[0] = 0;

	if (mod->nsyms[1])
		p->max[1]  = mod->sym_tab[1][mod->nsyms[1]-1].value
			+ mod->sym_tab[0][mod->nsyms[1]-1].size;
	else
		p->max[1] = 0;

	p->min[0]  = mod->sym_tab[0][0].value;
	p->min[1]  = mod->sym_tab[1][0].value;

	return 0;
}

/*
 * load symbols from image file using nm
 */
static int
load_module_syms(const char *filename, module_symbols_t *mod)
{
	FILE *fp;
	int stype;
	size_t max_syms[2];
	char *buf, *line, *saved_line, *p, *q;
	char *nm_toks[NTOK];
	size_t sz, ssz;
	unsigned long i;
	uint64_t addr;
        int breakflag;
        int64_t index = 0;

	buf = malloc(2*strlen(filename) + strlen(PFMON_NM_CMD)+1);
	if (!buf)
		return -1;

	sprintf(buf, PFMON_NM_CMD, filename, filename);

	fp = popen(buf, "r");
	free(buf);
	if (!fp)
		return -1;

	max_syms[0] = max_syms[1] = 2048;
	line = NULL, sz = 0; saved_line = NULL;
	while (getline(&line, &sz, fp) != EOF) {
		p = q = line; i = 0;
		nm_toks[6] = NULL;
		while(i < NTOK && (p = strtok_r(q, "|", &saved_line))) {
			if (*p == '\n' || *p == '\0')
				break;
			nm_toks[i++] = p;
			q = NULL;
		}
		if (!nm_toks[6])
			continue;

		/*
		 * XXX: missing ctors/dtros init/fini
		 */

		if (is_text(nm_toks[6])) {
			stype = 0;
		} else if (is_data(nm_toks[6])) {
			stype = 1;
		}
		else
			continue;

		addr = strtoull(nm_toks[1], NULL, 16);
		ssz = strtoul(nm_toks[4], NULL, 16);

		if (mod->nsyms[stype] == 0 || mod->nsyms[stype] == max_syms[stype]) {
			/* exponential growth */
			max_syms[stype] <<=1;
			mod->sym_tab[stype] = realloc(mod->sym_tab[stype], max_syms[stype] * sizeof(symbol_t));
			if (mod->sym_tab[stype] == NULL)
				goto error;
		}

                p = strchr(nm_toks[0], '|');
                if (p)
                        *p = '\0';

                for(i=strlen(nm_toks[0]); nm_toks[0][i-1] == ' '; i--);
                nm_toks[0][i] = '\0';

                breakflag = 0;
                index = (int64_t)mod->nsyms[stype] - 1;
                if((index >= 0) && (mod->sym_tab[stype][index].value == addr)) {
                        //DPRINT(("addrs match %s/%"PRIx64"\n", mod->sym_tab[stype][index].name, mod->sym_tab[stype][index].value));
                        if(strncmp(mod->sym_tab[stype][index].name, "_Z", 2)) {
                                //DPRINT(("skipping %s/%"PRIx64" because %s/%"PRIx64" already inside\n", nm_toks[0], addr, mod->sym_tab[stype][index].name, mod->sym_tab[stype][index].value));
                                breakflag = 1;
                        }
                }

		if(breakflag == 1) continue;

		mod->sym_tab[stype][mod->nsyms[stype]].name  = strdup(nm_toks[0]);
		mod->sym_tab[stype][mod->nsyms[stype]].value = addr;
		mod->sym_tab[stype][mod->nsyms[stype]].size  = ssz;
		mod->nsyms[stype]++;
	}

	if (line)
		free(line);

	fclose(fp);

	if (mod->nsyms[0] || mod->nsyms[1]) {
		qsort(mod->sym_tab[0], mod->nsyms[0], sizeof(symbol_t), symcmp);
		for(i=1; i < mod->nsyms[0]; i++) {
			size_t sss;
			sss  = mod->sym_tab[0][i].value - mod->sym_tab[0][i-1].value;
			if (mod->sym_tab[0][i-1].size == 0 || (sss < mod->sym_tab[0][i-1].size))
				mod->sym_tab[0][i-1].size  = sss;
		}

		qsort(mod->sym_tab[1], mod->nsyms[1], sizeof(symbol_t), symcmp);
		for(i=1; i < mod->nsyms[1]; i++) {
			size_t sss;
			sss  = mod->sym_tab[1][i].value - mod->sym_tab[1][i-1].value;
			if (mod->sym_tab[1][i-1].size == 0 || (sss < mod->sym_tab[1][i-1].size))
				mod->sym_tab[1][i-1].size  = sss;
		}
	}
	return 0;
error:
	return -1;
}

/*
 * load kernel symbols using /proc/kallsyms.
 * This file does not contains kernel data symbols but includes code/data
 * symbols from modules. Code symbol size is not provided.
 */
static int
load_kallsyms_symbols(module_symbols_t *mod)
{
	FILE *fp;
	uint64_t min_addr[2];
	char *s, *str_addr, *sym_start, *mod_start, *endptr;
	uint64_t sym_len, mod_len;
	uint64_t line = 1UL;
	uint64_t addr;
	uint64_t last_value[2];
	uint64_t sym_count[2];
	int need_sorting[2];
	size_t sz;
	char *line_str;
	char addr_str[24]; /* cannot be more than 16+2 (for 0x) */
	int type, ret;

	fp = fopen(PFMON_KALLSYMS, "r");
	if (fp == NULL) {
		DPRINT(("file %s not found\n", PFMON_KALLSYMS));
		return -1;
	}

	/*
	 * allocate a default-sized symbol table 
	 */
	sym_count[0] = sym_count[1] = 8192;
	mod->nsyms[0] = mod->nsyms[1] = 0;
	mod->sym_tab[0] = mod->sym_tab[1] = NULL;
	min_addr[0] = min_addr[1] = 0;
	need_sorting[0] = need_sorting[1] = 0;

	line_str = NULL; sz = 0;
	ret = 0;
	while(getline(&line_str, &sz, fp)>0) {

		s = line_str;

		while(*s != ' ' && *s !='\0')
			s++;

		if (*s == '\0')
			break;

		if (s-line_str > 16+2) {
			ret = -1;
			break;
		}

		strncpy(addr_str, line_str, s-line_str);
		addr_str[s-line_str] = '\0';

		/* point to object type */
		s++;
		type = tolower(*s);

		/* 
		 * keep only text and data symbols
		 *
		 * skip uninteresting symbols
		 */
		if (type == 's' || type == 'd' || type == 'D') 
			type = 1;
		else if (type == 't' || type == 'T' )
			type = 0;
		else
			continue;

		/* look for space separator */
		s++;
		if (*s != ' ') {
			ret = -1;
			break;
		}

		if (mod->nsyms[type] == 0 || mod->nsyms[type] == sym_count[type]) {
			/* exponential growth */
			sym_count[type] <<=1;
			mod->sym_tab[type] = (symbol_t *)realloc(mod->sym_tab[type], sym_count[type]*sizeof(symbol_t));
			if (!mod->sym_tab) {
				ret = -1;
				break;
			}
		}

		/* compute address */
		endptr = NULL;
		addr  = strtoull(addr_str, &endptr, 16);
		if (*endptr != '\0') {
			ret = -1;
			break;
		}
		/* skip aliased symbols */
		if (mod->nsyms[type] && addr == mod->sym_tab[type][mod->nsyms[type]-1].value) {
			while (*s++ != '\n');
			line++;
			continue;
		}
			
		/*
		 * check that file is sorted correctly
		 */
		if (mod->nsyms[type] == 0) 
			min_addr[type] = addr;


		if (addr < min_addr[type]) 
			need_sorting[type] = 1;

		min_addr[type] = addr;

		/* advance to symbol name */
		sym_start = ++s;

		/* look for end-of-string */
		while(*s != '\n' && *s != '\0' && *s != ' ' && *s != '\t')
			s++;

		if (*s == '\0') {
			ret = -1;
			break;
		}
		sym_len = s - sym_start;


		/* check for module */
		while(*s != '\n' && *s != '\0' && *s != '[')
			s++;

		/* symbol belongs to a kernel module */
		if (*s == '[') {
			mod_start = s++;
			while(*s != '\n' && *s != '\0' && *s != ']')
				s++;
			if (*s != ']') {
				ret = -1;
				break;
			}
			mod_len = s - mod_start + 1;
		} else {
			mod_len   = 0;
			mod_start = NULL;
		}

		line++;

		/*
		 * place string in our memory pool
		 * +1 for '\0'
		 */
		//str_addr = place_str(mod_len + sym_len + 1);
		str_addr = malloc(mod_len + sym_len + 1);
		if (str_addr == NULL) {
			ret = -1;
			break;
		}

		strncpy(str_addr, sym_start, sym_len);
		if (mod_len)
			strncpy(str_addr+sym_len, mod_start, mod_len);
		str_addr[sym_len+mod_len] = '\0';

		/*
		 * update size of previous symbol using current (estimate)
		 * unfortunately, /proc/kallsyms does not report the size of the symbols
		 * so we try to approximate uby assuming that symbols are contiguous. If there
		 * is a gap between two symbols, then it is likely that no executable code libves
		 * there, so there should be no risk of getting samples there.
		 */
		mod->sym_tab[type][mod->nsyms[type]].value = addr;
    		mod->sym_tab[type][mod->nsyms[type]].size  = 0;
    		mod->sym_tab[type][mod->nsyms[type]].name  = str_addr;
		if (mod->nsyms[type])
    			mod->sym_tab[type][mod->nsyms[type]-1].size  = mod->sym_tab[type][mod->nsyms[type]].value - last_value[type];

		last_value[type] = mod->sym_tab[type][mod->nsyms[type]].value;
		mod->nsyms[type]++;
	}
	if (line_str)
		free(line_str);

	/*
	 * normally a kallsyms is already sorted
	 * so we should not have to do this
	 */
	if (ret == 0) {
		if (need_sorting[0])
			qsort(mod->sym_tab[0], mod->nsyms[0], sizeof(symbol_t), symcmp);
		if (need_sorting[1])
			qsort(mod->sym_tab[1], mod->nsyms[1], sizeof(symbol_t), symcmp);
	}
	fclose(fp);

	return ret;
}

int
load_kernel_syms(void)
{
	module_symbols_t *mod;
	char *from;
	int ret;

	/*
 	 * don't bother if not use --resolv
 	 * it is not possible to set triggers
 	 * in the kernel anyway
 	 */
	if (!options.opt_addr2sym)
		return 0;

	mod = calloc(1, sizeof(module_symbols_t));
	if (!mod)
		return -1;

	mod->id = KERNEL_MOD_ID;
	mod->name = strdup("kernel");
	/* special refcnt for kernel so it gets freed at the very end */
	mod->refcnt = 1;

	/* 
	 * Despite /proc/kallsyms, System.map is still useful because it includes data symbols
	 * We use System.map if specified, otherwise we default to /proc/kallsyms
	 */
	if (options.opt_sysmap_syms) {
		ret  = -1; //load_sysmap_symbols(&kernel_syms);
		from = options.symbol_file;
	} else {
		ret  = load_kallsyms_symbols(mod);
		from = PFMON_KALLSYMS;
	}
	if (!ret) {
		vbprintf("loaded %lu text symbols %lu data symbols from %s\n",
		mod->nsyms[0],
		mod->nsyms[1],
		from);

		pthread_mutex_lock(&module_list_lock);
		add_module_syms(mod);
		pthread_mutex_unlock(&module_list_lock);
	} 
	return ret;
}

// attaches the kernel symbols to the options.primary_syms table in
// system-wide mode to enable kernel-level symbol resolution
void attach_kernel_syms(pfmon_sdesc_t *sdesc)
{
	module_map_list_t *list;
	module_map_t *map;
	module_symbols_t *mod;
	
	/* don't bother whenever unecessary */
	if (!(options.opt_addr2sym || options.opt_triggers))
		return;

	list = calloc(1, sizeof(module_map_list_t));
	if (!list)
		fatal_error("cannot allocate module_map_list\n");

	/* 2 entries, last is end marker */
	map = calloc(2, sizeof(module_map_t));
	if (!map)
		fatal_error("cannot allocate module_map\n");
	
	pthread_mutex_init(&list->lock, PTHREAD_MUTEX_TIMED_NP);
	list->refcnt = 1;
	list->map = map;

	mod = find_module_syms(KERNEL_MOD_ID);
	if (!mod) {
		free(map);
		return;
	}

	map[0].mod = mod;
	map[0].path = strdup("kernel");
	map[0].version = 0;
	map[0].pid = 0;

	map[0].base[0] = 0; /* kernel addresses are absolute */
	map[0].base[1] = 0; /* kernel addresses are absolute */

	map[0].min[0]  = mod->sym_tab[0][0].value;
	map[0].min[1]  = mod->sym_tab[1][0].value;
	
	/* end marker */
	map[1].mod = NULL;
	map[1].version = 0;
	map[1].pid = -1;

	if (mod->nsyms[0]) {
		map[0].max[0] = mod->sym_tab[0][mod->nsyms[0]-1].value
			    + mod->sym_tab[0][mod->nsyms[0]-1].size;

		if (map[0].mod->sym_tab[0][0].value >= map[0].base[0]) {
			map[0].base[0] = map[0].base[1] = 0;
			DPRINT(("xero base for %s\n", mod->name));
		}
	}
	if (mod->nsyms[1])
		map[0].max[1] = mod->sym_tab[1][mod->nsyms[1]-1].value
			    + mod->sym_tab[1][mod->nsyms[1]-1].size;

	sdesc->syms = list;
}

/*
 * load or connect missing module_symbols_t for sdesc
 * special module_symbols ([vdso], ...) have already
 * been loaded
 */
void
pfmon_gather_module_symbols(pfmon_sdesc_t *sdesc)
{
	module_map_t *map = NULL;
	module_symbols_t *mod = NULL;
	struct stat st;
	char *path = NULL;
	uint64_t id;
	int ret;
	
	if (!sdesc->syms)
		return;

	pthread_mutex_lock(&module_list_lock);

	pthread_mutex_lock(&sdesc->syms->lock);

	for(map = sdesc->syms->map; map->pid != -1; map++) {

		path = map->path;
		mod = map->mod;

		id = 0;

		/*
 		 * look if file-based module exist
 		 */
		if(!mod) {
			ret = stat(path, &st);
			if (ret == 0) {
				id = (uint64_t)st.st_dev << 32 | st.st_ino;
				/* look if module exists, and increment refcnt */
				mod = find_module_syms(id);
			}
		}

		if(!mod) {
			mod = calloc(1, sizeof(module_symbols_t));
			if (!mod) {
				warning("Module scanner out of memory (1)\n");
				goto error;
			}
			mod->id = id;
			mod->name = strdup(path);
			mod->refcnt = 1;
			if (load_module_syms(path, mod)) {
				free(mod->name);
				free(mod);
				goto error;
			}
			add_module_syms(mod);
		}

		/*
 		 * if we have created a new module, then adjust min, max
 		 */
		if (!map->mod) {
			if (mod->nsyms[0]) {
				map->max[0] = mod->sym_tab[0][mod->nsyms[0]-1].value
					+ mod->sym_tab[0][mod->nsyms[0]-1].size;

				if (mod->sym_tab[0][0].value >= map->base[0]) {
					map->base[0] = map->base[1] = 0;
					DPRINT(("zero base for %s\n", mod->name));
				}
			} else
				map->max[0] = 0;
		
			if (mod->nsyms[1]) {
				map->max[1] = mod->sym_tab[1][mod->nsyms[1]-1].value
					+ mod->sym_tab[1][mod->nsyms[1]-1].size;

			} else
				map->max[1] = 0;

			map->min[0] += map->base[0];
			map->min[1] += map->base[0]; /* yes, text base */

			map->max[0] += map->base[0];
			map->max[1] += map->base[0]; /* yes, text base */

			vbprintf("[%d] %lu text symbols and %lu data symbols, ELF file %s\n",
				sdesc->tid,
				mod->nsyms[0],
				mod->nsyms[1],
				path);
		}
		map->mod = mod;
	}
error:
	pthread_mutex_unlock(&sdesc->syms->lock);
	pthread_mutex_unlock(&module_list_lock);
}

/*
 * append k module_maps from map to end of sdesc->syms
 */
static int
append_module_maps(pfmon_sdesc_t *sdesc, module_map_t *map, int k)
{
	module_map_t *x;
	int i = 0;

	/* if list not empty, first find the end */
	if(sdesc->syms) {
		/* i points to last element */
		for(x = sdesc->syms->map; x->pid != -1; x++)
			i++; 
	} else {
		sdesc->syms = calloc(1, sizeof(module_map_list_t));
		if (!sdesc->syms)
			return -1;
		sdesc->syms->refcnt = 1;
		sdesc->syms->version = 1;
		pthread_mutex_init(&sdesc->syms->lock, PTHREAD_MUTEX_TIMED_NP);
	}
	/* realloc for old + new module_maps */
	sdesc->syms->map = realloc(sdesc->syms->map, (i+k) * sizeof(module_map_t));
	if (!sdesc->syms->map)
		return -1;

	x = sdesc->syms->map + i;
	memcpy(x, map, k * sizeof(module_map_t));

	return 0;
}

/*
 * mode = 0 : only map is loaded
 * mode = 1 : map + actual symbol table are loaded
 */
int
load_sdesc_symbols(pfmon_sdesc_t *sdesc, int mode)
{
	module_map_t *p;
	module_symbols_t *mod;
	pid_t pid;
	struct stat st;
	size_t szl;
	FILE *fp;
	uint64_t id, prev_id;
	uint64_t base_text, base_data, start, offset;
	uint64_t text_offs, data_offs, end;
	unsigned int version;
	size_t max_count;
	int ret, n, k;
	char perm[8];
	char filename[32];
	char *line, *path, *c;
	char found_text, found_data;

	/* don't bother whenever unecessary */
	if (!(options.opt_addr2sym || options.opt_triggers))
		return 0;

	/*
 	 * flush remaining samples, if any
 	 *
 	 * in per-thread mode, monitored thread is necessary
 	 * stopped because we come here on breakpoints only.
 	 */
	pfmon_process_smpl_buf(sdesc, 0);
	
	pid = sdesc->tid;

	line = path = NULL;
	
	if (sdesc->syms)
		version = ++sdesc->syms->version;
	else
		version = 1; /* anticipate first version */

	vbprintf("[%d] SDESC_SYMS mode=%d version=%d\n", pid, mode, version);
	DPRINT(("[%d] SDESC_SYMS mode=%d version=%d\n", pid, mode, version));
	
	sprintf(filename, "/proc/%d/maps", pid);
	fp = fopen(filename, "r");
	if (fp == NULL) 
		return -1;

	szl = 0;
	base_text = base_data = 0;
	found_text = found_data = 0;
	text_offs = data_offs = 0;

	p = NULL;
	max_count = 8;
	k = 0;
	ret = 0;
	prev_id = -1;
	while(getline(&line, &szl, fp) >0) {
		n = sscanf (line, "%"PRIx64"-%"PRIx64" %s %"PRIx64, &start, &end, perm, &offset);

		mod = NULL;
		if (n != 4 || perm[3] != 'p')
			continue;

		path = strchr(line, '/');
		if (!path)
			path = strchr(line, '[');
		/* remove trailing \n */
		if (path) {
			path[strlen(path)-1] = '\0';
			/*
			 * we skip stack because the current data structures
			 * do not allow copying of stack between different
			 * threads in the same process.
			 */
			if (!strcmp(path, "[stack]"))
				continue;

			/*
			 * handle the case where /proc/maps reports the library
			 * path as deleted (from the dcache)
			 */
			c = strchr(path, ';');
			if (c)
				*c = '\0';

			if (perm[2] == 'x' && perm[1] == '-') {
				base_text = start;
				text_offs = offset;
				found_text = 1;
			} else if (perm[0] == 'r' && perm[1] == 'w') {
				base_data = start;
				data_offs = offset;
				found_data = 1;
			} else
				continue;

			/*
 			 * need to iterate until we have text + data
 			 * for all filesystem-based paths
 			 * text and data may not necessarily be contiguous
 			 * in /proc/PID/maps
 			 */
			if (*path == '/' && (found_data == 0 || found_text == 0))
				continue;

			if (k == 0 || k == max_count) {
				max_count <<=1;
				p = realloc(p, max_count * sizeof(module_map_t));
				if (!p) {
					ret = -1;
					break;
				}
			}
			id = 0;
			/*
 			 *  get the inode number and assign it as an ID
 			 */
			if (*path =='/') {
				if (stat(path, &st) == 0) {
					id = (uint64_t)st.st_dev << 32 | st.st_ino;
					/* avoid duplicates */
					if (id == prev_id)
						continue;
					prev_id = id;
				}
				/*
 				 * look if we already have the module
 				 * id=0 guaranteed not to exist
 				 */
				mod = find_module_syms(id);
			}

			p[k].pid = pid;
			p[k].version = version;
                        p[k].path = strdup(path);
			
			p[k].base[0]  = base_text;
			p[k].base[1]  = base_data;
			p[k].min[0]   = base_text;
			p[k].min[1]   = base_data;
			p[k].offs[0]  = text_offs;
			p[k].offs[1]  = data_offs;

			/*
			 * if module was not found and exists
			 * in the filesystem, then load symbol information
			 */
			if (mode == 1 && !mod && id) {
				mod = calloc(1, sizeof(module_symbols_t));
				if (mod == NULL) {
					ret = -1;
					break;
				}
				mod->id	= id;
				mod->name = strdup(path);
				mod->refcnt = 1;
				if (load_module_syms(path, mod)) {
					ret = -1;
					break;
				}
				add_module_syms(mod);
			}

			if (*path != '/') {
				/* fill out max from maps */
				if (found_text)
					p[k].max[0] = end;
				else
					p[k].max[1] = end;

				mod = create_pseudo_module_syms(sdesc, path, !found_text, p+k);
				if (!mod) {
					ret = -1;
					break;
				}
			}
			
			p[k].mod = mod;

			if (mod && mod->nsyms[0]) {
				p[k].max[0] = mod->sym_tab[0][mod->nsyms[0]-1].value
					    + mod->sym_tab[0][mod->nsyms[0]-1].size;

				if (p[k].mod->sym_tab[0][0].value >= p[k].base[0]) {
					p[k].base[0] = p[k].base[1] = 0;
					DPRINT(("xero base for %s\n", mod->name));
				}
			} else
				p[k].max[0] = 0;

			if (mod && mod->nsyms[1])
				p[k].max[1] = mod->sym_tab[1][mod->nsyms[1]-1].value
					    + mod->sym_tab[1][mod->nsyms[1]-1].size;
			else
				p[k].max[1] = 0;

			p[k].max[0] += p[k].base[0];
			p[k].max[1] += p[k].base[0]; /* yes, text base */

			if (mode == 1)
				vbprintf("[%u] loaded %lu text symbols and %lu data symbols, ELF file %s\n",
				 	pid,
				 	mod->nsyms[0],
				 	mod->nsyms[1],
				 	path);

			found_text = found_data = 0;
			k++;
		}
	}
	if (!ret) {
		if (k == 0 || (k+2) >= max_count) {
			max_count+=2;
			p = realloc(p, max_count * sizeof(module_map_t));
			if (!p) {
				ret = -1;
				goto error;
			}
		}
		ret = add_kernel_module_map(sdesc, version, p+k);
		if (ret)
			goto error;
		k++;

		/* end marker */		
		p[k].mod = NULL;
		p[k].pid = -1;
		p[k].version = 0;
		k++;

		/* may create sdesc->syms */
		ret = append_module_maps(sdesc, p, k);
		if (ret)
			goto error;
	}
	if (!ret && mode == 0)
		vbprintf("[%u] loaded symbol maps version=%u\n",
		 	pid,
			sdesc->syms->version);
error:
	if (line)
		free(line);

	fclose(fp);
	free(p);

	if (ret == -1)
		warning("abort loading symbols from %s\n", filename);

	return ret;
}

int
find_sym_addr(char *name, unsigned int version, module_map_list_t *list,
	      pfmon_sym_type_t type, uint64_t *start, uint64_t *end)
{
	module_map_t *map;
	module_symbols_t *mod;
	symbol_t *symbol_tab;
	char *p;
	unsigned long i, nsyms;
	uint64_t offs = 0;
	int has_mod_name = 0;
	char mod_name[32];

	if (name == NULL || start == NULL || list == NULL) 
		return -1;

	/*
	 * check for module name
	 */
	mod_name[0] = '\0';
	p = strchr(name, ':');
	if (p) {
		strncpy(mod_name, name, p - name); 
		mod_name[p-name] = '\0';
		name = p + 1;
		has_mod_name = 1;
	}

	for(map = list->map; map->mod; map++) {
		if (has_mod_name && strcmp(mod_name, map->mod->name))
			continue;

		if (map->version != version)
			continue;	

		mod = map->mod;
		nsyms      = mod->nsyms[type];
		symbol_tab = mod->sym_tab[type];

		for (i = 0; i < nsyms; i++) {
			if (!strcmp(name, symbol_tab[i].name))
				goto found;
		 }
	}
	return -1;
found:
	if (type == PFMON_DATA_SYMBOL && map->base[PFMON_DATA_SYMBOL])
		offs = map->base[PFMON_DATA_SYMBOL] - map->base[PFMON_TEXT_SYMBOL];

	*start = map->base[type] - offs + symbol_tab[i].value;

	if (end) {
		if (symbol_tab[i].size != 0) {
			*end = *start + symbol_tab[i].size; 
		} else {
			vbprintf("using approximation for size of symbol %s\n", name);

			if (i == (nsyms-1)) {
				warning("cannot find another symbol to approximate size of %s\n", name);
				return -1;
			}

		        /*
		 	 * XXX: Very approximative and maybe false at times
		 	 * Use carefully
		 	 */
			*end = symbol_tab[i+1].value;
		}
		vbprintf("symbol %s (%s): [%"PRIx64"-%"PRIx64")=%"PRIu64" bytes\n", 
			name, 
			type == PFMON_TEXT_SYMBOL ? "code" : "data",
			*start, 
			*end, 
			*end-*start);
	}
	return 0;
}

static int
bsearch_sym_cmp(unsigned long base, unsigned long addr, symbol_t *sym)
{
	unsigned long s, e;

	s = base + sym->value;
	e = s + sym->size;

	/* match */
	if (s <= addr && addr < e)
		return 0;

	/* less than */
	if (addr < s)
		return -1;

	/* greater than */
	return 1;
}

// andrzejn: find by address, pid, version
// andrzejn: TBD: check if it works ok
int
find_sym_by_av(uint64_t addr, unsigned int version, module_map_list_t *list,
	       pfmon_sym_type_t type, char **name, char **module,
	       uint64_t *start, uint64_t *end)
{
	module_map_t *map;
	module_symbols_t *mod;
	symbol_t *s = NULL;
	long l, h, m;
	uint64_t base;
	int r;

	if (!list)
		return -1;

	for(map = list->map; map->mod ; map++) {

		if (map->version != version)
			continue;	

		mod = map->mod;

		/* max is already base adjusted */
		if (addr > map->max[type])
			continue;

		if (mod->nsyms[type] == 0)
			continue;

		base = map->base[type];

		/*
		 * binary search
		 * cannot use bsearch because of base adjustment
		 * s = bsearch(&addr, mod->sym_tab[type], mod->nsyms[type], sizeof(symbol_t), bsearch_sym_cmp);
		 */
		l = 0;
		h = mod->nsyms[type]-1;
		while (l <= h) {
			m = (l + h) / 2;
			s = &mod->sym_tab[type][m];
			r = bsearch_sym_cmp(base, addr, &mod->sym_tab[type][m]);
			if (r > 0)
				l = m + 1;
			else if (r < 0)
				h = m - 1;
			else
				goto found;
		}
		/*
		 * symbol was in range but did not match any symbol.
		 * possibly hit a hole because of incomplete/inacurate
		 * symbol information
		 */
		if (map->mod) {
			if((addr >= map->min[type]) && (addr <= map->max[type])) {
				if(name) *name = "UNKNOWN";
				if(start) *start = map->min[type];
				if(end) *end = map->min[type];
				if(module) *module = mod->name;
				return 0;
			}

		}
	}

	return -1;
found:
	if (name)  *name    = s->name;
	if (start) *start   = base + s->value;
	if (end)   *end     = base + s->value + s->size;
	if (module) *module = mod->name; /* symbol module */
	return 0;
}

/*
 * mostly for debug
 */
void
print_syms(pfmon_sdesc_t *sdesc)
{
	module_map_t *map;
	module_symbols_t *mod;
	symbol_t *symbol_tab;
	uint64_t sz, n;
	char *mod_name;
	char *c="TD";
	int j;
	unsigned long i, nsyms;

	for(j=0; j < 2; j++) {
		for (map = sdesc->syms->map; map->mod ; map++) {

			mod      = map->mod;
			mod_name = mod->name;

			nsyms      = mod->nsyms[j];
			symbol_tab = mod->sym_tab[j];
			for (i = 0; i < nsyms; i++) {
				sz = symbol_tab[i].size;
				if (i == (nsyms-1) && sz == 0) {
					if (map[1].mod && map[1].mod->nsyms[j]) {
						n = map[1].base[j]+map[1].mod->sym_tab[j][0].value;
						sz = n - map->base[j]+symbol_tab[i].value;
					} else {
						sz = ~0 - map->base[j]+symbol_tab[i].value;
					}

				}
				printf("%"PRIx64" %c %16"PRIu64" %s<%s>\n", 
					map->base[j]+symbol_tab[i].value, 
					c[j],
					sz,
					symbol_tab[i].name, mod_name);
			}
		}
	}
}

/*
 * read ELF program header to return entry point address
 * return:
 * 	0 if error
 * 	addr otherwise
 */
uint64_t
pfmon_get_entry_point(char *filename)
{
	Elf *elf;
	Elf64_Ehdr *ehdr64;
	Elf32_Ehdr *ehdr32;
	char *eident;
	uint64_t addr = 0;
	int fd;

	fd = open(filename, O_RDONLY);
	if (fd == -1) {
		DPRINT(("symbol file for %s not found\n", filename));
		return 0;
	}

  	/* initial call to set internal version value */
	if (elf_version(EV_CURRENT) == EV_NONE) {
		DPRINT(("ELF library out of date"));
		goto end2;
	}

  	/* prepare to read the entire file */
	elf = elf_begin(fd, ELF_C_READ, NULL);
	if (elf == NULL) {
		DPRINT(("cannot read %s\n", filename));
		goto end2;
	}

	/* error checking */
	if (elf_kind(elf) != ELF_K_ELF) {
		DPRINT(("%s is not an ELF file\n", filename));
		goto end;
	}
  
	eident = elf_getident(elf, NULL);
	switch (eident[EI_CLASS]) {
  		case ELFCLASS64:
			ehdr64 = elf64_getehdr(elf);
			if (ehdr64)
				addr = ehdr64->e_entry;
			break;
		case ELFCLASS32:
			ehdr32 = elf32_getehdr(elf);
			if (ehdr32)
				addr = ehdr32->e_entry;
			break;
		default:
			addr = 0;
	}
end:
	elf_end(elf);
end2:
	close(fd);

	return addr;
}

/*
 * check whether filename is ELF32 ABI
 * return:
 * 	0 not ELF32
 * 	1 is ELF32
 */
int
pfmon_program_is_abi32(char *filename)
{
	Elf *elf;
	char *eident;
	int fd, ret = 0;

	fd = open(filename, O_RDONLY);
	if (fd == -1) {
		DPRINT(("symbol file for %s not found\n", filename));
		return 0;
	}

  	/* initial call to set internal version value */
	if (elf_version(EV_CURRENT) == EV_NONE) {
		DPRINT(("ELF library out of date"));
		goto end2;
	}

  	/* prepare to read the entire file */
	elf = elf_begin(fd, ELF_C_READ, NULL);
	if (elf == NULL) {
		DPRINT(("cannot read %s\n", filename));
		goto end2;
	}

	/* error checking */
	if (elf_kind(elf) != ELF_K_ELF) {
		DPRINT(("%s is not an ELF file\n", filename));
		goto end;
	}
  
	eident = elf_getident(elf, NULL);
	if (eident[EI_CLASS] == ELFCLASS32)
		ret = 1;
end:
	elf_end(elf);
end2:
	close(fd);
	return ret;
}

static void
free_module_symbols(module_symbols_t *p)
{
	symbol_t *s;
	int i, j;

	DPRINT(("FREE id=%"PRIu64" %s\n", p->id, p->name));
			
	for(i=0; i < 2; i++) {
		s = p->sym_tab[i];
		for(j=0; j < p->nsyms[i]; j++, s++)
			free(s->name);
		free(p->sym_tab[i]);
	}
	/*
 	 * only actual files are present in
 	 * module list
 	 *
 	 * id == 0 denote special symbols ([heap], [stack], ...)
 	 *
 	 */
	if (p->id) {
		if (p->prev)
			p->prev->next = p->next;
		else
			module_list = p->next;

		if (p->next)
			p->next->prev = p->prev;
	}
	free(p->name);
	free(p);
}

void
free_module_map_list(module_map_list_t *list)
{
	module_map_t *map;

	if (!list)
		return;

	pthread_mutex_lock(&list->lock);

	if (--list->refcnt == 0) {

		pthread_mutex_lock(&module_list_lock);

		for(map = list->map; map->pid != -1; map++) {
			if (map->mod) {
				DPRINT(("REF %s %lu %p\n", map->mod->name, map->mod->refcnt, map->mod));
				map->mod->refcnt--;
				if (map->mod->refcnt == 0)
					free_module_symbols(map->mod);
				else
					DPRINT(("STILL REF %s %lu\n", map->mod->name, map->mod->refcnt));
			}
			/* was strdup'd */
			free(map->path);
		} 
		pthread_mutex_unlock(&module_list_lock);
		/* was realloc'd */
		free(list->map);
		free(list);
	} else
		pthread_mutex_unlock(&list->lock);
}

void
show_module_map(pfmon_sdesc_t *sdesc)
{
	module_map_t *map;

	if (!sdesc->syms)
		return;

	pthread_mutex_lock(&sdesc->syms->lock);

	for(map = sdesc->syms->map; map->mod; map++) {
		printf("mod %s %d min=%"PRIx64" max=%"PRIx64"\n",
			map->path, map->version,
			map->min[0],
			map->max[0]);
	}

	pthread_mutex_unlock(&sdesc->syms->lock);
}
