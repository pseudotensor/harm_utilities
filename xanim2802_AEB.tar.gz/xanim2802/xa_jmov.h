
/*
 * xa_jmov.h
 *
 * Copyright (C) 1995-1999,2000 by Mark Podlipec. 
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 * 
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */

#include "xanim.h"

typedef struct JMOV_FRAME_STRUCT
{
  uint32 time;
  uint32 timelo;
  XA_ACTION *act;
  struct JMOV_FRAME_STRUCT *next;
} JMOV_FRAME;
 
 
typedef struct
{
  uint32 version;
  uint32 fps;            /* frames per second */
  uint32 frames;         /* total video frames */
  uint32 width;
  uint32 height;
  uint32 bandwidth;      /* 1kbytes/sec need to playback */
  uint32 qfactor;        /* quantization scaling factor */
  uint32 mapsize;        /* colors in colormap */
  uint32 indexbuf;       /* offset in file of frame indexes */
  uint32 tracks;         /* num of audio tracks */
  uint32 volbase;        /* base volume */
  uint32 audioslice;     /* audio bytes per frame */
/*Audio_hdr */          /* Audio_hdr?!?  for what machine?? */
  uint32 freq;
  uint32 chans;
  uint32 prec;
  uint32 codec;
/*filler(48) */
} JMOV_HDR;
 
#define JMOV_AUDIO_ENC_NONE (0)   /* no encoding assigned */
#define JMOV_AUDIO_ENC_ULAW (1)   /* u-law encoding */
#define JMOV_AUDIO_ENC_ALAW (2)   /* A-law encoding */
#define JMOV_AUDIO_ENC_PCM  (3)   /* Linear PCM encoding */

