
/*
 * xanim.h
 *
 * Copyright (C) 1990-1999,2000 by Mark Podlipec. 
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 * 
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */
#ifndef XA_DONT_USE_X11
#include <X11/Xos.h>
#else
#include <Xos.h>
#endif

#include <stdio.h>
#include <sys/types.h>
#include <stdio.h>

#ifndef VMS

#ifndef __QNX__
#include <sys/param.h>
#include <memory.h>
#endif

#ifdef __bsdi__
#include <sys/malloc.h>
#else
#ifndef __CYGWIN32__
#ifndef __FreeBSD__
#include <malloc.h>
#endif
#endif
#endif


#include <unistd.h>
#else
#include <unixio.h>
#endif
#include <stdlib.h>
#ifndef XA_DONT_USE_X11
#include <X11/Xlib.h>
#else
#include <Xlib.h>
#endif
#include "xa_config.h"

#ifdef XA_XTPOINTER
typedef void* XtPointer;
#endif

#ifdef XA_PETUNIA
#define XA_REMOTE_CONTROL 1
#endif

#ifdef XA_ATHENA
#define XA_REMOTE_CONTROL 1
#endif

#ifdef XA_MOTIF
#define XA_REMOTE_CONTROL 1
#endif

/*
 * Win32 utilizatizes same defines as MSDOS does
 */
#ifdef _WIN32
#define MSDOS 1
#endif

/*
 * MSDOS and Win32 needs to be specifically told to open file for binary 
 * reading.  For VMS systems, specify "Stream_LF" mode for VAX C.
 */
#ifdef MSDOS
#define XA_OPEN_MODE "rb"
#else
#ifdef VMS
#define XA_OPEN_MODE "r","ctx=stm"
#else
#define XA_OPEN_MODE "r"
#endif
#endif

typedef int		int32;
typedef unsigned int	uint32;
typedef short		int16;
typedef unsigned short	uint16;
typedef char		int8;
typedef unsigned char	uint8;

#define xaFALSE  0
#define xaTRUE   1
#define xaNOFILE 2
#define xaERROR  3
#define xaPAUSE  4


#define xaMIN(x,y)   ( ((x)>(y))?(y):(x) )
#define xaMAX(x,y)   ( ((x)>(y))?(x):(y) )
#define xaABS(x)     (((x)<0)?(-(x)):(x))

/* X11 variables */

#define XA_GRAYSCALE	0x06
#define XA_STATICGRAY	0x03
#define XA_PSEUDOCOLOR	0x14
#define XA_STATICCOLOR	0x11
#define XA_DIRECTCOLOR	0x18
#define XA_TRUECOLOR	0x19
#define XA_MONOCHROME	0x00

#define XA_X11_STATIC	0x01
#define XA_X11_GRAY	0x02
#define XA_X11_CMAP	0x04
#define XA_X11_TRUE	0x08
#define XA_X11_COLOR	0x10

extern int32 x11_depth;
extern int32 x11_class;
extern int32 x11_bytes_pixel;
extern int32 x11_bits_per_pixel;
extern int32 x11_bitmap_pad;
extern int32 x11_bitmap_unit;
extern int32 x11_bit_order;
extern int32 x11_byte_order;
extern int32 xam_byte_order;
extern int32 x11_byte_mismatch;
extern int32 x11_pack_flag;
extern int32 x11_cmap_flag;
extern int32 x11_cmap_size;
extern int32 x11_disp_bits;
extern int32 x11_cmap_type;
extern int32 x11_depth_mask;
extern int32 x11_display_type;
extern int32 x11_red_mask;
extern int32 x11_green_mask;
extern int32 x11_blue_mask;
extern int32 x11_red_shift;
extern int32 x11_green_shift;
extern int32 x11_blue_shift;
extern int32 x11_red_bits;
extern int32 x11_green_bits;
extern int32 x11_blue_bits;
extern int32 x11_black;
extern int32 x11_white;
extern int32 x11_verbose_flag;
extern uint32 x11_kludge_1;
extern int32 xa_root;

#define XA_MSBIT_1ST  1
#define XA_LSBIT_1ST  0

#define XA_MSBYTE_1ST  1
#define XA_LSBYTE_1ST  0

extern int32 xa_anim_holdoff;
extern int32 xa_anim_status;

/*------*/
#define XA_NEXT_MASK	0x01
#define XA_STOP_MASK	0x02
#define XA_STEP_MASK	0x04
#define XA_RUN_MASK	0x08
#define XA_ISTP_MASK	0x10
#define XA_FILE_MASK	0x20
#define XA_CLEAR_MASK	0x01
#define XA_BEGIN_MASK	0x01
/*------*/
#define XA_UNSTARTED   0x00
#define XA_BEGINNING   0x80
#define XA_STOP_PREV   0x02
#define XA_STOP_NEXT   0x03
#define XA_STEP_PREV   0x04
#define XA_STEP_NEXT   0x05
#define XA_RUN_PREV    0x08
#define XA_RUN_NEXT    0x09
#define XA_ISTP_PREV   0x14
#define XA_ISTP_NEXT   0x15
#define XA_FILE_PREV   0x24
#define XA_FILE_NEXT   0x25

#define XA_SHOW_NORM   0
#define XA_SHOW_SKIP   1

#define XA_SPEED_NORM (1<<4)
#define XA_SPEED_MIN  (1)
#define XA_SPEED_MAX  (1<<8)
#define XA_SPEED_ADJ(x,s)  (((x)*(s))>>4)

#define NOFILE_ANIM   0xffff
#define UNKNOWN_ANIM  0
/*************************** VIDEO FILES *************/
#define XA_IFF_ANIM      1
#define XA_FLI_ANIM      2
#define XA_GIF_ANIM      3
#define XA_TXT_ANIM      4
#define XA_FADE_ANIM     5
#define XA_DL_ANIM       6
#define XA_JFIF_ANIM     7
#define XA_PFX_ANIM      8
#define XA_SET_ANIM      9
#define XA_RLE_ANIM     10
#define XA_AVI_ANIM     11
#define XA_OLDQT_ANIM	12
#define XA_MPG_ANIM     13
#define XA_JMOV_ANIM    14
#define XA_ARM_ANIM     15
#define XA_SGI_ANIM     16
#define XA_RAW_ANIM     17
#define XA_J6I_ANIM     18
#define XA_QT_ANIM	19
/*************************** AUDIO FILES *************/
#define XA_WAV_ANIM     128
#define XA_AU_ANIM      129
#define XA_8SVX_ANIM    130

typedef struct
{
  uint16 red,green,blue,gray;
} ColorReg;

typedef struct XA_ACTION_STRUCT
{
 int32 type;		/* type of action */
 int32 cmap_rev;          /* rev of cmap */
 uint8 *data;		/* data ptr */
 struct XA_ACTION_STRUCT *next;
 struct XA_CHDR_STRUCT *chdr;
 ColorReg *h_cmap;	/* For IFF HAM images */
 uint32 *map;
 struct XA_ACTION_STRUCT *next_same_chdr; /*ptr to next action with same cmap*/
} XA_ACTION;

typedef struct XA_CHDR_STRUCT
{
 int32 rev;
 ColorReg *cmap;
 uint32 csize,coff;
 uint32 *map;
 uint32 msize,moff;
 struct XA_CHDR_STRUCT *next;
 XA_ACTION *acts;
 struct XA_CHDR_STRUCT *new_chdr;
} XA_CHDR;

typedef struct
{
 uint32 csize,coff;
 uint8 data[4];
} ACT_CMAP_HDR;

typedef struct XA_FRAME_STRUCT
{
  XA_ACTION *act;	/* ptr to relevant Action. */
  int32 time_dur;	/* duration of Frame in ms. */
  int32 zztime;		/* time at start of Frame in ms. */
} XA_FRAME;

typedef struct
{
  uint32 count;    /* number of loops */
  int32 cnt_var;   /* var to keep track of loops */
  uint32 end_frame; /* last frame of loop */
} ACT_BEG_LP_HDR;

typedef struct ACT_END_LP_STRUCT
{
  uint32 *count;       /* points back to beg_lp->count */
  int32 *cnt_var;      /* points back to beg_lp->cnt_var */
  uint32 begin_frame;  /* first frame of loop */
  uint32 *end_frame;   /* points back to beg_lp->end_frame */
  XA_ACTION *prev_end_act; /* used to nest loops during creation */
} ACT_END_LP_HDR;

/** AUDIO SECTION ************************/

typedef struct
{
  uint32 enable;
  uint32 mute;
  int32  volume;
  uint32 newvol;
  uint32 port;
  uint32 playrate;
  uint32 divtest;
  uint32 synctst;
  uint32 fromfile;
  uint32 bufferit;
  uint32 try_stereo;
  double scale;
  char *device;
} XA_AUD_FLAGS;


/* POD temporary til complete overhaul */
#define XAAUD audiof

#ifdef XA_SPARC_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_MMS_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_AIX_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_NetBSD_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_LINUX_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_SGI_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_HPDEV_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_HP_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_EWS_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_SONY_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_AF_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_NAS_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_TOWNS_AUDIO
#define XA_AUDIO 1
#endif
#ifdef XA_TOWNS8_AUDIO
#define XA_AUDIO 1
#endif


/* AUDIO PORT MASKS */
#define XA_AUDIO_PORT_INT	1
#define XA_AUDIO_PORT_HEAD	2
#define XA_AUDIO_PORT_EXT	4
#define XA_AUDIO_PORT_NONE	8

#define XA_AUDIO_STEREO_MSK	0x000001
#define XA_AUDIO_BPS_2_MSK	0x000002
#define XA_AUDIO_BIGEND_MSK	0x000004
#define XA_AUDIO_INVALID	0x000000
#define XA_AUDIO_LINEAR		0x000010
#define XA_AUDIO_SIGNED		0x000020
#define XA_AUDIO_ULAW  		0x000030
#define XA_AUDIO_ADPCM		0x000040
#define XA_AUDIO_NOP  		0x000050
#define XA_AUDIO_ARMLAW		0x000060
#define XA_AUDIO_IMA4 		0x000070
#define XA_AUDIO_DVI  		0x000080
#define XA_AUDIO_GSM  		0x000090
#define XA_AUDIO_MSGSM 		0x0000A0
#define XA_AUDIO_ALAW  		0x0000B0
#define XA_AUDIO_TYPE_MASK  	0xfffff0

/*NOTES: 
 * last ending is [1|2](BPS),[M|S](Mono/Stereo),[B|L](big/little endian)
 */

#define XA_AUDIO_LINEAR_1M	0x000010
#define XA_AUDIO_LINEAR_1S	0x000011
#define XA_AUDIO_LINEAR_2ML	0x000012
#define XA_AUDIO_LINEAR_2SL	0x000013
#define XA_AUDIO_LINEAR_2MB	0x000016
#define XA_AUDIO_LINEAR_2SB	0x000017

#define XA_AUDIO_SIGNED_1M	0x000020
#define XA_AUDIO_SIGNED_1S	0x000021
#define XA_AUDIO_SIGNED_2ML	0x000022
#define XA_AUDIO_SIGNED_2SL	0x000023
#define XA_AUDIO_SIGNED_2MB	0x000026
#define XA_AUDIO_SIGNED_2SB	0x000027

#define XA_AUDIO_SUN_AU		0x000030
#define XA_AUDIO_ULAWM 		0x000030
#define XA_AUDIO_ULAWS 		0x000031

#define XA_AUDIO_ARMLAWM	0x000060
#define XA_AUDIO_ARMLAWS	0x000061

#define XA_AUDIO_ADPCM_M	0x000040
#define XA_AUDIO_ADPCM_S	0x000041

#define XA_AUDIO_IMA4_M 	0x000070
#define XA_AUDIO_IMA4_S 	0x000071

#define XA_AUDIO_DVI_M		0x000080
#define XA_AUDIO_DVI_S		0x000081

#define XA_AUDIO_GSM_M		0x000090
#define XA_AUDIO_MSGSM_M	0x0000A0

#define XA_AUDIO_ALAWM 		0x0000B0
#define XA_AUDIO_ALAWS 		0x0000B1

#define XA_AUDIO_FILE_FLAG   0x0001

typedef struct XA_SND_STRUCT
{
  uint32 type;		/* type, chans, bps, */
  uint32 flag;		/* flags */
  int32  fpos;		/* starting file position */
  uint32 itype;		/* input sample type */
  uint32 ifreq;		/* input sample freq */
  uint32 hfreq;		/* closest hardware freq */
  uint32 inc;		/* inc for i to h converstion << 24 */
  uint32 tot_bytes;	/* total size in bytes*/
  uint32 tot_samps;	/* total samples in chunk */
  uint32 inc_cnt;	/* dynamic var for freq conv */
  uint32 bit_cnt;	/* dynamic var for partial bytes - not used yet */
  uint32 byte_cnt;	/* dynamic var for counting bytes */
  uint32 samp_cnt;	/* samples used so far */
  uint32 blk_size;	/* size of blocks - used by some codecs */
  uint32 blk_cnt;	/* dynamic var for cnting inside a block */
  uint32 (*delta)();	/* conversion routine */
  uint32 snd_time;	/* time at start of snd struct ms */ 
  uint32 ch_time;	/* chunk time ms */
  uint32 ch_timelo;	/* chunk time fractional ms */
  uint32 ch_size;	/* size of chunk */
  uint32 spec;		/* used by decoder */
  int32 dataL;		/* data Left channel */
  int32 dataR;		/* data Right channel */
  uint8 *snd;		/* sound if present */
  struct XA_SND_STRUCT *prev;
  struct XA_SND_STRUCT *next;
} XA_SND;

#define XA_SND_CHUNK_SIZE 65536

typedef struct
{
  char		*file;		/* is this a duplication of xanim_hdr->file?*/
  FILE		*fin;           /* buffer file */
  int		csock;          /* control socket */
  int		dsock;          /* data socket */
  uint32	fpos;		/* bytes read so far */
  int32	eof;		/* size of file - set by client */
  uint32	err_flag;	/* set on errors and/or EOF */
  uint32	type_flag;	/* random/sequential access? */
  uint32	load_flag;	/* from file, from memory, buffered? */
  uint32	(*Open_File)();
  uint32	(*Close_File)();
  uint32	(*Read_U8)();
  uint32	(*Read_LSB_U16)();
  uint32	(*Read_MSB_U16)();
  uint32	(*Read_LSB_U32)();
  uint32	(*Read_MSB_U32)();
  int32	(*Read_Block)();
  int32	(*At_EOF)();
  void		(*Set_EOF)();
  int32	(*Seek_FPos)();
  int32	(*Get_FPos)();
	/* This Buffer is used initially to Determine File type and later *
	 * to contruct u8, u16 and u32 entities for certain input methods */
  uint8	*buf;
  uint32	buf_size;
  uint8	*buf_ptr;
  uint32	buf_cnt;
  void		*net;		/* generic structure for addition info */
} XA_INPUT;

	/* load into memory and play from there */
#define XA_IN_LOAD_MEM		0x00
	/* don't load into mem, play from file */
#define XA_IN_LOAD_FILE		0x01
	/* decompress into X11 images and play those */
#define XA_IN_LOAD_BUF		0x02

	/* Input Method supports Random access (otherwise Sequential only) */
#define XA_IN_TYPE_RANDOM	0x01
#define XA_IN_TYPE_SEQUENTIAL	0x00

#define XA_IN_ERR_NONE		0x00
#define XA_IN_ERR_EOF		0x01
#define XA_IN_ERR_ERR		0x02

typedef struct XA_PAUSE_STRUCT
{
  uint32 frame;
  struct XA_PAUSE_STRUCT *next;
} XA_PAUSE;

typedef struct XA_FUNC_STRUCT
{
  uint32 var1,var2;
  void (*function)();
  struct XA_FUNC_STRUCT *next;
} XA_FUNC_CHAIN;

typedef struct XA_ANIM_HDR_STRUCT
{
  int32	file_num;
  int32	anim_type;	/* animation type */
  int32	imagex;		/* width */
  int32	imagey;		/* height */
  int32	imagec;		/* number of colors */
  int32	imaged;		/* depth in planes */
  int32	dispx;		/* display width */
  int32	dispy;		/* display height */
  int32	buffx;		/* buffered width */
  int32	buffy;		/* buffered height */
  int32	anim_flags;
  int32	loop_num;	/* number of times to loop animation */
  int32	loop_frame;	/* index of loop frame */
  int32	last_frame;	/* index of last frame */
  int32	total_time;	/* Length of Anim in ms */
  char		*name;		/* name of anim */
  char		*fname;		/* name of anim data file(video and audio) */
  char		*desc;		/* descriptive string */
/* char		 *fsndname;	   eventually have separate sound file name */
  XA_INPUT	*xin;		/* XAnim Input structure */
  uint32	(*Read_File)();	/* Routine to Parse Animation */
  int32	max_fvid_size;	/* Largest video codec size */
  int32	max_faud_size;	/* Largest audio codec size */
  XA_FRAME	*frame_lst;	/* array of Frames making up the animation */
  XA_ACTION	*acts;		/* actions associated with this animation */
  XA_SND	*first_snd;	/* ptr to first sound chunk */
  XA_SND	*last_snd;	/* ptr to last sound chunk */
  XA_PAUSE	*pause_lst;	/* pause list */
  void		(*init_vid)();	/* routine to init video */
  void		(*init_aud)();	/* routine to init audio */
 
  XA_FUNC_CHAIN *free_chain;	/* list of routines to call on exit */
  struct XA_ANIM_HDR_STRUCT *next_file;
  struct XA_ANIM_HDR_STRUCT *prev_file;
} XA_ANIM_HDR;

#define ANIM_HAM	0x00000009
#define ANIM_HAM6	0x00000001
#define ANIM_LACE	0x00000002
#define ANIM_CYCLE	0x00000004
#define ANIM_HAM8	0x00000008
#define ANIM_PIXMAP	0x00000100
#define ANIM_FULL_IM	0x00001000
#define ANIM_PING	0x00010000
#define ANIM_NOLOOP	0x00020000
/* single buffered, x11_bytes_pixel */
#define ANIM_SNG_BUF	0x01000000
/* double buffered, 1 byte per pixel */
#define ANIM_DBL_BUF	0x02000000
#define ANIM_3RD_BUF	0x04000000
/* open anim_hdr->fname when starting anim */
#define ANIM_USE_FILE	0x08000000

typedef struct
{
 int32 imagex;
 int32 imagey;
 int32 xoff;
 int32 yoff;
} SIZE_HDR;

typedef struct
{ 
 uint32 flag;
 int32 xpos;
 int32 ypos;
 int32 xsize;
 int32 ysize;
 XImage *image;
 uint8 *clip;
} ACT_IMAGE_HDR;

typedef struct
{ 
 uint32 flag;
 int32 xpos;
 int32 ypos;
 int32 xsize;
 int32 ysize;
 Pixmap pixmap;
 Pixmap clip;
} ACT_PIXMAP_HDR;

typedef struct
{ 
 int32 xpos;
 int32 ypos;
 int32 xsize;
 int32 ysize;
 XA_ACTION *act;
} ACT_APTR_HDR;

#define ACT_BUFF_VALID 0x01

typedef struct
{ 
  uint32 xapi_rev;
  uint32 (*delta)();
  uint32 flags;
  uint32 xpos,ypos;
  uint32 xsize,ysize;
  uint32 special;
  void *extra;
  uint32 fpos;
  uint32 fsize;
  uint8 data[4];
} ACT_DLTA_HDR;

/* ACT_DLTA_HDR Flag Values */
/* ALSO ACT_BUFF_VALID  0x0001   defined above */
#define ACT_SNGL_BUF    0x0100   /* delta is from sngl buffer anim */
#define ACT_DBL_BUF     0x0200   /* delta is from sngl buffer anim */
#define ACT_3RD_BUF     0x0400   /* needs 3rd buffer for HAM or Dither */
#define DLTA_DATA	0x1000   /* delta data is present */

/* DELTA Return VALUES */
#define ACT_DLTA_NORM   0x00000000   /* nothing special */
#define ACT_DLTA_BODY   0x00000001   /* IFF BODY - used for dbl buffer */
#define ACT_DLTA_XOR    0x00000002   /* delta work in both directions */
#define ACT_DLTA_NOP    0x00000004   /* delta didn't change anything */
#define ACT_DLTA_MAPD   0x00000008   /* delta was able to map image */
#define ACT_DLTA_DROP   0x00000010   /* drop this one */
#define ACT_DLTA_BAD    0x80000000   /* uninitialize value if needed */


typedef struct
{
  uint32 cfunc_type;
  void (*color_RGB)();
  void (*color_Gray)();
  void (*color_CLR8)();
  void (*color_CLR16)();
  void (*color_CLR32)();
  void (*color_332)();
  void (*color_CF4)();
  void (*color_332_Dither)();
  void (*color_CF4_Dither)();
} XA_COLOR_FUNC;


typedef struct
{
  uint32 imagex,max_imagex;
  uint32 imagey,max_imagey;
  uint32 imagec;
  uint32 depth;
  uint32 compression;
  uint8 *pic;
  uint32 pic_size;
  uint32 max_fvid_size,max_faud_size;
  uint32 vid_time,vid_timelo;
  uint32 aud_time,aud_timelo;
  uint32 cmap_flag;
  uint32 cmap_cnt;
  uint32 color_cnt;
  uint32 color_retries;
  uint32 cmap_frame_num;
  ColorReg cmap[256];
  XA_CHDR  *chdr;
} XA_ANIM_SETUP;


typedef struct STRUCT_ACT_SETTER_HDR
{ 
 XA_ACTION *work;
 int32 xback,yback;
 int32 xpback,ypback; 
 XA_ACTION *back;
 int32 xface,yface;
 int32 xpface,ypface;
 int32 depth;
 XA_ACTION *face;
 struct STRUCT_ACT_SETTER_HDR *next;
} ACT_SETTER_HDR;

typedef struct
{ 
  int32 xpos;
  int32 ypos;
  int32 xsize;
  int32 ysize;
  int32 psize;
  uint8 *clip;
  uint8 *data; 
} ACT_MAPPED_HDR;

typedef struct
{ 
  int32 xpos;
  int32 ypos;
  int32 xsize;
  int32 ysize;
  int32 psize;
  int32 rbits;
  int32 gbits;
  int32 bbits;
  uint8 *clip;
  uint8 *data; 
} ACT_TRUE_HDR;

typedef struct
{ 
  int32 xpos;
  int32 ypos;
  int32 xsize;
  int32 ysize;
  int32 pk_size;
  uint8 *clip;
  uint8 data[4]; 
} ACT_PACKED_HDR;

typedef struct
{ 
 int32 xpos;
 int32 ypos;
 int32 xsize;
 int32 ysize;
 XImage *image;
 uint8 *clip_ptr;
} ACT_CLIP_HDR;

#define ACT_NOP		0x0000
#define ACT_DELAY	0x0001
#define ACT_IMAGE	0x0002
#define ACT_CMAP	0x0003
#define ACT_SIZE	0x0004
#define ACT_FADE	0x0005
#define ACT_CLIP	0x0006
#define ACT_PIXMAP	0x0007
#define ACT_SETTER	0x0008
#define ACT_RAW		0x0009
#define ACT_PACKED	0x000A
#define ACT_DISP	0x000B
#define ACT_MAPPED	0x000C
#define ACT_TRUE	0x000D
#define ACT_PIXMAPS	0x000E
#define ACT_IMAGES	0x000F
#define ACT_CYCLE	0x0010
#define ACT_DELTA	0x0011
#define ACT_APTR 	0x0012
#define ACT_BEG_LP	0x0100
#define ACT_END_LP	0x0101
#define ACT_JMP2END	0x0102

/* flags */
extern int32 xa_verbose;
extern int32 xa_debug;
extern int32 xa_jiffy_flag;
extern int32 xa_buffer_flag;
extern int32 xa_file_flag;
extern int32 xa_optimize_flag;
extern int32 xa_use_depth_flag;

#define DEBUG_LEVEL1   if (xa_debug >= 1) 
#define DEBUG_LEVEL2   if (xa_debug >= 2) 
#define DEBUG_LEVEL3   if (xa_debug >= 3) 
#define DEBUG_LEVEL4   if (xa_debug >= 4) 
#define DEBUG_LEVEL5   if (xa_debug >= 5) 

#define XA_CMAP_SIZE 256
#define XA_HMAP_SIZE  64
#define XA_HMAP6_SIZE 16
#define XA_HMAP8_SIZE 64

/* CMAP function flags for ACT_Setup_CMAP */
#define CMAP_DIRECT		0x000000
#define CMAP_ALLOW_REMAP	0x000001


#define CMAP_SCALE4 4369
#define CMAP_SCALE5 2114
#define CMAP_SCALE6 1040
#define CMAP_SCALE8  257
#define CMAP_SCALE9  128
#define CMAP_SCALE10  64
#define CMAP_SCALE11  32
#define CMAP_SCALE13   8
extern uint32 cmap_scale[17];
extern int32 cmap_true_to_332;
extern int32 cmap_true_to_gray;
extern int32 cmap_true_to_1st;
extern int32 cmap_true_to_all;
extern int32 cmap_true_map_flag;
extern int32 cmap_dither_type;

extern uint32 cmap_sample_cnt;  /* how many times to sample colors for +CF4 */
extern uint32 cmap_color_func;
extern int32 cmap_luma_sort;
extern int32 cmap_map_to_1st_flag;
extern int32 cmap_play_nice;
extern XA_CHDR *xa_chdr_start;
extern XA_CHDR *xa_chdr_cur;
extern XA_CHDR *xa_chdr_now;
extern ColorReg *xa_cmap;
extern uint32 xa_cmap_size;
extern uint32 xa_cmap_off;
extern int32 cmap_median_type;
extern int16 cmap_floyd_error;
extern int32 cmap_map_to_one_flag;
extern int32 pod_max_colors;
extern int32 cmap_hist_flag;
extern int32 cmap_median_bits;
extern uint32 cmap_cache_size;
extern uint32 cmap_cache_bits;
extern uint32 cmap_cache_rmask;
extern uint32 cmap_cache_gmask;
extern uint32 cmap_cache_bmask;
extern uint16 *cmap_cache,*cmap_cache2;
extern XA_CHDR *cmap_cache_chdr;

extern uint32 xa_gamma_flag;
extern uint16 xa_gamma_adj[];


extern uint32 xa_r_shift,xa_g_shift,xa_b_shift;
extern uint32 xa_r_mask,xa_g_mask,xa_b_mask;
extern uint32 xa_gray_bits,xa_gray_shift;

#define XA_HAM_MAP_INVALID 0xffffffff
#define XA_HAM6_CACHE_SIZE   4096
#define XA_HAM8_CACHE_SIZE 262144

typedef struct
{
 uint32 rate;	/* rate at which to cycle colors in milliseconds */
 uint32 flags;   /* flags */
 uint32 size;    /* size of color array */
 uint32 curpos;  /* curpos in array */
 uint8 data[4];  /* array of cmap pixel values to cycle */
} ACT_CYCLE_HDR;

/* ACT_CYCLE flags values */
/* NOTE: ACTIVE isn't currently checked. It's assumed to be active or
 *       else it shouldn't have been created by anim reader. */
#define ACT_CYCLE_ACTIVE  0x01
#define ACT_CYCLE_REVERSE 0x02
#define ACT_CYCLE_STARTED 0x80000000

extern void TheEnd();
extern void TheEnd1();
extern void XAnim_Looped();
extern void Cycle_It();
extern uint32 X11_Get_True_Color();
extern uint32 X11_Get_Line_Size();


/* AUDIO STUFF */

#define XA_AUDIO_STOPPED 0
#define XA_AUDIO_PREPPED 1
#define XA_AUDIO_STARTED 2
#define XA_AUDIO_NICHTDA 3

#define XA_AUDIO_OK   0
#define XA_AUDIO_UNK  1
#define XA_AUDIO_NONE 2
#define XA_AUDIO_ERR  3

#define XA_AUDIO_MAXVOL  100
#define XA_AUDIO_MINVOL  0

extern uint32 xa_audio_enable;


/* 
 * Useful Macros 
 */

#define CMAP_GET_GRAY(r,g,b,scale) \
( ((scale)*((r)*11+(g)*16+(b)*5) ) >> xa_gray_shift)

#define CMAP_GET_332(r,g,b,scale) ( \
( (((r)*(scale)) & xa_r_mask) >> xa_r_shift) | \
( (((g)*(scale)) & xa_g_mask) >> xa_g_shift) | \
( (((b)*(scale)) & xa_b_mask) >> xa_b_shift) )

#define X11_Get_Bitmap_Width(x) \
  ( ((x + x11_bitmap_unit - 1)/x11_bitmap_unit) * x11_bitmap_unit )

#define X11_Make_Pixel(p)  (x11_cmap_type == 0)?(p): \
		( (((p)<<24)|((p)<<16)|((p)<<8)|(p)) & x11_depth_mask )

#define XA_PIC_SIZE(p) ( (xa_use_depth_flag==xaTRUE)?((p) * x11_bytes_pixel): \
		(p) )

#define XA_GET_TIME(t) ( (xa_jiffy_flag)?(xa_jiffy_flag):(t) )

#define XA_MEMSET(p,d,size) \
{ if (x11_bytes_pixel==4) { uint32 _sz=(size); \
    uint32 *_lp=(uint32 *)p; while(_sz--) *_lp++ = (uint32)(d); } \
  else if (x11_bytes_pixel==2) { uint32 _sz=(size); \
    uint16 *_sp=(uint16 *)p; while(_sz--) *_sp++ = (uint16)(d); } \
  else { memset(p,d,size); } \
}

#define XA_REALLOC(p,cur_size,new_size) { if (new_size > cur_size) \
{ char *_tmp; \
  if (p == 0) _tmp=(char *)malloc(new_size); \
  else _tmp=(char *)realloc(p,new_size); \
  if (_tmp == 0) TheEnd1("XA_Realloc: malloc err"); \
  p = _tmp; cur_size = new_size; } \
} 

#define FREE(_p,_q) free(_p)
/* For Debug
#include <errno.h>
#define FREE(_p,_q) { int ret; ret = free(_p); \
fprintf(stderr,"FREE %lx %lx ret=%ld err=%ld\n",_p,_q,ret,errno); }
*/


/* REV 1 */
typedef struct
{
  uint32 cmd;			/* decode or query */
  uint32 skip_flag;		/* skip_flag */
  uint32 imagex,imagey;	/* Image Buffer Size */
  uint32 imaged; 		/* Image depth */
  XA_CHDR *chdr;		/* Color Map Header */
  uint32 map_flag;		/* remap image? */
  uint32 *map;			/* map to use */
  uint32 xs,ys;		/* pos of changed area */
  uint32 xe,ye;		/* size of change area */
  uint32 special;		/* Special Info */
  void *extra;			/* Decompression specific info */
} XA_DEC_INFO;

#include "xa_dec2.h"



