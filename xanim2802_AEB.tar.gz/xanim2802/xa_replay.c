
/*
 * xa_replay.c
 *
 * Copyright (C) 1995-1999,2000 by Mark Podlipec. 
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 * 
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */

/*******************************
 * Revision
 *
 *
 ********************************/


#include "xa_replay.h" 

uint32 ARM_Read_File();
ARM_FRAME *ARM_Add_Frame();
void ARM_Free_Frame_List();
void ACT_Setup_Delta();
uint32 ARM_Read_Header();
uint32 ARM_Read_Index();
void ARM_Read_Frame();
uint32 ARM_Get_Length();

void ARM_Free_Stuff();
void ARM_Init_Tables();


uint32 ARM_Decode_MLINES();


/* CODEC ROUTINES */
extern void yuv_to_rgb();
extern void XA_Gen_YUV_Tabs();
extern uint32 XA_RGB24_To_CLR32();

void CMAP_Cache_Clear();
void CMAP_Cache_Init();

extern XA_ACTION *ACT_Get_Action();
extern XA_CHDR *ACT_Get_CMAP();
extern XA_CHDR *CMAP_Create_332();
extern XA_CHDR *CMAP_Create_422();
extern XA_CHDR *CMAP_Create_Gray();
extern void ACT_Add_CHDR_To_Action();
extern void ACT_Setup_Mapped();
extern void ACT_Get_CCMAP();
extern XA_CHDR *CMAP_Create_CHDR_From_True();
extern uint32 CMAP_Find_Closest();
extern uint8 *UTIL_RGB_To_FS_Map();
extern uint8 *UTIL_RGB_To_Map();

extern void  UTIL_FPS_2_Time();
extern XA_ANIM_SETUP *XA_Get_Anim_Setup();
extern void XA_Add_Func_To_Free_Chain();
extern void XA_Free_Anim_Setup();
extern uint32 XA_find_str();

uint8 *ARM_prev_buff = 0;
uint32 ARM_prev_buff_size = 0;
int32 *ARM_MOVL_X = 0;
int32 *ARM_MOVL_Y = 0;

uint32 arm_audio_attempt;
uint32 arm_audio_type;
uint32 arm_audio_freq;
uint32 arm_audio_chans;
uint32 arm_audio_bps;
uint32 XA_Add_Sound();


uint32 arm_frame_cnt;
ARM_FRAME *arm_frame_start,*arm_frame_cur;

ARM_FRAME *ARM_Add_Frame(time,timelo,act)
uint32 time,timelo;
XA_ACTION *act;
{
  ARM_FRAME *fframe;
 
  fframe = (ARM_FRAME *) malloc(sizeof(ARM_FRAME));
  if (fframe == 0) TheEnd1("ARM_Add_Frame: malloc err");
 
  fframe->time   = time;
  fframe->timelo = timelo;
  fframe->act = act;
  fframe->next = 0;
 
  if (arm_frame_start == 0) arm_frame_start = fframe;
  else arm_frame_cur->next = fframe;
 
  arm_frame_cur = fframe;
  arm_frame_cnt++;
  return(fframe);
}

void ARM_Free_Frame_List(fframes)
ARM_FRAME *fframes;
{
  ARM_FRAME *ftmp;
  while(fframes != 0)
  {
    ftmp = fframes;
    fframes = fframes->next;
    FREE(ftmp,0xA000);
  }
}


uint32 ARM_Read_File(fname,anim_hdr,audio_attempt)
char *fname;
XA_ANIM_HDR *anim_hdr;
uint32 audio_attempt;	/* xaTRUE if audio is to be attempted */
{ XA_INPUT *xin = anim_hdr->xin;
  int32 i,t_time;
  uint32 t_timelo;
  XA_ANIM_SETUP *arm;
  ARM_HDR   arm_hdr;
 

  arm = XA_Get_Anim_Setup();
  arm->vid_time = XA_GET_TIME( 100 ); /* default */

  arm_frame_cnt		= 0;
  arm_frame_start	= 0;
  arm_frame_cur		= 0;
  arm_audio_attempt	= audio_attempt;


  if (ARM_Read_Header(anim_hdr,xin,arm,&arm_hdr) == xaFALSE)
  {
    fprintf(stderr,"ARM: read header error\n");
    xin->Close_File(xin);
    return(xaFALSE);
  }

  if (ARM_Read_Index(xin,anim_hdr,arm,&arm_hdr)==xaFALSE) return(xaFALSE);

  if (xa_verbose) 
  {
    fprintf(stderr,"ARM %dx%dx%d frames %d\n",
		arm->imagex,arm->imagey,arm->imagec,arm_frame_cnt);
  }
  if (arm_frame_cnt == 0)
  { 
    fprintf(stderr,"ARM: No supported video frames exist in this file.\n");
    return(xaFALSE);
  }

  anim_hdr->frame_lst = (XA_FRAME *)
				malloc( sizeof(XA_FRAME) * (arm_frame_cnt+1));
  if (anim_hdr->frame_lst == NULL) TheEnd1("ARM_Read_File: frame malloc err");

  arm_frame_cur = arm_frame_start;
  i = 0;
  t_time = 0;
  t_timelo = 0;
  while(arm_frame_cur != 0)
  {
    if (i > arm_frame_cnt)
    {
      fprintf(stderr,"ARM_Read_Anim: frame inconsistency %d %d\n",
                i,arm_frame_cnt);
      break;
    }
    anim_hdr->frame_lst[i].time_dur = arm_frame_cur->time;
    anim_hdr->frame_lst[i].zztime = t_time;
    t_time += arm_frame_cur->time;
    t_timelo += arm_frame_cur->timelo;
    while(t_timelo > (1<<24)) {t_time++; t_timelo -= (1<<24);}
    anim_hdr->frame_lst[i].act = arm_frame_cur->act;
    arm_frame_cur = arm_frame_cur->next;
    i++;
  }
  anim_hdr->imagex = arm->imagex;
  anim_hdr->imagey = arm->imagey;
  anim_hdr->imagec = arm->imagec;
  anim_hdr->imaged = 8; /* nop */
  anim_hdr->frame_lst[i].time_dur = 0;
  anim_hdr->frame_lst[i].zztime = -1;
  anim_hdr->frame_lst[i].act  = 0;
  anim_hdr->loop_frame = 0;
  if (!(xin->load_flag & XA_IN_LOAD_BUF)) anim_hdr->anim_flags |= ANIM_SNG_BUF;
  if (xin->load_flag & XA_IN_LOAD_FILE) anim_hdr->anim_flags |= ANIM_USE_FILE;
  anim_hdr->anim_flags |= ANIM_FULL_IM;
  anim_hdr->max_fvid_size = arm->max_fvid_size;
  anim_hdr->max_faud_size = arm->max_faud_size;
  anim_hdr->fname = anim_hdr->name;
  if (i > 0) 
  {
    anim_hdr->last_frame = i - 1;
    anim_hdr->total_time = anim_hdr->frame_lst[i-1].zztime
				+ anim_hdr->frame_lst[i-1].time_dur;
  }
  else
  {
    anim_hdr->last_frame = 0;
    anim_hdr->total_time = 0;
  }
  ARM_Free_Frame_List(arm_frame_start);
  XA_Free_Anim_Setup(arm);
  return(xaTRUE);
} /* end of read file */


#define ARM_MAX_LINE 256
char arm_line[ARM_MAX_LINE];

uint32 ARM_Read_Line(xin,ptr)
XA_INPUT *xin;
char *ptr;
{ int i = 0;
  while( !xin->At_EOF(xin,-1) )
  { int d = xin->Read_U8(xin);
    if (d >= 0)
    { ptr[i] = d; i++;
      if (i  >= ARM_MAX_LINE) return(xaFALSE);
      if ( (d == 0x0a) || (d == 0x0d) ) 
	{ ptr[i] = 0; 
	  DEBUG_LEVEL1 fprintf(stderr,"LINE: %s",ptr);
          return(xaTRUE); 
	}
    }
    else return(xaFALSE); 
  }
  return(xaFALSE);
}

uint32 ARM_Read_Header(anim_hdr,xin,arm,arm_hdr)
XA_ANIM_HDR *anim_hdr;
XA_INPUT *xin;
XA_ANIM_SETUP *arm;
ARM_HDR *arm_hdr;
{ double tmpf;

  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* ARMovie */
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* name */
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* date/copyright */
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* author/etc */
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* video format */
  if (arm_line[0] == '1') arm_hdr->vid_codec = ARM_VIDEO_MOVL_RGB;
  else
  { fprintf(stderr,"ARM: Unsupported Video Type: %s,",arm_line);
    arm_hdr->vid_codec = ARM_VIDEO_UNK;
  }

  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);	/* width */
    tmpf = atof(arm_line);  arm_hdr->width	 = (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);	/* height */
    tmpf = atof(arm_line);  arm_hdr->height	= (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);	/* depth */
    tmpf = atof(arm_line);  arm_hdr->depth	= (int32)tmpf;

/* Check Video Precision Line for modifiers */
    if (arm_hdr->vid_codec == ARM_VIDEO_MOVL_RGB)
    {
       if (   (XA_find_str(arm_line,"yuv") == xaTRUE) 
           || (XA_find_str(arm_line,"YUV") == xaTRUE) )
		arm_hdr->vid_codec = ARM_VIDEO_MOVL_YUV;
    }

  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);	/* fps */
    arm_hdr->fps = atof(arm_line);
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /*audio format */
    if (arm_audio_attempt == xaTRUE)
    {
      if (arm_line[0] == '0') 
      {
	arm_hdr->aud_codec = ARM_AUDIO_NONE;
	arm_audio_attempt = xaFALSE;
      }
      else if (arm_line[0] == '1') 
      { 
	arm_hdr->aud_codec = ARM_AUDIO_FORM1;
      }
      else
      { 
	fprintf(stderr,"ARM: Unsupported Audio Type: %s\n",arm_line);
	arm_hdr->aud_codec = ARM_AUDIO_UNK;
	arm_audio_attempt = xaFALSE;
      }
    }
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* audio freq */
     /* NOTE: this can be fraction HZ - eventually support this or us */
    tmpf = atof(arm_line);
    { static unsigned char us[3] = { 0xB5, 0x73, 0x00 };
      if (XA_find_str(arm_line,us)==xaTRUE)
      { double freq = (1000000.0 / tmpf) + 0.5;
        arm_hdr->aud_freq = (int32)freq;
      }
      else arm_hdr->aud_freq = (int32)tmpf;
    }
     
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* audio chans */
    tmpf = atof(arm_line);  arm_hdr->aud_chans	= (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);  /* audio prec */
    tmpf = atof(arm_line);  arm_hdr->aud_prec	= (int32)tmpf;

    /* Check Audio Precision Line for modifiers */
    if (arm_audio_attempt == xaTRUE)
    {
      arm_audio_freq  = arm_hdr->aud_freq;
      arm_audio_chans = arm_hdr->aud_chans;
      if (arm_hdr->aud_prec == 8) arm_audio_bps = 1;
      else if (arm_hdr->aud_prec == 16) arm_audio_bps = 2;
      else arm_audio_bps = 0;
      if ( XA_find_str(arm_line,"linear") == xaTRUE) 
      {
        if (xa_verbose==xaTRUE) 
		fprintf(stderr,"AUDIO: Signed %dHz chans: %d  bits: %d\n",
			arm_audio_freq,arm_audio_chans,arm_hdr->aud_prec);
        arm_audio_type = XA_AUDIO_SIGNED;  /* NOTE: little endian */
      } 
      else if ( XA_find_str(arm_line,"logarithmic") == xaTRUE) 
      {
        if (xa_verbose==xaTRUE) 
	    fprintf(stderr,"AUDIO: LOGARITHMIC %dHz chans: %d bits: %d\n",
			arm_audio_freq,arm_audio_chans,arm_hdr->aud_prec);
        arm_audio_type = XA_AUDIO_ARMLAW;  /* NOTE: little endian */
      } 
      else arm_audio_type = XA_AUDIO_INVALID;
      /* paranoia */
      if ( (arm_audio_chans > 2) || (arm_audio_chans == 0) )
					arm_audio_type = XA_AUDIO_INVALID;
      if ( (arm_audio_bps > 2) || (arm_audio_bps == 0) )
					arm_audio_type = XA_AUDIO_INVALID;

      /* warning and final modifications */
      if (arm_audio_type == XA_AUDIO_INVALID)
      {
        if (arm_audio_attempt == xaTRUE) 
	  fprintf(stderr,"ARM: Audio Type unsupported %d \n",
						arm_hdr->aud_codec);
        arm_audio_attempt = xaFALSE;
      }
      else
      {
        if (arm_audio_chans == 2) arm_audio_type |= XA_AUDIO_STEREO_MSK;
        if (arm_audio_bps == 2) arm_audio_type |= XA_AUDIO_BPS_2_MSK;
      }
    }

  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE);/*frames perchnk*/
    tmpf = atof(arm_line);  arm_hdr->fp_chunk	= (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /* chunk cnt */
    tmpf = atof(arm_line);  arm_hdr->chunk_cnt	= (int32)tmpf;

    /* This is necessary so +CF4 will function correctly */
    arm->cmap_frame_num  = (arm_hdr->chunk_cnt * arm_hdr->fp_chunk) 
							/ cmap_sample_cnt;

  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /*ev chunk sz */
    tmpf = atof(arm_line);  arm_hdr->ev_chk_size	= (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /*od chunk sz */
    tmpf = atof(arm_line);  arm_hdr->od_chk_size	= (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /* idx offset */
    tmpf = atof(arm_line);  arm_hdr->idx_offset	= (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /*sprite offset*/
    tmpf = atof(arm_line);  arm_hdr->sprite_off	= (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /*sprite size*/
    tmpf = atof(arm_line);  arm_hdr->sprite_size = (int32)tmpf;
  if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /*key  offset */
    tmpf = atof(arm_line);  arm_hdr->key_offset	= (int32)tmpf;
  

  UTIL_FPS_2_Time(arm, arm_hdr->fps );

/*
  switch(arm_hdr->aud_codec)
  {
  }
*/

  arm->depth  = arm_hdr->depth;
  arm->imagex = arm_hdr->width;
  arm->imagey = arm_hdr->height;
  XA_Gen_YUV_Tabs(anim_hdr);
  ARM_Init_Tables(anim_hdr,arm->imagex,arm->imagey);

if (xa_verbose)
{
  fprintf(stderr,"ARM: %dx%dx%x\n",arm->imagex,arm->imagey,arm->depth);
}

  if (   (cmap_true_map_flag == xaFALSE) /* depth 16 and not true_map */
      || (!(xin->load_flag & XA_IN_LOAD_BUF)) )
  {
     if (cmap_true_to_332 == xaTRUE)
             arm->chdr = CMAP_Create_332(arm->cmap,&arm->imagec);
     else    arm->chdr = CMAP_Create_Gray(arm->cmap,&arm->imagec);
  }
  if ( (arm->pic==0) && (xin->load_flag & XA_IN_LOAD_BUF))
  {
    arm->pic_size = arm->imagex * arm->imagey;
    if ( (cmap_true_map_flag == xaTRUE) && (arm->depth > 8) )
                arm->pic = (uint8 *) malloc( 3 * arm->pic_size );
    else arm->pic = (uint8 *) malloc( XA_PIC_SIZE(arm->pic_size) );
    if (arm->pic == 0) TheEnd1("ARM_Buffer_Action: malloc failed");
  }
  return(xaTRUE);
}


uint32 ARM_Read_Index(xin,anim_hdr,arm,arm_hdr)
XA_INPUT *xin;
XA_ANIM_HDR *anim_hdr;
XA_ANIM_SETUP *arm;
ARM_HDR *arm_hdr;
{ uint32 idx_cnt = arm_hdr->chunk_cnt;
  uint32 i,*idx_off,*idx_vsize,*idx_asize;

  idx_off = (uint32 *)malloc( (idx_cnt + 2) * sizeof(uint32) );
  idx_vsize = (uint32 *)malloc( (idx_cnt + 2) * sizeof(uint32) );
  idx_asize = (uint32 *)malloc( (idx_cnt + 2) * sizeof(uint32) );

  DEBUG_LEVEL2 fprintf(stderr,"    idx offset  %08x\n",arm_hdr->idx_offset);
  xin->Seek_FPos(xin,arm_hdr->idx_offset,0);
  /* Go Through Chunks */
  for(i=0; i<=idx_cnt; i++)
  { int32 off, vid_size, aud_size, ret;
    if (ARM_Read_Line(xin,arm_line) == xaFALSE) return(xaFALSE); /*chunk count*/
    ret = sscanf(arm_line,"%d,%d;%d",&off,&vid_size,&aud_size);
    DEBUG_LEVEL1
    {
     fprintf(stderr,"  (%d) %d) off %08x  vid %08x  aud %08x\n",ret,i,
						off,vid_size,aud_size);
    }
    idx_off[i] = off;
    idx_vsize[i] = vid_size;
    idx_asize[i] = aud_size;

  } /* end of for */


  for(i=0; i<=idx_cnt; i++)
  { uint32 j; uint32 tot_dsize = 0;

DEBUG_LEVEL1 fprintf(stderr," idx %d) chunks %d\n",i, arm_hdr->fp_chunk);
    /* VIDEO */
    xin->Seek_FPos(xin,idx_off[i],0);
    for(j=0; j < arm_hdr->fp_chunk; j++)
    { uint32 fpos,dsize;
      fpos = xin->Get_FPos(xin);		/* save xin position */
      dsize = ARM_Get_Length(xin,arm);	/* find length of delta */
      xin->Seek_FPos(xin,fpos,0);		/* return to xin position */
      ARM_Read_Frame(xin,anim_hdr,arm,arm_hdr,dsize);
      tot_dsize += dsize;
    }

    /* AUDIO */
    if (arm_audio_attempt == xaTRUE) 
    { int32 ret, snd_size = (int32)idx_asize[i];
      uint32 snd_off = idx_off[i] + idx_vsize[i];
      if (xin->load_flag & XA_IN_LOAD_FILE)
      { int32 rets;
	rets = XA_Add_Sound(anim_hdr,0,arm_audio_type, snd_off,
				arm_audio_freq, snd_size, 
				&arm->aud_time,&arm->aud_timelo, 0, 0);
	if (rets==xaFALSE) arm_audio_attempt = xaFALSE;
	if (snd_size > arm->max_faud_size) arm->max_faud_size = snd_size;
      }
      else
      { uint8 *snd = (uint8 *)malloc(snd_size);
	if (snd==0) TheEnd1("ARM: snd malloc err");
        xin->Seek_FPos(xin,snd_off,0); /* seek to audio info */
	ret = xin->Read_Block(xin, snd, snd_size);
	if (ret < snd_size) fprintf(stderr,"ARM: snd rd err(size %x\n",snd_size);
	else
	{ int rets;
          /*NOTE: don't free snd */
	  rets = XA_Add_Sound(anim_hdr,snd,arm_audio_type, -1,
				arm_audio_freq, snd_size,
				&arm->aud_time, &arm->aud_timelo, 0, 0);
	  if (rets==xaFALSE) arm_audio_attempt = xaFALSE;
	}
      }
    } /* end of audio attempt */
  }
  free(idx_off);
  free(idx_vsize);
  free(idx_asize);
  return(xaTRUE);
}

/* Assuming xin is pointing to start of delta.
 * leaves xin just after end of delta.
 */
void ARM_Read_Frame(xin,anim_hdr,arm,arm_hdr,vsize)
XA_INPUT *xin;
XA_ANIM_HDR *anim_hdr;
XA_ANIM_SETUP *arm;
ARM_HDR *arm_hdr;
int32 vsize;
{ XA_ACTION *act;
  uint32 dlta_len = vsize;
  ACT_DLTA_HDR *dlta_hdr;

  act = ACT_Get_Action(anim_hdr,ACT_DELTA);
  if (xin->load_flag & XA_IN_LOAD_FILE)
  {
    dlta_hdr = (ACT_DLTA_HDR *) malloc(sizeof(ACT_DLTA_HDR));
    if (dlta_hdr == 0) TheEnd1("ARM: dlta malloc err");
    act->data = (uint8 *)dlta_hdr;
    dlta_hdr->flags = ACT_SNGL_BUF;
    dlta_hdr->fsize = dlta_len;
    dlta_hdr->fpos  = xin->Get_FPos(xin);
    if (dlta_len > arm->max_fvid_size) arm->max_fvid_size = dlta_len;
    xin->Seek_FPos(xin,dlta_len,1);
  }
  else
  { uint32 d; int32 ret;
    d = dlta_len + (sizeof(ACT_DLTA_HDR));
    dlta_hdr = (ACT_DLTA_HDR *) malloc( d );
    if (dlta_hdr == 0) TheEnd1("QT rle: malloc failed");
    act->data = (uint8 *)dlta_hdr;
    dlta_hdr->flags = ACT_SNGL_BUF | DLTA_DATA;
    dlta_hdr->fpos = 0; dlta_hdr->fsize = dlta_len;
    ret = xin->Read_Block(xin, dlta_hdr->data, dlta_len);
    if (ret < dlta_len) { fprintf(stderr,"ARM: read err\n"); return; }
  }
  ARM_Add_Frame(arm->vid_time,arm->vid_timelo,act);
  dlta_hdr->xpos = dlta_hdr->ypos = 0;
  dlta_hdr->xsize = arm->imagex;
  dlta_hdr->ysize = arm->imagey;
  dlta_hdr->special = 0;
  if (arm_hdr->vid_codec == ARM_VIDEO_MOVL_YUV)
		dlta_hdr->extra = (void *)(ARM_VIDEO_YUV);
  else		dlta_hdr->extra = (void *)(ARM_VIDEO_RGB);
  dlta_hdr->xapi_rev = 0x0001;
  dlta_hdr->delta = ARM_Decode_MLINES;
  ACT_Setup_Delta(arm,act,dlta_hdr,xin);
}



#define ARM_15YUV(pix,y,u,v) { \
  v = (pix >> 10) & 0x1f; u = (pix >> 5) & 0x1f; y = pix & 0x1f; \
  u ^= 0x10; v ^= 0x10; \
  y = (y << 3) | (y >> 2); u = (u << 3) | (u >> 2); v = (v << 3) | (v >> 2); \
} 

#define ARM_16YUV(pix,y,u,v) { \
  v = (pix >> 11) & 0x1f; u = (pix >> 6) & 0x1f; y = (pix >> 1) & 0x1f; \
  u ^= 0x10; v ^= 0x10; \
  y = (y << 3) | (y >> 2); u = (u << 3) | (u >> 2); v = (v << 3) | (v >> 2); \
}

#define ARM_GET_CODE(dp,code) {code = (*dp++); code |= (*dp++) << 8; }

uint32 ARM_Get_RGB_Pixel(pix,map_flag,map,chdr)
uint32 pix,map_flag,*map;
XA_CHDR *chdr;
{ uint32 r,g,b;
  r = (pix >> 10) & 0x1f; g = (pix >> 5) & 0x1f; b = pix & 0x1f;
  r = (r << 3) | (r >> 2); g = (g << 3) | (g >> 2); b = (b << 3) | (b >> 2);
  return( XA_RGB24_To_CLR32(r,g,b,map_flag,map,chdr) );
} 

uint32 ARM_Get_YUV_Pixel(pix,map_flag,map,chdr)
uint32 pix,map_flag,*map;
XA_CHDR *chdr;
{ uint32 y,u,v,r,g,b;
  v = (pix >> 10) & 0x1f; u = (pix >> 5) & 0x1f; y = pix & 0x1f;
  u ^= 0x10; v ^= 0x10;
  y = (y << 3) | (y >> 2); u = (u << 3) | (u >> 2); v = (v << 3) | (v >> 2);
  yuv_to_rgb(y,u,v,&r,&g,&b); 
  return( XA_RGB24_To_CLR32(r,g,b,map_flag,map,chdr) );
} 

uint32 ARM_Get_RGB_RGB(pix,ir,ig,ib)
uint32 pix;
uint32 *ir,*ig,*ib;
{ uint32 r,g,b;
  r = (pix >> 10) & 0x1f; g = (pix >> 5) & 0x1f; b = pix & 0x1f;
  r = (r << 3) | (r >> 2); g = (g << 3) | (g >> 2); b = (b << 3) | (b >> 2);
  *ir = r; *ig = g; *ib = b;
  return(1);
} 

uint32 ARM_Get_YUV_RGB(pix,ir,ig,ib)
uint32 pix;
uint32 *ir,*ig,*ib;
{ uint32 y,u,v;
  v = (pix >> 10) & 0x1f; u = (pix >> 5) & 0x1f; y = pix & 0x1f;
  u ^= 0x10; v ^= 0x10;
  y = (y << 3) | (y >> 2); u = (u << 3) | (u >> 2); v = (v << 3) | (v >> 2);
  yuv_to_rgb(y,u,v,ir,ig,ib); 
  return(1);
} 

/* TEST */
uint32
ARM_Decode_MLINES(image,delta,dsize,dec_info)
uint8 *image;         /* Image Buffer. */
uint8 *delta;         /* delta data. */
uint32 dsize;          /* delta size */
XA_DEC_INFO *dec_info;  /* Decoder Info Header */
{ uint32 imagex = dec_info->imagex;    uint32 imagey = dec_info->imagey;
  uint32 map_flag = dec_info->map_flag;        uint32 *map = dec_info->map;
  uint32 special = dec_info->special;          void *extra = dec_info->extra;
  XA_CHDR *chdr = dec_info->chdr;
  uint8 *dp = delta;
  uint32 special_flag = special & 0x0001;
  int32 i_cnt,im_size = imagex * imagey;
  uint32 code;
  uint8 *pptr = ARM_prev_buff;
  uint32 vid_type = (uint32)(extra);
  uint32 (*arm_get_pixel)();
  
  if (chdr) { if (chdr->new_chdr) chdr = chdr->new_chdr; }

  /* Need to copy previous image, since Temporal references it */
  { i_cnt  = im_size * ((special_flag)?(3):(x11_bytes_pixel));
    memcpy((char *)(pptr),(char *)(image),(i_cnt));
  }

/* */
  if (special)
  {
    if (vid_type == ARM_VIDEO_YUV) arm_get_pixel = ARM_Get_YUV_RGB;
    else arm_get_pixel = ARM_Get_RGB_RGB;
  }
  else
  {
    if (vid_type == ARM_VIDEO_YUV) arm_get_pixel = ARM_Get_YUV_Pixel;
    else arm_get_pixel = ARM_Get_RGB_Pixel;
  }

  i_cnt = 0;

 if (special)
 { uint8 *iptr = image;
  while(i_cnt < im_size)
  { ARM_GET_CODE(dp,code); 
    if (code & 0x01)
    { uint32 test,cnt;
      if (code == 0xe601) { i_cnt = im_size; break; }	/* End of Frame */
      test = code >> 7;		cnt = ((code >> 1) & 0x3f) + 2;
      if (test < 0x1cc)			/* Temporal/Spatial */
      { uint8 *isp;
        if (test < 0x120) { isp = pptr; isp += (3 * i_cnt); } /* temporal */
	else isp = iptr; /* spatial */
	isp += 3 * (ARM_MOVL_X[test] + (ARM_MOVL_Y[test] * imagex));
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) { *iptr++ = *isp++; *iptr++ = *isp++; *iptr++ = *isp++; }
      }
      else if (test >= 0x1e0)
      { cnt = ((code >> 1) & 0x3ff) + 1;
	if (test >=0x1f0)				/* New N Pixels */
	{ int32  arm_bcnt   = ((((cnt * 15) + 15) >> 4) << 1); /* dp bytes */
	  int32  arm_b_bnum = 0;	uint32 arm_b_bbuf = 0;
	  DEBUG_LEVEL1  fprintf(stderr,"New N Pixels %d\n",cnt);
	  i_cnt += cnt; if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	  while(cnt--)  /* pixels */
	  { uint32 r,g,b; /* Little Endian */
	    while(arm_b_bnum < 15) { arm_b_bbuf |=  (*dp++) << arm_b_bnum;
						arm_b_bnum += 8; arm_bcnt--; }
	    arm_get_pixel(arm_b_bbuf,&r,&g,&b);
	    *iptr++ = (uint8)r; *iptr++ = (uint8)g; *iptr++ = (uint8)b;
	    arm_b_bbuf >>= 15;		arm_b_bnum -= 15;
	  }
	  while(arm_bcnt--) dp++; /* left overs */
	} else { iptr += (3 * cnt);  i_cnt += cnt; }		/* Copy/Skip */
      }
      else if (test == 0x1cc)
      { uint32 r,g,b,pixel;
	ARM_GET_CODE(dp,pixel);
	arm_get_pixel(pixel,&r,&g,&b);
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) { *iptr++ = (uint8)r; 
				*iptr++ = (uint8)g; *iptr++ = (uint8)b; }
      } else fprintf(stderr,"ARM decode ERROR: %04x\n",code);
    }
    else			/* New Pixel */
    { uint32 r,g,b; arm_get_pixel((code>>1),&r,&g,&b);  i_cnt++;
      *iptr++ = (uint8)r; *iptr++ = (uint8)g; *iptr++ = (uint8)b;
    }
  } 
 }
 else if ( (x11_bytes_pixel==1) || (map_flag == xaFALSE) )
 { uint8 *iptr = image;
  while(i_cnt < im_size)
  { ARM_GET_CODE(dp,code); 
    if (code & 0x01)
    { uint32 test,cnt;
      if (code == 0xe601) { i_cnt = im_size; break; }	/* End of Frame */
      test = code >> 7;		cnt = ((code >> 1) & 0x3f) + 2;
      if (test < 0x1cc)			/* Temporal/Spatial */
      { uint8 *isp;
        if (test < 0x120) { isp = pptr; isp += i_cnt; } /* temporal */
	else isp = iptr; /* spatial */
	isp += (ARM_MOVL_X[test] + (ARM_MOVL_Y[test] * imagex));
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) *iptr++ = *isp++;
      }
      else if (test >= 0x1e0)
      { cnt = ((code >> 1) & 0x3ff) + 1;
	if (test >=0x1f0)				/* New N Pixels */
	{ int32  arm_bcnt   = ((((cnt * 15) + 15) >> 4) << 1); /* dp bytes */
	  int32  arm_b_bnum = 0;	uint32 arm_b_bbuf = 0;
	  DEBUG_LEVEL1  fprintf(stderr,"New N Pixels %d\n",cnt);
	  i_cnt += cnt; if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	  while(cnt--)  /* pixels */
	  { /* Little Endian */
	    while(arm_b_bnum < 15) { arm_b_bbuf |=  (*dp++) << arm_b_bnum;
						arm_b_bnum += 8; arm_bcnt--; }
	    *iptr++ = (uint8)arm_get_pixel(arm_b_bbuf,map_flag,map,chdr);
	    arm_b_bbuf >>= 15;		arm_b_bnum -= 15;
	  }
	  while(arm_bcnt--) dp++; /* left overs */
	} else { iptr += cnt;  i_cnt += cnt; }		/* Copy/Skip */
      }
      else if (test == 0x1cc)
      { uint32 pixel; uint8 d;
	ARM_GET_CODE(dp,pixel);
	d = (uint8)arm_get_pixel(pixel,map_flag,map,chdr);
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) *iptr++ = d;
      } else fprintf(stderr,"ARM decode ERROR: %04x\n",code);
    }
    else			/* New Pixel */
    { *iptr++ = (uint8)arm_get_pixel((code>>1),map_flag,map,chdr);  i_cnt++; }
  } 
 } /* end of byte 1 */
 else if (x11_bytes_pixel==4)
 { uint32 *iptr = (uint32 *)image;
  while(i_cnt < im_size)
  { ARM_GET_CODE(dp,code); 
    if (code & 0x01)
    { uint32 test,cnt;
      if (code == 0xe601) { i_cnt = im_size; break; }	/* End of Frame */
      test = code >> 7;		cnt = ((code >> 1) & 0x3f) + 2;
      if (test < 0x1cc)			/* Temporal/Spatial */
      { uint32 *isp;
        if (test < 0x120) { isp = (uint32 *)pptr; isp += i_cnt; }/*temporal */
	else isp = (uint32 *)iptr; /* spatial */
	isp += (ARM_MOVL_X[test] + (ARM_MOVL_Y[test] * imagex));
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) *iptr++ = *isp++;
      }
      else if (test >= 0x1e0)
      { cnt = ((code >> 1) & 0x3ff) + 1;
	if (test >=0x1f0)				/* New N Pixels */
	{ int32  arm_bcnt   = ((((cnt * 15) + 15) >> 4) << 1); /* dp bytes */
	  int32  arm_b_bnum = 0;	uint32 arm_b_bbuf = 0;
	  DEBUG_LEVEL1  fprintf(stderr,"New N Pixels %d\n",cnt);
	  i_cnt += cnt; if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	  while(cnt--)  /* pixels */
	  { /* Little Endian */
	    while(arm_b_bnum < 15) { arm_b_bbuf |=  (*dp++) << arm_b_bnum;
						arm_b_bnum += 8; arm_bcnt--; }
	    *iptr++ = (uint32)arm_get_pixel(arm_b_bbuf,map_flag,map,chdr);
	    arm_b_bbuf >>= 15;		arm_b_bnum -= 15;
	  }
	  while(arm_bcnt--) dp++; /* left overs */
	} else { iptr += cnt;  i_cnt += cnt; }		/* Copy/Skip */
      }
      else if (test == 0x1cc)
      { uint32 pixel; uint32 d;
	ARM_GET_CODE(dp,pixel);
	d = (uint32)arm_get_pixel(pixel,map_flag,map,chdr);
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) *iptr++ = d;
      } else fprintf(stderr,"ARM decode ERROR: %04x\n",code);
    }
    else			/* New Pixel */
    { *iptr++ = (uint32)arm_get_pixel((code>>1),map_flag,map,chdr);  i_cnt++; }
  } 
 } /* end of byte 4 */
 else /* if (x11_bytes_pixel==2) */
 { uint16 *iptr = (uint16 *)image;
  while(i_cnt < im_size)
  { ARM_GET_CODE(dp,code); 
    if (code & 0x01)
    { uint32 test,cnt;
      if (code == 0xe601) { i_cnt = im_size; break; }	/* End of Frame */
      test = code >> 7;		cnt = ((code >> 1) & 0x3f) + 2;
      if (test < 0x1cc)			/* Temporal/Spatial */
      { uint16 *isp;
        if (test < 0x120) { isp = (uint16 *)pptr; isp += i_cnt; }/*temporal */
	else isp = (uint16 *)iptr; /* spatial */
	isp += (ARM_MOVL_X[test] + (ARM_MOVL_Y[test] * imagex));
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) *iptr++ = *isp++;
      }
      else if (test >= 0x1e0)
      { cnt = ((code >> 1) & 0x3ff) + 1;
	if (test >=0x1f0)				/* New N Pixels */
	{ int32  arm_bcnt   = ((((cnt * 15) + 15) >> 4) << 1); /* dp bytes */
	  int32  arm_b_bnum = 0;	uint32 arm_b_bbuf = 0;
	  DEBUG_LEVEL1  fprintf(stderr,"New N Pixels %d\n",cnt);
	  i_cnt += cnt; if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	  while(cnt--)  /* pixels */
	  { /* Little Endian */
	    while(arm_b_bnum < 15) { arm_b_bbuf |=  (*dp++) << arm_b_bnum;
						arm_b_bnum += 8; arm_bcnt--; }
	    *iptr++ = (uint16)arm_get_pixel(arm_b_bbuf,map_flag,map,chdr);
	    arm_b_bbuf >>= 15;		arm_b_bnum -= 15;
	  }
	  while(arm_bcnt--) dp++; /* left overs */
	} else { iptr += cnt;  i_cnt += cnt; }		/* Copy/Skip */
      }
      else if (test == 0x1cc)
      { uint32 pixel; uint16 d;
	ARM_GET_CODE(dp,pixel);
	d = (uint16)arm_get_pixel(pixel,map_flag,map,chdr);
	i_cnt += cnt;	if (i_cnt >= im_size) cnt -= (i_cnt - im_size);
	while(cnt--) *iptr++ = d;
      } else fprintf(stderr,"ARM decode ERROR: %04x\n",code);
    }
    else			/* New Pixel */
    { *iptr++ = (uint16)arm_get_pixel((code>>1),map_flag,map,chdr); i_cnt++; }
  } 
 } /* end of byte 2 */

  dec_info->xs = dec_info->ys = 0; dec_info->xe = imagex; dec_info->ye = imagey;
  if (map_flag==xaTRUE) return(ACT_DLTA_MAPD);
  else return(ACT_DLTA_NORM);
}


uint32 ARM_Get_Length(xin,arm)
XA_INPUT *xin;
XA_ANIM_SETUP *arm;
{ uint32 d_cnt = 0;
  int32 i = arm->imagex * arm->imagey;
  uint32 code;

  while(i > 0)
  {
    if ( xin->At_EOF(xin,-1) ) return(0);
    code = xin->Read_LSB_U16(xin); d_cnt += 2; 

    if (code & 0x01)
    { uint32 test,cnt;

      if (code == 0xe601) return(d_cnt);	/* End of Frame */
      test = code >> 7;		
      cnt = ((code >> 1) & 0x3f) + 2;
      if (test < 0x120)		{ i -= cnt; }	/* Temporal */
      else if (test < 0x1cc)	{ i -= cnt; }	/* Spatial */ 
      else if (test >= 0x1e0)			/* New N Pix */
      { cnt = ((code >> 1) & 0x3ff) + 1;
	if (test >=0x1f0)			/* New N Pixels */
	{ uint32 bs = ((cnt * 15) + 15) >> 4;
	  i -= cnt;
	  while(bs--) { xin->Read_LSB_U16(xin); d_cnt += 2; } 
	}
	else	{ i -= cnt; }			/* Copy/Skip */
      }
      else if (test == 0x1cc)				/* Duplicate */
      {
        if (cnt <= 2) {fprintf(stderr,"DUP CNT ERR\n"); continue; }
        xin->Read_LSB_U16(xin); d_cnt += 2;
	i -= cnt;
      }
      else 
      {
	fprintf(stderr,"ARM Get len error: %04x\n",code);
      }
    }
    else { i--; }				/* New Pixel */
  }
  code = xin->Read_LSB_U16(xin); 
  if (code == 0xe601) d_cnt += 2;
  return(d_cnt);
}

void arm_yuv_to_rgb(iy,iu,iv,ir,ig,ib)
uint32 iy,iu,iv;
uint32 *ir,*ig,*ib;
{ float yy,uu,vv;
  float u2,u3,v2,v3;
  float DD;
  float rr,gg,bb;
  

  DD = 255.0;
  yy =  ((float)(iy)/31.0);
  vv =  ((float)(iv)/15.0);
  uu =  ((float)(iu)/15.0);
  if (vv > 1.0) vv = -((31.0 - (float)(iv) ) / 15.0);
  if (uu > 1.0) uu = -((31.0 - (float)(iu) ) / 15.0);
  v2 = vv * 0.701;
  u2 = uu * 0.886;
  v3 = vv * (0.299 * 0.701 / 0.587);
  u3 = uu * (0.114 * 0.886 / 0.587);

  bb = (yy + u2);
  rr = (yy + v2);
  gg = (yy - u3 - v3);
  DEBUG_LEVEL1 
	fprintf(stderr,"rr = %f gg = %f bb = %f\n",rr,gg,bb);
  bb *= 255.0;
  rr *= 255.0;
  gg *= 255.0;

  if (bb > 255.0) bb = 255.0; if (bb < 0.0) bb = 0.0;
  if (rr > 255.0) rr = 255.0; if (rr < 0.0) rr = 0.0;
  if (gg > 255.0) gg = 255.0; if (gg < 0.0) gg = 0.0;
  *ir = (uint32)(rr);
  *ig = (uint32)(gg);
  *ib = (uint32)(bb);

  DEBUG_LEVEL1
    fprintf(stderr,"YUV %d %d %d  RGB %d %d %d\n",iy,iu,iv,*ir,*ig,*ib);
}


/*****************************
 *  Function To allocate and initialized the following tables and buffers:
 *
 *********/
void ARM_Init_Tables(anim_hdr,imagex,imagey)
XA_ANIM_HDR *anim_hdr;
uint32 imagex,imagey;
{ uint32 i; int32 x,y;

 XA_Add_Func_To_Free_Chain(anim_hdr,ARM_Free_Stuff);
 /* Prev Buffer Allocation */
 if (cmap_color_func == 4)  i = xaMAX(3,x11_bytes_pixel);
 else i = x11_bytes_pixel;
 i *= imagex * imagey;

 if (ARM_prev_buff == 0)
 { ARM_prev_buff_size = i;
   ARM_prev_buff = (uint8 *)malloc( ARM_prev_buff_size );
 }
 else if (i > ARM_prev_buff_size)
 { ARM_prev_buff_size = i;
   ARM_prev_buff = (uint8 *)realloc( ARM_prev_buff, ARM_prev_buff_size );
 }
 if (ARM_prev_buff == 0) TheEnd1("ARM: prev_buff malloc err");

 /* Spatial/Temporal Tables Allocation */
 if (ARM_MOVL_X == 0)
 { ARM_MOVL_X = (int32 *)malloc( 459 * sizeof(int32) );
   if (ARM_MOVL_X==0) TheEnd1("ARM: MOVL_X malloc err");
 }
 if (ARM_MOVL_Y == 0)
 { ARM_MOVL_Y = (int32 *)malloc( 459 * sizeof(int32) );
   if (ARM_MOVL_Y==0) TheEnd1("ARM: MOVL_Y malloc err");
 }
 /* Temporal Encoding */
 x = y = -8;
 for(i = 0; i < 288; i++)
 { ARM_MOVL_X[i] = x;
   ARM_MOVL_Y[i] = y;
   x++; if (x > 8) { x = -8; y++; }
   if ((x==0) && (y==0))  x++; /* skip x = y = 0 case */
 }
 /* Spatial Encoding */
 x = y = -9;
 for(i = 288; i < 459; i++)
 { ARM_MOVL_X[i] = x;
   ARM_MOVL_Y[i] = y;
   x++; if (x > 9) { x = -9; y++; }
 }
}

/*****************************
 *  Function To Free  the following tables and buffers.
 *
 *********/
void ARM_Free_Stuff()
{
  if (ARM_MOVL_X) { free(ARM_MOVL_X); ARM_MOVL_X = 0; }
  if (ARM_MOVL_Y) { free(ARM_MOVL_Y); ARM_MOVL_Y = 0; }
  if (ARM_prev_buff) { free(ARM_prev_buff); ARM_prev_buff = 0; }
}


