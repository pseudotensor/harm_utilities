 
/*
 * xa_qt.h
 *
 * Copyright (C) 1993-1999,2000 by Mark Podlipec.
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 *
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */
 
#include "xanim.h"
 
#define QT_moov 0x6D6F6F76
#define QT_trak 0x7472616B
#define QT_mdia 0x6D646961
#define QT_minf 0x6D696E66
#define QT_stbl 0x7374626C
#define QT_rmra 0x726d7261
#define QT_cmov 0x636d6f76
#define QT_dcom 0x64636F6D
#define QT_zlib 0x7A6C6962
#define QT_cmvd 0x636D7664
/*-------------- LISTS ---------------------*/
#define QT_edts 0x65647473
/*-------------- STUFF ---------------------*/
#define QT_hdlr 0x68646C72
#define QT_mvhd 0x6D766864
#define QT_tkhd 0x746B6864
#define QT_elst 0x656C7374
#define QT_mdhd 0x6D646864
#define QT_stsd 0x73747364
#define QT_stts 0x73747473
#define QT_stss 0x73747373
#define QT_stsc 0x73747363
#define QT_stsz 0x7374737a
#define QT_stco 0x7374636f
/*-------------- VIDEO CODECS ---------------*/
#define QT_rle   0x726c6520
#define QT_smc   0x736D6320
#define QT_rpza  0x72707A61
#define QT_azpr  0x617A7072
#define QT_CVID  0x43564944
#define QT_cvid  0x63766964
#define QT_jpeg  0x6a706567
#define QT_MJPG  0x4d4a5047
#define QT_mjpg  0x6d6a7067
#define QT_mjpa  0x6d6a7061
#define QT_mjpb  0x6d6a7062
#define QT_SPIG  0x53504947
#define QT_yuv2  0x79757632
#define QT_PGVV  0x50475656
#define QT_YUV9  0x59565539
#define QT_YVU9  0x59555639
#define QT_RT21  0x52543231
#define QT_rt21  0x72743231
#define QT_IV31  0x49563331
#define QT_iv31  0x69763331
#define QT_IV32  0x49563332
#define QT_iv32  0x69763332
#define QT_IV41  0x49563431
#define QT_iv41  0x69763431
#define QT_kpcd  0x6b706364
#define QT_KPCD  0x4b504344
#define QT_cram 0x6372616D
#define QT_CRAM 0x4352414D
#define QT_wham 0x7768616d
#define QT_WHAM 0x5748414d
#define QT_msvc 0x6D737663
#define QT_MSVC 0x4d535643
#define QT_SVQ1 0x53565131
#define QT_UCOD 0x55434f44
#define QT_8bps	0x38627073
#define QT_8BPS	0x38425053
#define QT_wrle	0x77726c65
#define QT_WRLE	0x57524c45
#define QT_tga  0x74676120

/* added by konstantin priblouda to support sgi converted quicktimes */
/* this represents luminance only 8 bit images, uncompressed */
/* #define QT_sgi_raw_gray8  0x72617733   POD renamed to _raw3 */
#define QT_raw3	0x72617733


/*-------------- VIDEO/AUDIO CODECS ---------------*/
#define QT_raw   0x72617720
/*-------------- AUDIO CODECS ---------------*/
#define QT_raw00 0x00000000
#define QT_twos  0x74776f73
#define QT_MAC3  0x4d414333
#define QT_MAC6  0x4d414336
#define QT_ima4  0x696d6134
#define QT_ulaw  0x756c6177
#define QT_Qclp  0x51636c70
#define QT_QDMC	 0x51444d43
#define QT_agsm  0x6167736d
/*-------------- misc ----------------------*/
#define QT_free 0x66726565
#define QT_vmhd 0x766D6864
#define QT_dinf 0x64696e66
#define QT_appl 0x6170706C
#define QT_mdat 0x6D646174
#define QT_smhd 0x736d6864
#define QT_stgs 0x73746773
#define QT_udta 0x75647461
#define QT_skip 0x736B6970
#define QT_gmhd 0x676d6864
#define QT_text 0x74657874
#define QT_clip 0x636C6970   /* clip ??? contains crgn atom  */
#define QT_crgn 0x6372676E   /* crgn ??? contain coordinates?? */
#define QT_ctab 0x63746162   /* ctab: color table for 16/24 anims on 8 bit */

typedef struct
{
  uint32 format;
  uint32 compression;
  uint32 dref_id;
  uint32 version;
  uint32 codec_rev;
  uint32 vendor;
  uint16 chan_num;
  uint16 bits_samp;
  uint16 comp_id;
  uint16 pack_size;
  uint16 samp_rate;
  uint16 pad;
  uint32  bps;		/* convenience for me */
} QTS_CODEC_HDR;

typedef struct
{
  uint32 version;                /* version/flags */
  uint32 creation;               /* creation time */
  uint32 modtime;                /* modification time */
  uint32 timescale;
  uint32 duration;
  uint32 rate;
  uint16 volume;
  uint32  r1;
  uint32  r2;
  uint32 matrix[3][3];
  uint16 r3;
  uint32  r4;
  uint32 pv_time;
  uint32 pv_durat;
  uint32 post_time;
  uint32 sel_time;
  uint32 sel_durat;
  uint32 cur_time;
  uint32 nxt_tk_id;
} QT_MVHDR;

typedef struct
{
  uint32 version;                /* version/flags */
  uint32 creation;               /* creation time */
  uint32 modtime;                /* modification time */
  uint32 trackid;
  uint32 timescale;
  uint32 duration;
  uint32 time_off;
  uint32 priority;
  uint16 layer;
  uint16 alt_group;
  uint16 volume;
  uint32 matrix[3][3];
  uint32 tk_width;
  uint32 tk_height;
  uint16 pad;
} QT_TKHDR;

typedef struct
{
  uint32 version;                /* version/flags */
  uint32 creation;               /* creation time */
  uint32 modtime;                /* modification time */
  uint32 timescale;
  uint32 duration;
  uint16 language;
  uint16 quality;
} QT_MDHDR;

typedef struct
{
  uint32 version;                /* version/flags */
  uint32 type;
  uint32 subtype;
  uint32 vendor;
  uint32 flags;
  uint32 mask;
} QT_HDLR_HDR;


typedef struct QT_FRAME_STRUCT
{
  uint32 time;
  uint32 timelo;
  XA_ACTION *act;
  struct QT_FRAME_STRUCT *next;
} QT_FRAME;

typedef struct
{
  uint32 width;
  uint32 height;
  uint32 depth;
  uint32 compression;
  uint32 xapi_rev;
  uint32 (*decoder)();
  void *dlta_extra;
  XA_CHDR *chdr;
} QTV_CODEC_HDR;

typedef struct
{
  uint32 first;
  uint32 num;
  uint32 tag;
} QT_S2CHUNK_HDR;

typedef struct
{
  uint32 cnt;
  uint32 time;
  uint32 timelo;
} QT_T2SAMP_HDR;


