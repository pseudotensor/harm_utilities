
/*
 * xa_movi.h
 *
 * Copyright (C) 1996-1999,2000 by Mark Podlipec. 
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 * 
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */

#include "xanim.h"

typedef struct MOVI_FRAME_STRUCT
{
  uint32 time;
  uint32 timelo;
  XA_ACTION *act;
  struct MOVI_FRAME_STRUCT *next;
} MOVI_FRAME;

typedef struct
{
  uint32 frames;
  uint32 width;
  uint32 chans;
  uint32 format;
  float rate;
  uint32 compression;
  uint32 *off;
  uint32 *size;
} MOVI_A_HDR;

typedef struct
{
  uint32 frames;
  uint32 width;
  uint32 height;
  uint32 compression;
  uint32 interlacing;
  uint32 packing;
  uint32 orientation;
  float pixel_aspect;
  float fps;
  float q_spatial;
  float q_temporal;
  uint32 *off;
  uint32 *size;
} MOVI_I_HDR;

/* NOTES:
 *   from makemovie manpage
 *     interlace  none, even lines 1st, odd lines 1st
 *     loopmode   once, loop, swing(pingpong)
 *     compressions   mvc1   (most likely my comp1)
 *                    mvc2
 *                    jpeg
 *                    rle   8 bit
 *                    rle24 24 bit
 *    orientation  top_to_bottom  bottom_to_top?
 *    packing      32-bit RGBX ???
 */
 
typedef struct
{
 uint32 version;
 uint32 i_tracks;
 uint32 a_tracks;
 uint32 loop_mode;
 uint32 num_loops;
 uint32 optimized;
 MOVI_A_HDR *a_hdr;
 MOVI_I_HDR *i_hdr;
} MOVI_HDR;
 
