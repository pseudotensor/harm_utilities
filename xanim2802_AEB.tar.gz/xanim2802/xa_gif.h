
/*
 * xa_gif.h
 *
 * Copyright (C) 1990-1999,2000 by Mark Podlipec. 
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 * 
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */

#include "xanim.h"

typedef struct
{
  int32 width;
  int32 height;
  uint8 m;
  uint8 cres;
  uint8 pixbits;
  uint8 bc;
} GIF_Screen_Hdr; 

typedef struct
{
  int32 left;
  int32 top;
  int32 width;
  int32 height;
  uint8 m;
  uint8 i;
  uint8 pixbits;
  uint8 reserved;
} GIF_Image_Hdr;

typedef struct 
{
  uint8 valid;
  uint8 data;
  uint8 first;
  uint8 res;
  int32 last;
} GIF_Table;

typedef struct GIF_FRAME_STRUCT
{
  uint32 time;
  XA_ACTION *act;
  struct GIF_FRAME_STRUCT *next;
} GIF_FRAME;

