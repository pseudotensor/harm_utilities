
/*
 * xa_j6i.h
 *
 * Copyright (C) 1995-1999,2000 by Mark Podlipec. 
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 * 
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */

#include "xanim.h"

typedef struct J6I_FRAME_STRUCT
{
  uint32 time;
  uint32 timelo;
  XA_ACTION *act;
  struct J6I_FRAME_STRUCT *next;
} J6I_FRAME;
 
 
typedef struct
{
  uint8	*desc;
  uint32	jpg_beg;
  uint32	jpg_end;
  uint32	hdr_len;
  uint8	year;
  uint8	month;
  uint8	day;
  uint8	hour;
  uint8	min;
  uint8	sec;
} J6I_HDR;
 

