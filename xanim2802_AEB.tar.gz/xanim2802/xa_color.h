
/*
 * xa_color.h
 *
 * Copyright (C) 1995-1999,2000 by Mark Podlipec.
 * All rights reserved.
 *
 * This software may be freely used, copied and redistributed without
 * fee for non-commerical purposes provided that this copyright
 * notice is preserved intact on all copies.
 *
 * There is no warranty or other guarantee of fitness of this software.
 * It is provided solely "as is". The author disclaims all
 * responsibility and liability with respect to this software's usage
 * or its effect upon hardware or computer systems.
 *
 */

typedef struct
{
  uint8 *Ybuf;
  uint8 *Ubuf;
  uint8 *Vbuf;
  uint8 *the_buf;
  uint32  the_buf_size;
  uint16 y_w,y_h;
  uint16 uv_w,uv_h;
} YUVBufs;

typedef struct
{
  uint32 Uskip_mask;
  int32 *YUV_Y_tab;
  int32 *YUV_UB_tab;
  int32 *YUV_VR_tab;
  int32 *YUV_UG_tab;
  int32 *YUV_VG_tab;
} YUVTabs;

typedef struct
{
  uint8 r0,g0,b0;
  uint8 r1,g1,b1;
  uint8 r2,g2,b2;
  uint8 r3,g3,b3;
  uint32 clr0_0,clr0_1,clr0_2,clr0_3;
  uint32 clr1_0,clr1_1,clr1_2,clr1_3;
  uint32 clr2_0,clr2_1,clr2_2,clr2_3;
  uint32 clr3_0,clr3_1,clr3_2,clr3_3;
} XA_2x2_Color;



