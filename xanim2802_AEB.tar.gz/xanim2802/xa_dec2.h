
/* REV 2 Decoder Info Structure */

typedef struct
{
  uint32 cmd;			/* decode or query */
  uint32 skip_flag;		/* skip_flag */
  uint32 imagex,imagey;	/* Image Buffer Size */
  uint32 imaged; 		/* Image depth */
  XA_CHDR *chdr;		/* Color Map Header */
  uint32 map_flag;		/* remap image? */
  uint32 *map;			/* map to use */
  uint32 xs,ys;		/* pos of changed area */
  uint32 xe,ye;		/* size of change area */
  uint32 special;		/* Special Info */
  uint32 bytes_pixel;		/* bytes per pixel */
  uint32 image_type;		/* type of image */
  uint32 tmp1;			/* future expansion */
  uint32 tmp2;			/* future expansion */
  uint32 tmp3;			/* future expansion */
  uint32 tmp4;			/* future expansion */
  void *extra;			/* Decompression specific info */
} XA_DEC2_INFO;

#define XA_DEC_SPEC_RGB		0x0001
#define XA_DEC_SPEC_CF4		0x0002
#define XA_DEC_SPEC_DITH	0x0004

#define XA_IMTYPE_RGB		0x0001
#define XA_IMTYPE_GRAY		0x0002
#define XA_IMTYPE_CLR8		0x0003
#define XA_IMTYPE_CLR16		0x0004
#define XA_IMTYPE_CLR32		0x0005
#define XA_IMTYPE_332		0x0006
#define XA_IMTYPE_332DITH	0x0007
#define XA_IMTYPE_CF4		0x0008
#define XA_IMTYPE_CF4DITH	0x0009


