import gpfmon, os, pygtk, gtk, gobject, re, sets, sys, pickle, random, time

# TODO: this is a zoo, add some organization

# hold some global vars
widgets = None
globalvars = None

def update_interface():
    while gtk.events_pending(): gtk.main_iteration()

def clear_event_list():
    print "Clearing event list"
    gpfmon.widgets.staStatusbar.push(1, "Clearing event list")
    gpfmon.widgets.lblName.set_text("")
    gpfmon.widgets.lblCode.set_text("")
    gpfmon.widgets.lblCounters.set_text("")
    gpfmon.widgets.lblDesc.set_text("")    
    gpfmon.widgets.lblPebs.set_text("")
    gpfmon.widgets.lblInfo.set_text("")

    # get and clean up the model
    lstore = gpfmon.widgets.get_widget("lstEvents").get_model().get_model().get_model()
    lstore.clear()
    gpfmon.globalvars.events = []
    gpfmon.globalvars.selected_events = []
    gpfmon.globalvars.available_counters = []
    gpfmon.globalvars.used_counters = sets.Set([])
    gpfmon.widgets.staStatusbar.pop(1)
    
    
def refresh_event_list():
    gpfmon.widgets.staStatusbar.push(1, "Getting event info...")
    gpfmon.update_interface()
    clear_event_list()
    
    lstore = gpfmon.widgets.get_widget("lstEvents").get_model().get_model().get_model()
    
    # prepare a raw list of events from pfmon as a list of lines
    elist = gpfmon.BlockingCommand("pfmon -i _").run()
#    print elist
    elist = map(lambda x: x.strip("\n\r"), elist)
    event = None

    for line in elist:
        if line != "":
            re_name = re.compile("Name[\t\ ]+: (.*)")
            re_any = re.compile("[A-Za-z0-9\-]+[\t\ ]+: .*")
            match = re_name.match(line)
            if match:
                event = gpfmon.Event()
                event.name = match.group(1)
                gpfmon.globalvars.events.append(event)
            else:
                if re_any.match(line):
                    try:
                        event.harvest_data(line)
                    except:
                        print "exception (I should not be here - has the output format changed in pfmon?): Unknown line: %s" % line
                        break
                else:
                    print "Unknown line: %s" % line
#                    break

    # calculate global counter priority model
    gpfmon.globalvars.available_counters.sort(lambda x, y: x[1] - y[1])
    print "Spotted counters: %s" % str(gpfmon.globalvars.available_counters)
    gpfmon.globalvars.available_counters = [ x[0] for x in gpfmon.globalvars.available_counters ]
    
    # populate the model
    for event in gpfmon.globalvars.events:
        iter = lstore.append()
        lstore.set(iter, 
                    0, event.name, 	# event name
                    1, False, 		# monitoring control
                    2, event,		# event object
                    3, True)		# filter helper column
    gpfmon.widgets.staStatusbar.pop(1)
    if len(gpfmon.globalvars.events) < 10:
        gpfmon.widgets.staStatusbar.push(1, "Pfmon not supported or not in path")
        gpfmon.widgets.get_widget("btnAttach").set_sensitive(False)
        gpfmon.widgets.get_widget("btnExecute").set_sensitive(False)
    else:
        gpfmon.widgets.get_widget("btnAttach").set_sensitive(True)
        gpfmon.widgets.get_widget("btnExecute").set_sensitive(True)
    
    print "Total events registered: %d" % len(gpfmon.globalvars.events)

    # def get_host_info():
    gpfmon.widgets.staStatusbar.push(1, "Getting host info...")
    response = gpfmon.BlockingCommand("uname -i").run()
    gpfmon.globalvars.current.arch = response[0].strip("\n").strip("\r")
    print "Host architecture is '%s'" % gpfmon.globalvars.current.arch
    gpfmon.widgets.staStatusbar.pop(1)

def showModalErrorDialog(header, text):
    dlg = gtk.MessageDialog(gpfmon.widgets.get_widget("wndMain"),
                            gtk.DIALOG_MODAL,
                            gtk.MESSAGE_ERROR,
                            gtk.BUTTONS_OK,
                            header)
    dlg.set_property("secondary-text", text)
    dlg.run()
    dlg.destroy()

def showNotification(message, type="info"):
    gpfmon.widgets.vbxNotifications.pack_start(
        gpfmon.NotificationMessage(message, type), expand=False)
        
# TODO? change all references to lstEvents.get_model.get_iter blah blah to this
def get_selected_event():
    pass

# updates the selected events info box on tab 1
def update_event_info():
    info = "Selected events:\n"
    for e in gpfmon.globalvars.selected_events:
        info += "    " + e.name + " [%d]\n" % e.assigned_counter
    info += "\nUsed counters: "
    for c in gpfmon.globalvars.used_counters:
        info += str(c) + ", "
    info += "\n"
    gpfmon.widgets.lblInfo.set_text(info)
    
#    if len(gpfmon.globalvars.selected_events) == 2:
#        gpfmon.widgets.rdoSmplEv0.set_label(gpfmon.globalvars.selected_events[0].name)
#        gpfmon.widgets.rdoSmplEv1.set_label(gpfmon.globalvars.selected_events[1].name)
#    else:
#        gpfmon.widgets.rdoSmplEv0.set_label("None")
#        gpfmon.widgets.rdoSmplEv1.set_label("None")

# result line definitions
#old re_normal_result = re.compile("^[\ \t]*[0-9]+ [A-Z123_:]+[\ \t\n\r]*$")
re_normal_result = re.compile("^[\ \t]*([0-9]+) ([A-Z123_:]+[\ \t\n\r]*)$")
#re_profile_result = re.compile(r"\s+(\d+);\s+(\d+.\d+)%;\s+(\d+.\d+)%;\s+(.*)")
re_profile_result = re.compile(r"\s+(\d+)\s+(\d+.\d+)%\s+(\d+.\d+)%\s+([x0-9a-f]+)\s+(.*)")
re_profile_header = re.compile("#\s+counts\s+%self\s+%cum\s+function\s+name:file.*")

# ex 1: 11          30385    30385  2 0xffffffff81009aca 0x0012dcff34b3855a   2     0         -2667000 0x9f968
# ex 2: entry 11 PID:30396 TID:30396 CPU:2 STAMP:0x12dd4be2c4a853 OVFL:2 LAST_VAL:2667000 SET:0 IIP:0x4012c0
# for the compact format:
# entry, PID, TID, CPU, IIP, STAMP, OVERFLOW, REF SET TO, LAST REF VALUE, VALUE1, VALUE2
sampling_result_string = "(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([0-9a-fx]+)\s+([0-9a-fx]+)\s+(\d+)\s+(\d+)\s+([\d-]+)"
sampling_result_item = "\s+([0-9a-fx]+)"

# this is the base for a result line from sampling; we don't know how many pmds were assigned
re_sampling_result_base = re.compile(sampling_result_string + ".*")
re_sampling_pmd_assignment = re.compile("#\s+PMD(\d+):\s+([A-Z_0123:]+).*")
re_sampling_header_end = re.compile("# description of columns:.*")

# TODO: not exactly thread safe (does it matter?)
def append_output(text, tag=None):
    global re_normal_result, re_sampling_result_base, re_profile_result
    
    n_result = re_normal_result.match(text)
    s_result = re_sampling_result_base.match(text)
    p_result = re_profile_result.match(text)
    if n_result or s_result or p_result:
        tag = "result"

    gtk.gdk.threads_enter()
    buffer = gpfmon.widgets.txtOutput.get_buffer()
    if tag == None:
        buffer.insert(buffer.get_end_iter(), text + "\n")
    else:
        buffer.insert_with_tags_by_name(buffer.get_end_iter(), text + "\n", tag)

    # new auto scrolling
    if gpfmon.globalvars.autoscroll == True:
        buffer.move_mark_by_name("ye_end", buffer.get_end_iter())
        gpfmon.widgets.txtOutput.scroll_mark_onscreen(buffer.get_mark("ye_end"))
    gtk.gdk.threads_leave()
                
#    if gpfmon.widgets.chkAutoscroll.get_active():
#        gpfmon.widgets.txtOutput.scroll_to_mark(
#            buffer.get_insert(), 0)

# process application output text to find results
def process_results():
    global re_normal_result, re_sampling_result_base, re_profile_result
    global sampling_result_string, sampling_result_item, re_sampling_pmd_assignment, re_sampling_header_end

    current_run = gpfmon.globalvars.current.run
    current_run.date_finished = time.time()
    current_run.runtime = current_run.date_finished - current_run.date_started
    
    buffer = gpfmon.widgets.txtOutput.get_buffer()
    text = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False).split("\n")

    if gpfmon.globalvars.mode == gpfmon.MODE_NORMAL:
        # add the time column
        for col in gpfmon.widgets.tvData.get_columns():
            gpfmon.widgets.tvData.remove_column(col)
        gpfmon.widgets.tvData.append_column(gtk.TreeViewColumn("Time", gtk.CellRendererText(), text=0))
        
        columns = [gobject.TYPE_STRING]
        for e in current_run.events:
            columns.append(gobject.TYPE_STRING)
        for de in current_run.derived_events:
            columns.append(gobject.TYPE_STRING)
        model = gtk.ListStore(*tuple(columns))
        gpfmon.widgets.tvData.set_model(model)

        # clear data (should this be a function?)    
        current_run.result.clear()        
        
        # process the text line by line and stuff it into an intermediate list
        for line in text:
            match = re_normal_result.match(line)
            if match:
                current_run.result[match.group(2).strip("\n\r")] = match.group(1)

        if len(current_run.derived_events) > 0:
            for de in current_run.derived_events:
                formula = de.formulas[gpfmon.globalvars.current.arch]
                current_run.result[de.name] = current_run.result.calculate(formula)
                
        # visualization; stuff it into the table    
        column_number = 1
        args = ["N/A"]
        for k, v in current_run.result.iteritems():
            gpfmon.widgets.tvData.append_column(gtk.TreeViewColumn(k.replace("_", " "), gtk.CellRendererText(), text=column_number))
            column_number += 1
            args.append(v)
        
        try:
            model.append(args)
        except:
            print "An error occurred while adding data to the table - probably the monitoring session didn't go as planned"

    elif gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING:
        pmd = {}		# here we will store the pmd assignments done 
                                # automatically by pfmon at runtime and
                                # reported after the run
        phase = 1
        first_pmd = True
        model = None
        derived_event_space = []
        
        for line in text:
            if phase == 1:
                # look for the end of the sampling header. if found, the PMD
                # descriptions have already appeared and data can be gathered
                match = re_sampling_header_end.match(line)
                if match:
                    print "Header matched, processing PMD assignments"
                    columns = []
                    local_sampling_result_string = sampling_result_string
                    for element in pmd.values():
                        current_run.result.value_labels.append(element)
                        local_sampling_result_string += sampling_result_item
                        columns.append(gobject.TYPE_STRING)
                        columns.append(gobject.TYPE_INT)

                    # prepare space for derived events
                    for de in current_run.derived_events:
                        current_run.result.value_labels.append(de.name)
                        columns.append(gobject.TYPE_STRING)
                        columns.append(gobject.TYPE_FLOAT)
                        derived_event_space.append("x")
                        derived_event_space.append(-1.0)

                    columns = tuple(columns)
                    local_sampling_result_string += ".*"
                    re_sampling_result = re.compile(local_sampling_result_string)

                    # TODO: add some other columns to this list store
                    #       i.e. interpreted decimal value of the counter or
                    #       human-readable time.
                    model = gtk.ListStore(gobject.TYPE_INT,	# entry
                        gobject.TYPE_INT,			# PID
                        gobject.TYPE_INT,			# TID
                        gobject.TYPE_INT,			# CPU
                        gobject.TYPE_STRING,		# some address (?)
                        gobject.TYPE_STRING,		# stamp
                        gobject.TYPE_INT,			# overflow
                        gobject.TYPE_INT,			# ref set to
                        gobject.TYPE_INT,			# ref last val
                        gobject.TYPE_FLOAT,			# CUSTOM: delta time
                        *columns)
                        
                    gpfmon.widgets.tvData.set_model(None)
                    phase = 2

                # look for pmd assignments
                match = re_sampling_pmd_assignment.match(line)
                if match:
                    if first_pmd == True:
                        # TODO: ****** I'm not sure we should be doing this (it should already be there?)
#                        current_run.reference_event = match.group(2)
                        first_pmd = False
                    else:
                        pmd[int(match.group(1))] = match.group(2)

            if phase == 2:
                # look for sampling results
                match = re_sampling_result.match(line)
                if match:
                    # entry, PID, TID, CPU, IIP, STAMP, OVERFLOW, REF SET TO, LAST REF VALUE, VALUES
                    (entry, pid, tid, cpu, iip, stamp,
                    overflow, ref_set_to, ref_last_val) = match.groups()[:9]

                    values = []				# values for the ListStore
                    intvalues = []			# values for DataPoint
                    for element in match.groups()[9:]:
                        values.append(element)
                        intvalue = int(element, 16)
                        values.append(intvalue)
                        intvalues.append(intvalue)
                    
                    # TODO: convert this to UNIX seconds (interpret the stamp
                    #       value in terms of absolute time)
                    tstamp = int(stamp, 16)/1.0e9 # the number of seconds since something (WHAT? - like uptime)

                    # TODO
                    current_run.result.append(gpfmon.DataPointSampling(
                                values=list(intvalues),
                                timestamp=tstamp,
                                raw=line
                                ))
                    
                    tref = current_run.result[0].timestamp
                    delta = tstamp - tref
                    
                    modelrow = [int(entry),
                        int(pid),
                        int(tid),
                        int(cpu),
                        iip,
                        stamp,
                        int(overflow),
                        int(ref_set_to),                    
                        int(ref_last_val),
                        delta]
                    modelrow += values
                    modelrow += derived_event_space
                    model.append(modelrow)


        # calculate derived event values and stuff them into the model
        if len(current_run.derived_events) > 0:
            offset = len(model[0]) - len(derived_event_space) + 1
            for de in current_run.derived_events:
                formula = de.formulas[gpfmon.globalvars.current.arch]
                current_run.result.calculate(formula)
                for i in range(0, len(model)):
#                    print i, offset, current_run.result.getIndexByName(de.name), current_run.result[i].values[current_run.result.getIndexByName(de.name)]
                    model[i][offset] = current_run.result[i].values[current_run.result.getIndexByName(de.name)]
                offset += 2

        gpfmon.widgets.tvData.set_model(model)

        gpfmon.globalvars.graph.update_data(current_run.result.getGraphData())

        for col in gpfmon.widgets.tvData.get_columns():
            gpfmon.widgets.tvData.remove_column(col)

        columns = []
        columns.append(gtk.TreeViewColumn("Entry #", gtk.CellRendererText(), text=0))
        columns.append(gtk.TreeViewColumn("Stamp", gtk.CellRendererText(), text=5))
        columns.append(gtk.TreeViewColumn("Delta", gtk.CellRendererText(), text=9))

        j = 11
        for label in current_run.result.value_labels:
            columns.append(gtk.TreeViewColumn(label.replace("_", " "), gtk.CellRendererText(), text=j))
            j += 2
        for column in columns:        
            gpfmon.widgets.tvData.append_column(column)

    elif gpfmon.globalvars.mode == gpfmon.MODE_PROFILE:
        # scan for matching lines and stuff results into the array
        num_results = 0
        
        # TODO: what if the user changes this param while the program is running?
        # TODO: freeze the whole option tab in runtime
        max_results = int(gpfmon.widgets.entProfTopItems.get_text())
        for line in text:
            result = re_profile_header.match(line)
            if result:
                num_results = 0
            result = re_profile_result.match(line)
            if result and num_results < max_results:
                fun_lib_tuple = result.group(5).strip("\n\r").split("<")
                if len(fun_lib_tuple) > 1:
                    fun = fun_lib_tuple[0]
                    lib = fun_lib_tuple[1].split(">")[0]
                else:
                    fun = fun_lib_tuple[0]
                    lib = "unknown"
                current_run.result.append(gpfmon.DataPointProfile(
                            samples=result.group(1),
                            percent=float(result.group(2)),
                            percent_cum=float(result.group(3)),
                            function=fun,
                            library=lib))
                num_results += 1

        gpfmon.globalvars.graph.update_data(current_run.result.getGraphData())
        
        # add columns to table for visualisation
        for col in gpfmon.widgets.tvData.get_columns():
            gpfmon.widgets.tvData.remove_column(col)
        gpfmon.widgets.tvData.append_column(gtk.TreeViewColumn("Function/module", gtk.CellRendererText(), text=0))
        gpfmon.widgets.tvData.append_column(gtk.TreeViewColumn("% Total", gtk.CellRendererText(), text=1))
        gpfmon.widgets.tvData.append_column(gtk.TreeViewColumn("% Cumulative", gtk.CellRendererText(), text=2))
        model = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_STRING, gobject.TYPE_STRING)
        gpfmon.widgets.tvData.set_model(model)
        
        total = 0.0
        
        # fill table with data
        for element in current_run.result:
            total += element.percent
            model.append([element.function + " in " + element.library, str(element.percent) + "%", str(total) + "%"])

    print "Results processing ended. We're done."
#    # update whichever graph is being displayed
#    gpfmon.graph.queue_draw()
    
# setup variables, dirs etc
def config_setup(config):
    # TODO: quikhak!
    gpfmon.globalvars.derived_events = gpfmon.DerivedEvents.read_from_file("test.xml")

    config.path_home = os.path.expanduser("~") + "/"
    config.pathname_conf = ".pfmon/"
    config.path_conf = config.path_home + config.pathname_conf
#    config.filename_pid = "pfmon.pid"
#    config.file_pid = config.path_conf + config.filename_pid
    config.filename_sshopts = "gpfmon_sshopts"
    config.file_sshopts = config.path_conf + config.filename_sshopts
    config.filename_options_autosave = "gpfmon_autosave_options"
    config.file_options_autosave = config.path_conf + config.filename_options_autosave
    config.filename_preferences = "gpfmon_preferences"
    config.file_preferences = config.path_conf + config.filename_preferences

    try:    
        if not os.path.exists(config.path_home):
            raise OSError("Home directory does not exist?")

        if not os.path.exists(config.path_conf):
            print "Configuration directory (%s) not found. Creating..." % config.path_conf
            os.mkdir(config.path_conf, 0700)
    except:
        gpfmon.showModalErrorDialog("Access error", "Failed to access configuration directory\nError: %s" % sys.exc_info()[0])

    try:
        if not os.path.exists(config.file_sshopts):
            print "SSH profile file not fount. Creating..."
            open(config.file_sshopts, "w").close()

        if os.stat(config.file_sshopts).st_size == 0:
            print "SSH profile file empty"
            gpfmon.globalvars.sshopts = []
        else:
            f = open(config.file_sshopts)
            gpfmon.globalvars.sshopts = pickle.load(f)
            f.close()
    except:
        gpfmon.showModalErrorDialog("Access error", "Failed to access SSH profile configuration file (%s)\nError: %s" % (config.file_sshopts, sys.exc_info()[0]))
        gpfmon.globalvars.sshopts = []

def set_hourglass_cursor(state):
    if state == True:
        c = gtk.gdk.Cursor(gtk.gdk.WATCH)
    else:
        c = gtk.gdk.Cursor(gtk.gdk.LEFT_PTR)
    gpfmon.widgets.wndMain.window.set_cursor(c)

def generate_dummy_sampling_data():
    d = gpfmon.DataPointList(type=gpfmon.DATA_SAMPLING, values_per_point=2)
    d.value_labels = ["UNHALTED_CORE_CYCLES", "INSTRUCTIONS_RETIRED"]
    d.append(gpfmon.DataPoint("first", values=[0, 0], timestamp=0))
    tstamp = 0
    for i in range(20):
        tstamp += 0.01*random.randint(1,9)
        d.append(gpfmon.DataPoint("nic",
            values=[d[-1].values[0] + random.randint(-100, 200), d[-1].values[1] + random.randint(-10, 20)], timestamp=tstamp))
    return d

# stuff the options tab into a dict and pickle it into a file
def save_options(filename=None, auto=False):
    if filename == None:
        if auto == False:
            dlg = gtk.FileChooserDialog(title = "Save Options As...", 
                                        parent = gpfmon.widgets.wndMain,
                                        action = gtk.FILE_CHOOSER_ACTION_SAVE,
                                        buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_SAVE, gtk.RESPONSE_OK))
            ret = dlg.run()
            if ret != gtk.RESPONSE_OK:
                dlg.destroy()
                return
            else:
                filename = dlg.get_filename()
            dlg.destroy()
        else:
            filename = gpfmon.globalvars.config.file_options_autosave

    widget_list = []
    widget_dict = {}
    val = None
    widgets_find_all_children(gpfmon.widgets.hbxOptions, widget_list)
    for w in widget_list:
        if w.__class__ == gtk.CheckButton or w.__class__ == gtk.ComboBox:
            val = w.get_active()
        elif w.__class__ == gtk.Entry:
            val = w.get_text()
        elif w.__class__ == gtk.SpinButton:
            val = w.get_value_as_int()
        elif w.__class__ == gtk.RadioButton:
            val = w.get_active()
            if val != True:
                continue
        else:
            val = None
        widget_dict[w.name] = val
    f = open(filename, "w")
    print "Saving options to %s" % filename
    pickle.dump(widget_dict, f, pickle.HIGHEST_PROTOCOL)
    f.close()
    gpfmon.globalvars.current.options_filename = filename

# unpickle a dict from a file and set the widgets in the options tab according to
# values in the dict
def load_options(auto=False):
    if auto == False:
        dlg = gtk.FileChooserDialog(title = "Load Options...", 
                                    parent = gpfmon.widgets.wndMain,
                                    action = gtk.FILE_CHOOSER_ACTION_OPEN,
                                    buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK))
        ret = dlg.run()
        if ret != gtk.RESPONSE_OK:
            dlg.destroy()
            return
        else:
            filename = dlg.get_filename()
        dlg.destroy()
    else:
        filename = gpfmon.globalvars.config.file_options_autosave

    try:
        f = open(filename)
        widget_dict = pickle.load(f)
        f.close()
    except:
        showModalErrorDialog("Error", "A problem occurred while loading the options. Please make sure that the supplied file is a gpfmon options file.")
        return
        
    # TODO: add check from preferences if the dialog should be displayed
    if auto == False and gpfmon.globalvars.preferences.replace_project_options == True:
        dlg = gtk.MessageDialog(gpfmon.widgets.wndMain,
                                gtk.DIALOG_MODAL,
                                gtk.MESSAGE_QUESTION,
                                gtk.BUTTONS_OK_CANCEL,
                                "Confirm action")
        dlg.set_property("secondary-text", "Current options will be replaced")
        ret = dlg.run()
        dlg.destroy()
        if ret == gtk.RESPONSE_CANCEL:
            return

    print "Loading options from %s" % filename
    gpfmon.globalvars.current.options_filename = filename
        
    for key, val in widget_dict.iteritems():
        w = gpfmon.widgets.get_widget(key)
        if w.__class__ == gtk.CheckButton or w.__class__ == gtk.ComboBox or w.__class__ == gtk.RadioButton:
            w.set_active(val)
        elif w.__class__ == gtk.Entry:
            w.set_text(val)
        elif w.__class__ == gtk.SpinButton:
            w.set_value(val)

# get all widgets of interest whose ancestor is the first argument and pack them into a list
def widgets_find_all_children(widget, widget_list):
    important_classes = [gtk.CheckButton, gtk.Entry, gtk.ComboBox, gtk.SpinButton, gtk.RadioButton]
    try:
        if widget.__class__ in important_classes:
            widget_list.append(widget)
        # all containers will pass this call, other classes will throw an exception
        children = widget.get_children()
        for w in children:
            widgets_find_all_children(w, widget_list)
    except:
        pass
