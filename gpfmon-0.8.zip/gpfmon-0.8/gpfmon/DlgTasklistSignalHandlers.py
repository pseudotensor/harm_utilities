import gpfmon, re

class DlgTasklistSignalHandlers:
    def btnDlgTasklist_Cancel_clicked(self, widget):
        gpfmon.widgets.get_widget("dlgTasklist").hide()

    def btnDlgTasklist_OK_clicked(self, widget):
        lstTasks = gpfmon.widgets.get_widget("lstTasks")
        path, column = lstTasks.get_cursor()
        if path == None:
            gpfmon.showModalErrorDialog("Select a task from the list")
            return -1
        model = lstTasks.get_model()
        pid = model.get_value(model.get_iter(path), 0)
        gpfmon.widgets.get_widget("entPath").set_text("#%s" % pid)
        gpfmon.widgets.get_widget("dlgTasklist").hide()

    def cmbTaskFilter_changed(self, widget):
        model = widget.get_model()
        event_regex = model[widget.get_active()][1]
        print event_regex
        e_model_filter = gpfmon.widgets.lstTasks.get_model().get_model()
        e_model = e_model_filter.get_model()
        for row in e_model:
#            print row[0]
            if re.match(event_regex, row[1]):
                row[3] = True
            else:
                row[3] = False
        print "Refiltering..."
        e_model_filter.refilter()
