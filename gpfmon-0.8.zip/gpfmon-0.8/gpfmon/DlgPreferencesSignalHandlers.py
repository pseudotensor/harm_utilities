import gpfmon

class DlgPreferencesSignalHandlers:
    pass
