import gpfmon, pygtk, gtk

class DlgUmasksSignalHandlers:
    def lstUmasks_toggled(self, cell, path, model):
        model[path][0] = not model[path][0]
        
    def btnDlgUmasks_Cancel_clicked(self, widget):
        gpfmon.widgets.dlgUmasks.hide()
        
    def btnDlgUmasks_Apply_clicked(self, widget):
        model = gpfmon.widgets.lstUmasks.get_model()
        e_model = gpfmon.widgets.lstEvents.get_model()
        event = e_model.get_value(e_model.get_iter(gpfmon.widgets.lstEvents.get_cursor()[0]), 2)
        event.selected_umasks = []
        for row in model:            
            if row[0] == True:
                event.selected_umasks.append(row[1])
        gpfmon.widgets.dlgUmasks.hide()
