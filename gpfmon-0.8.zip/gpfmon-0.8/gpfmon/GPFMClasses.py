import sets, re, os, time, pty
import pexpect, pxssh, gpfmon, threading, pygtk, gtk, gobject
import copy, xml.dom.minidom, pickle
import operator
from gtk import gdk

re_name = re.compile(r"Name[\ \t]+: (.*)")
re_code = re.compile(r"Code[\ \t]+: (.*)")
re_counters = re.compile(r"Counters[\ \t]+: (.*)")
re_desc = re.compile(r"Desc[\ \t]+: (.*)")
re_pebs = re.compile(r"PEBS[\ \t]+: (.*)")
re_umask = re.compile(r"Umask-[0-9]+[\ \t]+: ([^\:]+ : [^\:]+ : .*)")
#re_umask = re.compile(r"Umask-[0-9]+ : [^:]+ :(.*)")

# ACHTUNG: watch out for the scope.
(DATA_UNSPECIFIED,
DATA_NORMAL,
DATA_SAMPLING,
DATA_PROFILE) = range(4)

class Event(object):
    
    def __init__(self):
        # constant event info
        self.name = ""
        self.code = ""
        self.counters = sets.Set([])
        self.desc = ""
        self.umasks = []
        self.pebs = "No"
        
        # runtime vars
        self.monitor = False
        self.assigned_counter = -1
        self.available = True
        self.selected_umasks = []

    # harvest event data obtained from pfmon -i
    def harvest_data(self, line):
        match = re_name.match(line)
        if match:
            self.name = match.group(1)

        match = re_code.match(line)
        if match:
            self.code = match.group(1)

        match = re_counters.match(line)
        if match:
            counters = match.group(1)
            counters = counters.strip("[").strip("]").split(" ")
            counters = map(lambda x: int(x), counters[1:-1])
            counters = sets.Set(counters)
            for counter in counters:
                for ctr in gpfmon.globalvars.available_counters:
                    if ctr[0] == counter:
                        ctr[1] += 1
                        break
                else:
                    gpfmon.globalvars.available_counters.append([counter, 1])

#            print counters
            self.counters = counters
#            self.counters = match.group(1)
            
        match = re_desc.match(line)
        if match:
            self.desc = match.group(1)

        match = re_umask.match(line)
        if match:
            self.umasks.append(match.group(1))
                        
        match = re_pebs.match(line)
        if match:
            self.pebs = match.group(1)

class SSHConnection(object):
    sshbinary = "/usr/bin/ssh"
    
    def __init__(self):
        self.hostname = ""
        self.user = ""
        self.password = ""
        self.connected = False
        self.fd = None
        self.marker = "__d_"	# I use this semi clever method to find out
                                # when the command exits.
        pass

    def pause(self, period=1):
        time.sleep(period)
                
    def connect(self, hostname, user, password):
        pid, fd = pty.fork()
        if pid == 0:
#            os.execv(self.sshbinary, [self.sshbinary, "-T", "-l", user, hostname])
            os.execv(self.sshbinary, [self.sshbinary, "-l", user, hostname, "echo %s; /bin/tcsh" % self.marker])
            print "I should never be here"
        else:
            print "Connecting..."
            self.fd = fd
            self.hostname = hostname
            self.user = user
            self.password = password
            self.pause(2)
#            s = os.read(fd, 1)
#            print "X1: %s" % s
            # read motd
            s = os.read(fd, 1000)
            print "<motd>: %s" % s
            self.pause()
            if not re.match("%s.*" % self.marker, s):
                s = os.read(fd, 1000)
                print "<password prompt>: %s" % s
                os.write(fd, password + "\n")
                self.pause()
                s = os.read(fd, 1000)
                print "X5: %s" % s
                self.pause()
                print "Connected"
            else:
                print "Looks like no password is needed..."
            # TODO: this needs more love; i.e. check the output of an id command?
            self.connected = True

    def reconnect(self):
        self.connect(self.hostname, self.user, self.password)

    def disconnect(self):
        os.write(fd, "exit\n")
        pause()
        self.fd = None
        self.connected = False

    def command(self, cmd):
        print "preparing to run \"%s\"" % cmd
        cmd += ";echo %s" % self.marker
        # handle leftovers and silently ignore exceptions (not the best choice perhaps)
        try:
            s = os.read(self.fd, 1000)
            print "<leftovers>: %s" % s
        except:
            pass
        print "executing command \"%s\"" % cmd
        os.write(self.fd, cmd + "\n")
        self.pause()
        dummy = os.read(self.fd, len(cmd)+1)
        res = ''
        s = True
        while s:
            try:
                s = os.read(self.fd, 1)                
                res += s
                if res[-5:-1] == self.marker:
                    raise "from the dead"
            except:
                break
        return res[0:-5]

class SSHConnection2(object):
    
    def __init__(self):
        self.conn = None
#        self.hostname = None
#        self.username = None
#        self.password = None
        self.profile = None
        self.connected = False
        pass

    def connect(self, profile):
        self.profile = profile
        print "Logging in to %s..." % profile.hostname
        if profile.ssh_cmdline != "":
            print "Using custom ssh command line: %s" % profile.ssh_cmdline
        self.conn = pxssh.pxssh(profile)
        if not self.conn.login(profile.hostname, profile.username, profile.password):
            print "Logging in failed... %s" % str(self.conn)
            return -1            

#        self.hostname = hostname
#        self.username = username
#        self.password = password
        self.connected = True
        print "SSH session login successful (%s@%s)" % (profile.username, profile.hostname)
#        self.conn.sendline('id')
#        self.conn.prompt()
#        print self.conn.before
#        self.conn.logout()
        return 1
        
    def __old_connect(self, hostname, username, password):
        print "Logging in to %s..." % hostname
        self.conn = pxssh.pxssh()
        if not self.conn.login(hostname, username, password):
            print "Logging in failed... %s" % str(self.conn)
            return -1            

        self.hostname = hostname
        self.username = username
        self.password = password
        self.connected = True
        print "SSH session login successful (%s@%s)" % (username, hostname)
#        self.conn.sendline('id')
#        self.conn.prompt()
#        print self.conn.before
#        self.conn.logout()
        return 1

    def reconnect(self):
        if self.hostname and self.username and self.password:
            return self.connect(self.hostname, self.username, self.password)
        else:
            raise Exception()

    def fake_popen(self, cmd):
        if self.conn != None:
            self.conn.sendline(cmd)
            return self.conn
        else:
            print "Not connected (bug?)"
            return None

    def command(self, cmd):
        if self.conn != None:
            self.conn.sendline(cmd)
#            while self.conn.readline():
#                boo = self.conn.readline()
#                print boo
            self.conn.prompt()
#            self.conn.expect(".+")
#            print "vsdvsdvs"

#            print "---"
#            print self.conn.before
#            print "---"

            return self.conn.before
#            return "*Nothing*"
        else:
            print "Not connected"
    
    def command_nonblocking(self, cmd):
        if self.conn != None:
            threadcmd = threading.Thread(target=self.runme, name="ThreadCMD", args=(cmd,)).start()
            threadwatcher = threading.Thread(target=self.watchme, name="WatchCMD", args=(threadcmd,)).start()
            return threadcmd
        else:
            print "Not connected"

    def disconnect(self):
        if self.conn:
            self.conn.logout()
            self.conn = None
            self.connected = False

    def isConnected(self):
        return self.connected

# TODO: remove this?
    def runme(self, cmd):
        print "runme"
        self.conn.sendline(cmd)
        self.conn.prompt()
        print self.conn.before

# TODO: remove this?
    def watchme(self, cmd):
        pass
#c = SSHConnection2()
#c.connect("158.75.57.4", "anowak", "")
#print c.command("ls /tmp")
#c.disconnect()

# TODO: remove this?
class SSHConnection2Servant(threading.Thread):
    def run(self):
        caller.conn.sendline(command)
        caller.conn.prompt()
        print caller.conn.before

class BlockingCommand(object):
    def __init__(self, cmd):
        self.__running = threading.Event()
        self.__running.clear()
        self.__cmd = cmd
    
    def start(self):
        return self.run()
        
    def run(self):
#        if gpfmon.globalvars.sshconnection.connected == False:
        if not gpfmon.globalvars.sshconnection.isConnected():
            return os.popen(self.__cmd).readlines()
        else:
            return gpfmon.globalvars.sshconnection.command(self.__cmd).split("\n")[1:]

    def isRunning():
        if self.__running.isSet():
            return True
        else:
            return False
        
class BackgroundCommand(threading.Thread):
    def __init__(self, cmd):
        self.__running = threading.Event()
        self.__running.clear()
        self.__cmd = cmd
        threading.Thread.__init__(self)

    def run(self):
        self.__running.set()
        gtk.gdk.threads_enter()
        gpfmon.widgets.staStatusbar.push(1, "Running...")
        gpfmon.widgets.btnExecute.set_sensitive(False)
        gpfmon.widgets.btnAttach.set_sensitive(False)
        gpfmon.widgets.btnAbort.set_sensitive(True)
        gpfmon.widgets.ntbNotebook.set_current_page(4)
        gtk.gdk.threads_leave()

#        re_result = re.compile("^[\ \t]*[0-9]+ [A-Z123_:]+[\ \t\n\r]*$")


#        cmd = "echo $$ > /tmp/pfmon.pid; exec %s" % self.__cmd
        # TODO: hardwired (".pfmon"), fix!
#        cmd = "mkdir -p ~/.pfmon; bash -c 'export TERM=dumb; echo $$ > ~/.pfmon/pfmon.pid; exec %s'" % self.__cmd
#        cmd = "mkdir -p ~/.pfmon; bash -c 'echo $$ > ~/.pfmon/pfmon.pid; exec %s'" % self.__cmd
#        cmd = "mkdir -p $HOME/%s; bash -c 'echo $$ > $HOME/%s; exec %s'" % \
#            (gpfmon.globalvars.config.pathname_conf,
#             gpfmon.globalvars.config.pathname_conf + gpfmon.globalvars.config.filename_pid,
#             self.__cmd)


# temporarily commented
#        cmd = "bash -c 'echo $$ > $HOME/%s; exec %s'" % \
#             (gpfmon.globalvars.config.pathname_conf + gpfmon.globalvars.config.filename_pid,
#             self.__cmd)

        cmd = self.__cmd
        print cmd
#        if gpfmon.globalvars.sshconnection.connected == False:
        if not gpfmon.globalvars.sshconnection.isConnected():
            pipe = os.popen(cmd)
#            pipe = os.popen("./sleeper.sh")
        else:
            pipe = gpfmon.globalvars.sshconnection.fake_popen(cmd)

        gpfmon.globalvars.current.pipe = pipe
        gtk.gdk.threads_enter()
        autoscroll = gpfmon.widgets.chkAutoscroll.get_active()            
        gtk.gdk.threads_leave()
        line = pipe.readline()
        while line:
#            tag = None
#            if re_result.match(line):
#                tag = "result"
            gpfmon.append_output(line.strip("\n"), None)
            line = pipe.readline()

        gpfmon.globalvars.current.pipe = None
        gpfmon.append_output("Session ended", "info")
        gpfmon.process_results()

        gtk.gdk.threads_enter()
        gpfmon.widgets.staStatusbar.pop(1)
        gpfmon.widgets.ntbNotebook.set_current_page(4)
        gpfmon.widgets.btnExecute.set_sensitive(True)
        gpfmon.widgets.btnAttach.set_sensitive(True)
        gpfmon.widgets.btnAbort.set_sensitive(False)        
        gtk.gdk.threads_leave()
        self.__running.clear()
    
    def isRunning():
        if self.__running.isSet():
            return True
        else:
            return False

class SSHProfile(object):
    def __init__(self, description="", hostname="", username="",
                 password="", path="", ldpath="", pfmon_executable="pfmon",
                 exec_after_login="", exec_before="", exec_after="",
                 ssh_cmdline=""):
        self.hostname = hostname
        self.username = username
        self.description = description
        self.password = password
        self.path = path
        self.ldpath = ldpath
        self.pfmon_executable = pfmon_executable
        self.exec_after_login = exec_after_login
        self.exec_before = exec_before
        self.exec_after = exec_after
        self.ssh_cmdline = ssh_cmdline

# moreover: add inheriting classes like SamplingDataPoint to handle the value
# presently stored in 'raw' more conveniently
class old__DataPoint(object):
    def __init__(self, key="", value=0, values=None, raw=None, timestamp=None):
        self.key = key
        self.value = value		# used when there is only 1 value per point
        self.values = values		# used when tehre is more than 1 value per point
        self.raw = raw
        self.timestamp = timestamp		# non-scaled time
        self.timestamp2 = self.timestamp	# scaled time

    # TODO: this should be handled by python 2.4 i think        
    def cmp(a, b):
        if a.value < b.value:
            return -1
        elif a.value == b.value:
            return 0
        else:
            return 1

    # TODO: same here    
    def cmp_by_key(a, b):
        if a.key < b.key:
            return -1
        elif a.key == b.key:
            return 0
        else:
            return 1

class DataPointList(list):
    def __init__(self, type = DATA_UNSPECIFIED, values_per_point = 1):
        self.multiple = False		# does this set contain child sets?
        self.name = None		# what is the name of this set?
        self.type = type		# if which type is the data?
        self.date = None		# when did monitoring start?
        self.enddate = None		# when did monitoring end?
        self.values_per_point = values_per_point
        self.value_labels = []		# the label for each set of values
                                        # (NOT for each single value!)
        self.reference_event = None
        self.timelabel = "None"		# the X axis label for this data set
        list.__init__(self)

    def clear(self):
#        self[:] = []
        for i in range(len(self)):
            del self[0]

    # class methods for operating on values; the arg may be the same class or
    # a number (int, float); split up for performance
    def add(op1, index1, op2, index2 = 0):
        result = copy.deepcopy(op1)
        if op1.__class__ == op2.__class__:
            for element in result:
                element.values[index1] += op2.values[index2]
        else:
            for element in result:
                element.values[index1] += op2
        return result

    def sub(op1, index1, op2, index2 = 0):
        result = copy.deepcopy(op1)
        if op1.__class__ == op2.__class__:
            for element in result:
                element.values[index1] -= op2.values[index2]
        else:
            for element in result:
                element.values[index1] -= op2
        return result

    def mul(op1, index1, op2, index2 = 0):
        result = copy.deepcopy(op1)
        if op1.__class__ == op2.__class__:
            for element in result:
                element.values[index1] *= op2.values[index2]
        else:
            for element in result:
                element.values[index1] *= op2
        return result

    def div(op1, index1, op2, index2 = 0):
        result = copy.deepcopy(op1)
#        result = DataPointList(type=gpfmon.DATA_SAMPLING)
        result.value_labels = ["TEST"]
        result.values_per_point = 1
        i = 0
        if op1.__class__ == op2.__class__:
            for element in result:
                if op2[i].values[index2] != 0:
#                    element.values[index1] /= op2[i].values[index2]
                    element.values[index1] = op2[i].values[index2]*1.0 / element.values[index1]*1.0
                else:
                    element.values[index1] = 0.1
                i += 1
        else:
            for element in result:
                element.values[index1] /= op2
        return result

    # recalculate the time according to the format selected by the user
    def update_time(self):
        model = gpfmon.widgets.cmbTimeFormat.get_model()
        time_format_name, time_format = model[gpfmon.widgets.cmbTimeFormat.get_active()]
        i = 0
        for item in self:
            if time_format == gpfmon.TIME_R_SEC:
                item.timestamp2 = item.timestamp
            elif time_format == gpfmon.TIME_R_MSEC:
                item.timestamp2 = item.timestamp*1000
            elif time_format == gpfmon.TIME_E_HITS:
                item.timestamp2 = i
            else:
                # unsupported - no effect
                pass
            i += 1
        self.timelabel = time_format_name + "; reference event: %s" % self.reference_event.name

    # get the index of data for event named 'name' in the sample array
    def getIndexByName(self, name):
        return self.value_labels.index(name)
            
# behold, the most java-esque piece of code in this software "product"
class DerivedEvents(list):
    def __init__(self):
        self.categories = []
        list.__init__(self)

    @staticmethod
    def read_from_file(filename):
        derived_events = DerivedEvents()
        index = 0
        
        f = open(filename)
        doc = xml.dom.minidom.parse(f)
        xmlcategories = doc.getElementsByTagName("category")
        for xmlcategory in xmlcategories:
            category_name = xmlcategory.getAttribute("name")
            category_id = xmlcategory.getAttribute("id") # not used
            derived_events.categories.append(category_name)
            print category_name, category_id
            xml_derived_events = xmlcategory.getElementsByTagName("event")
            for xml_derived_event in xml_derived_events:
                kwargs = {}
                kwargs['name'] = xml_derived_event.getAttribute("name")
                kwargs['categories'] = [category_name]
                description = xml_derived_event.getElementsByTagName("description")[0].childNodes[0].data
                kwargs['description'] = re.sub("\s+", " ", description)[1:]	# leading space
                formulas = {}
                xmlformulas = xml_derived_event.getElementsByTagName("formula")
                for xmlformula in xmlformulas:
                    arch = xmlformula.getAttribute("arch")
                    data = xmlformula.childNodes[0].data
                    formulas[arch] = data
                kwargs['formulas'] = formulas
                kwargs['index'] = index
                derived_events.append(DerivedEvent(**kwargs))
                index += 1
        return derived_events
    
#    read_from_file = staticmethod(read_from_file)
    
#    def getCategories(self, category):
#        return self.categories
        
    def getElementsByCategory(self, category):
        return filter(lambda x: category in x.categories, self)

    # better not give a missing index
    def getElementByIndex(self, index):
        if index != -1:
            return filter(lambda x: x.index == index, self)[0]

class DerivedEvent(object):
    re_event = re.compile("[A-Z][A-Z0-9_\.:]+$")
    
    def __init__(self, name="", formulas=None, description="", categories=[], index=-1):
        if formulas == None:
            formulas = {}
            
        if categories == None:
            categories = []
            
        self.name = name			# derived event name
        self.formulas = formulas		# dict of arch:formula in RPN
        self.events = {}
        for arch, formula in formulas.iteritems():
            self.events[arch] = []
            tokens = formula.split(",")
            for token in tokens:
                if self.re_event.match(token):
                    self.events[arch].append(token)
        print self.events
        self.description = description		# derived event description
        self.categories = categories		# not used
        self.index = index			# used for the tree model

# rpn parser
class ArithmeticProcessingPlant(object):
    def __init__(self):
        pass
        
    @staticmethod
    def infix_to_postfix(formula):
        stack = []
        num_stack = []
        op_stack = []
        
#    infix_to_postfix = staticmethod(infix_to_postfix)

    # somewhat inefficient if large amounts of data were to be processed
    # TODO: add support for 1 operand operators like "%" etc
    @staticmethod
    def calculate_individual(result, formula_postfix):
        transtbl = {}
        transtbl["+"] = ArithmeticProcessingPlant.simple_add
        transtbl["-"] = ArithmeticProcessingPlant.simple_sub
        transtbl["*"] = ArithmeticProcessingPlant.simple_mul
        transtbl["/"] = ArithmeticProcessingPlant.simple_div
        
        stack = formula_postfix.split(",")
        stack.reverse()

        print "stack: %s" % stack
        print "result: %s" % result

        while len(stack) > 1:
            op1 = stack.pop()
            op2 = stack.pop()
            oper = stack.pop()
            
            print op1, op2, oper
            
            if not re.match("\d+", str(op1)):
                op1 = result[op1]
                
            if not re.match("\d+", str(op2)):
                op2 = result[op2]                
            
            op1 = float(op1)
            op2 = float(op2)
            
            print op1, op2, oper
            stack.append(transtbl[oper](op1, op2))

        retval = stack.pop()
        print retval
        return "%.2f" % retval
        
    @staticmethod    
    def simple_add(op1, op2):
        return op1 + op2

    @staticmethod    
    def simple_sub(op1, op2):
        return op1 - op2

    @staticmethod    
    def simple_mul(op1, op2):
        return op1 * op2 * 1.0

    @staticmethod    
    def simple_div(op1, op2):
        return op1 / (op2 * 1.0)
    
    @staticmethod
    def simple_percent(op1, op2):
        return op1 * 100.0
        
    @staticmethod
    def calculate(formula_postfix):
#    def solve(formula_infix):
#        stack = ArithmeticProcessingPlant.infix_to_postfix(formula_infix)
        stack = formula_postfix.split(",")
        stack.reverse()
        print "stack: %s" % stack
        transtbl = {}
        transtbl["+"] = gpfmon.DataPointList.add
        transtbl["-"] = gpfmon.DataPointList.sub
        transtbl["*"] = gpfmon.DataPointList.mul
        transtbl["/"] = gpfmon.DataPointList.div

        while len(stack) > 1:
            op1 = stack.pop()	# either a string, a number or an instance
            op2 = stack.pop()
            oper = stack.pop()
            print op1, op2, oper
            operator_func = transtbl[oper]
            
            if op1.__class__ == gpfmon.DataPointList:
                op1index = 0
            elif re.match("\d+", op1):	# impossible? never should happen
                op1 = int(op1)
                op1index = 0
            else:
                # TODO: FIX THIS!! hardcoded and wrong and not scalable and ble
                op1index = gpfmon.globalvars.data2.getIndexByName(op1)
                op1 = gpfmon.globalvars.data2

            if op2.__class__ == gpfmon.DataPointList:
                op2index = 0
            elif re.match("\d+", op2):
                op2 = int(op2)
                op2index = 0
            else:
                # TODO: FIX THIS!! hardcoded and wrong and not scalable and ble
                op2index = gpfmon.globalvars.data2.getIndexByName(op2)
                op2 = gpfmon.globalvars.data2

            print "calling ", operator_func, " with ", type(op1), op1index, type(op2), op2index
            
            result = operator_func(op1, op1index, op2, op2index)
            result.value_labels[op1index] = "MODIFIED"
            stack.append(result)

        return stack.pop()
        
#    calculate = staticmethod(calculate)

#class NotificationMessage(gtk.Widget):
#class NotificationMessage(gtk.HBox):
class NotificationMessage(gtk.EventBox):
    def __init__(self, message, type="info"):
        gtk.EventBox.__init__(self)

        self.imgMessage = gtk.Image()
        if type == "error":
            self.imgMessage.set_from_stock("gtk-dialog-error", 1)
        elif type == "warn":
            self.imgMessage.set_from_stock("gtk-dialog-warning", 1)
        elif type == "info":
            self.imgMessage.set_from_stock("gtk-dialog-info", 1)
        else:
            self.imgMessage.set_from_stock("", 1)

        self.lblMessage = gtk.Label()
        self.lblMessage.set_label(message)
        self.lblMessage.set_property("use-markup", True)

        self.hbxMessage = gtk.HBox()
        self.hbxMessage.pack_start(gtk.Label(), expand=True, fill=True)
        self.hbxMessage.pack_start(self.imgMessage, expand=False, fill=True)
        self.hbxMessage.pack_start(self.lblMessage, expand=False, fill=True)
        self.hbxMessage.pack_start(gtk.Label(), expand=True, fill=True)
        self.hbxMessage.set_spacing(7)
        
        self.imgClose = gtk.Image()
        self.imgClose.set_from_stock("gtk-close", 2)

        self.btnClose = gtk.Button()
        self.btnClose.set_image(self.imgClose)
        self.btnClose.set_relief(gtk.RELIEF_NONE)
        self.btnClose.connect("clicked", self.btnClose_clicked)

        self.hbx = gtk.HBox()
        self.hbx.pack_start(self.hbxMessage, expand=True, fill=True)
        self.hbx.pack_end(self.btnClose, expand=False, fill=True)
#        self.hbx.set_property("expand", False)
        self.hbx.set_property("border_width", 7)
        self.add(self.hbx)

        """        
        style = self.btnClose.get_style()
        bgcolor = style.fg[gtk.STATE_NORMAL]
        r, g, b, p = bgcolor.red, bgcolor.green, bgcolor.blue, bgcolor.pixel
        r = (r + 3000) & 65535
        print p
        bgcolor = gdk.Color(r, 65000, 2314, 32000)
        style = style.copy()
        style.fg[gtk.STATE_NORMAL] = bgcolor
        self.btnClose.set_style(style)
        """
        
#        ctr = self.btnClose
#        ctr = gpfmon.widgets.vbxNotifications
        ctr = self
        map = ctr.get_colormap()
        style = ctr.get_style().copy()
        bgcolor = style.bg[gtk.STATE_NORMAL]
        r, g, b, p = bgcolor.red, bgcolor.green, bgcolor.blue, bgcolor.pixel
        topval = 65535

        if type == "error":
            r = int(r * 1.2)
            r = (r & topval) | bool(r & ~topval)*topval
            g = int(g * 0.8)
            b = int(b * 0.8)
        elif type == "warn":
            r = int(r * 1.1)
            r = (r & topval) | bool(r & ~topval)*topval
            g = int(g)
            b = int(b * 0.8)
        elif type == "info":
            r = int(r * 1.1)
            r = (r & topval) | bool(r & ~topval)*topval
            g = int(g * 1.1)
            g = (g & topval) | bool(g & ~topval)*topval
            b = int(b * 0.8)
        else:
            pass
        color = map.alloc_color(r, g, b)
        style.bg[gtk.STATE_NORMAL] = color
        ctr.set_style(style)
        
        self.show_all()

    def set_label(self, text):
        self.lblMessage.set_label(text)

    def btnClose_clicked(self, widget):
        self.destroy()

gobject.type_register(NotificationMessage)

# TODO: check if the attached stuff (runs, etc) is also saved
"""A gpfmon project"""
class GPFMProject(object):
    def __init__(self):
        self.date_created = time.time()
        self.date_last_saved = -1
        self.name = ""
        self.author = ""
        self.comments = ""
        self.notes = []
        self.runs = []
        
    # TODO: add failsafe stuff
    @staticmethod
    def open(filename=None):
        infile = open(filename, "rb")
        p = pickle.load(infile)
        infile.close()
        return p
        
    # TODO: add failsafe stuff
    def save(self):
        self.date_last_saved = time.time()
        outfile = open("gpfmontestsav.dat", "wb", 2)
        pickle.dump(self, outfile)
        outfile.close()
        
    def addRun(self, run):
        self.runs.append(run)
        
class ProjectNote(object):
    def __init__(self, contents=""):
        date_created = time.time()
        date_modified = date_created
        self.contents = contents
        
    def update(self, contents=""):
        date_modified = time.time()
        self.contents = contents

"""A single pfmon run"""
class Run(object):
    def __init__(self, command_line="", binary="", mode=None, event_specification=None, events=[], derived_events=[], scenarios=[]):
        self.date_started = -1
        self.date_finished = -1
        self.runtime = -1
        self.command_line = command_line
        self.binary = binary
        self.aborted = False
        self.mode = mode
        self.arch = gpfmon.globalvars.current.arch
        self.hostname = gpfmon.globalvars.current.hostname
        self.username = gpfmon.globalvars.current.username
        self.result = gpfmon.Result.Factory(parent=self, mode=mode)
        self.event_specification = None
        self.events = events
        self.derived_events = derived_events
        self.scenarios = scenarios
        
        
    # TODO: do we need this?
    def addResult(self):
        self.result = gpfmon.Result.Factory(parent=self, mode=self.mode)
        return self.result

"""A run result"""
class Result(object):
    def __init__(self, parent=None):
        self.parent = parent
        
    @staticmethod
    def Factory(parent, mode):
        if mode == gpfmon.MODE_NORMAL:
            return gpfmon.ResultNormal(parent)
        elif mode == gpfmon.MODE_PROFILE:
            return gpfmon.ResultProfile(parent)
        elif mode == gpfmon.MODE_SAMPLING:
            return gpfmon.ResultSampling(parent)
        else:
            return None

    # abstract
    def getGraphData(self):
        raise Exception("method not implemented")

class ResultNormal(Result, dict):
    def __init__(self, parent):
        Result.__init__(self, parent)
        dict.__init__(self)
    
    # simplified RPN parser (2 ops required!)
    def calculate(self, formula_postfix):
        transtbl = {}
        transtbl["+"] = operator.add
        transtbl["-"] = operator.sub
        transtbl["*"] = operator.mul
        transtbl["/"] = operator.div
        transtbl["%%"] = ArithmeticProcessingPlant.simple_percent
        
        stack = formula_postfix.split(",")
        stack.reverse()

        print "stack: %s" % stack
        print "result: %s" % self

        while len(stack) > 1:
            op1 = stack.pop()
            op2 = stack.pop()
            
            if op2 in transtbl:
                oper = op2
                op2 = None
            else:
                oper = stack.pop()
            
            print op1, op2, oper
            
            if not re.match("\d+", str(op1)):
                op1 = self[op1]
            op1 = float(op1)
                
            if op2 != None:
                if not re.match("\d+", str(op2)):
                    op2 = self[op2]                
                op2 = float(op2)            
            
            print op1, op2, oper
            stack.append(transtbl[oper](op1, op2))

        retval = stack.pop()
        print retval
        return "%.2f" % retval
        
class ResultProfile(Result, list):
    def __init__(self, parent):
        Result.__init__(self, parent)
        list.__init__(self)

    def clear(self):
#        self[:] = []
        for i in range(len(self)):
            del self[0]
        
    # limit - the number of top results to show
    # fill - whether to fill the missing values up to 100% with "Other"
    def getGraphData(self, limit=None, fill=True):
        gd = GraphDataProfile()
        
        if limit == None or limit > len(self):
                limit = len(self)
        
        total = 0    
        for i in range(limit):
            total += self[i].percent
            gd.keys.append(self[i].function + " in " + self[i].library)
            gd.values.append(self[i].percent)
            
        if fill == True:
            gd.keys.append("Other")
            gd.values.append(100.0 - total)
            
        return gd
        
class ResultSampling(Result, list):
    def __init__(self, parent, values_per_point=1):
        self.values_per_point = values_per_point
        self.reference_event = None
        self.value_labels = []
        Result.__init__(self, parent)
        list.__init__(self)
        
    def clear(self):
#        self[:] = []
        for i in range(len(self)):
            del self[0]

    def getGraphData(self):
        d = GraphDataSampling(self)
        return d

    def getIndexByName(self, name):
        return self.value_labels.index(name)

    def calculate(self, formula_postfix):
        transtbl = {}
        transtbl["+"] = operator.add
        transtbl["-"] = operator.sub
        transtbl["*"] = operator.mul
        transtbl["/"] = operator.div
        transtbl["%%"] = ArithmeticProcessingPlant.simple_percent

        for item in self:
            stack = formula_postfix.split(",")
            stack.reverse()

            print "stack: %s" % stack

            while len(stack) > 1:
                op1 = stack.pop()
                op2 = stack.pop()
                
                if op2 in transtbl:
                    oper = op2
                    op2 = None
                else:
                    oper = stack.pop()
                
                print op1, op2, oper
                
                if not re.match("\d+", str(op1)):
                    op1 = item.values[self.getIndexByName(op1)]
                op1 = float(op1)
                    
                if op2 != None:
                    if not re.match("\d+", str(op2)):
                        op2 = item.values[self.getIndexByName(op2)]
                    op2 = float(op2)
                                
                print op1, op2, oper
                stack.append(transtbl[oper](op1, op2))

            retval = stack.pop()
            print retval
            item.values.append(float("%.2f" % retval))


class DataPoint(object):
    def __init__(self):
        pass
        
class DataPointProfile(DataPoint):
    def __init__(self, samples, percent, percent_cum, function, library):
        DataPoint.__init__(self)
        self.samples = samples
        self.percent = percent
        self.percent_cum = percent_cum
        self.function = function
        self.library = library

class DataPointSampling(DataPoint):
    def __init__(self, values, timestamp, raw):
        DataPoint.__init__(self)
        self.values = values
        self.timestamp = timestamp
        self.raw = raw

class GraphData(object):
    def __init__(self):
        self.title = ""
        
    def __len__(self):
        raise Exception("__len__ implementation must be supplied")

# should this be a dict?
class GraphDataProfile(GraphData):
    def __init__(self):
        self.keys = []
        self.values = []
        self.__iterctr = 0
        GraphData.__init__(self)
    
    # the list interface
    def __len__(self):
        return len(self.values)
    
    def __getitem__(self, index):
        return self.keys[index], self.values[index]
        
    # the iterator interface
    def __iter__(self):
        self.__iterctr = 0
        return self
        
    def next(self):
        if self.__iterctr < len(self):
            self.__iterctr += 1
            return self.keys[self.__iterctr-1], self.values[self.__iterctr-1]
        else:
            raise StopIteration()

# TODO?
class GraphDataSampling(GraphData):
    def __init__(self, parent):
        self.timelabel = ""
        self.parent = parent
        self.__iterctr = 0
        self.timestamps = []
        self.update_time()
        GraphData.__init__(self)

    # the list interface - will return items from the parent
    def __len__(self):
        return len(self.parent)
    
    def __getitem__(self, index):
        return self.parent[index]

    # the iterator interface - will return items from the parent
    def __iter__(self):
        self.__iterctr = 0
        return self
        
    def next(self):
        if self.__iterctr < len(self):
            self.__iterctr += 1
            return self.parent[self.__iterctr-1]
        else:
            raise StopIteration()
        
    def update_time(self):
        # safety valve
        if len(self) == 0:
            return
            
        model = gpfmon.widgets.cmbTimeFormat.get_model()
        time_format_name, time_format = model[gpfmon.widgets.cmbTimeFormat.get_active()]
        self.timestamps[:] = []
        zero = self.parent[0].timestamp
        if time_format == gpfmon.TIME_R_SEC:
            for element in self.parent:
                self.timestamps.append(element.timestamp - zero)
        elif time_format == gpfmon.TIME_R_MSEC:
            for element in self.parent:
                self.timestamps.append((element.timestamp - zero)*1000)
        elif time_format == gpfmon.TIME_E_HITS:
            i = 0
            for element in self.parent:
                self.timestamps.append(i)
                i += 1
        else:
            # unsupported - no effect
            pass
        # TODO: potential problem with reference_event (already fixed?)
        self.timelabel = time_format_name
        if gpfmon.globalvars.current.run != None:
            self.timelabel += "; reference event: %s" % gpfmon.globalvars.current.run.reference_event.name

class Preferences:
    def __init__(self):
        self.auto_save = True
        self.save_project_options = False
        self.load_project_options = False
        self.replace_project_options = False

    @staticmethod
    def load_from_file():
        filename = gpfmon.globalvars.config.file_preferences
        pref_object = None
        print "Loading preferences from %s" % filename
        
        try:
            f = open(filename)
            pref_object = pickle.load(f)
            f.close()
        except:
            print "Problem while loading preferences. Resetting to defaults."
            pref_object = Preferences()
        
        return pref_object

    def save_to_file(self):
        filename = gpfmon.globalvars.config.file_preferences
        print "Saving preferences to %s" % filename

        try:
            f = open(filename, "w")
            pickle.dump(self, f, pickle.HIGHEST_PROTOCOL)
            f.close()
        except:
            print "Problem while saving preferences."
