import pygtk, gtk, gobject, sets, os, GPFMClasses, gpfmon, re, time
import threading

class SignalHandlers:
#    widgets = None
#    globalvars = None
#    widgets = gpfmon.widgets
#    globalvars = gpfmon.globalvars

    def xQuit(self, widget):
        if gpfmon.globalvars.preferences.auto_save:
#            print "Saving options..."
            gpfmon.save_options(auto=True)
        gpfmon.globalvars.preferences.save_to_file()
        print "Exiting gracefully..."
        gpfmon.globalvars.sshconnection.disconnect()
        gtk.main_quit()

    def ShowAbout(self, widget):
        dlgAbout = gpfmon.widgets.get_widget("dlgAbout")
        dlgAbout.show_all()
        
    def WindowClose(self, widget, response):
        widget.hide()

    def something(self, widget):
        print "something"

# ------------ Menu
    # File
    def mnuLoadOptions_activate(self, widget):
        gpfmon.load_options()

    def mnuSaveOptions_activate(self, widget):
        gpfmon.save_options(gpfmon.globalvars.current.options_filename)
        
    def mnuSaveOptionsAs_activate(self, widget):
        gpfmon.save_options()
        pass

    def mnuProperties_activate(self, widget):
        prj = gpfmon.globalvars.current.project
        gpfmon.widgets.entDlgProperties_Name.set_text(prj.name)
        gpfmon.widgets.lblDlgProperties_DateCreated.set_text(time.strftime("%A, %d %B %Y at %X", time.localtime(prj.date_created)))
        gpfmon.widgets.lblDlgProperties_DateLastSaved.set_text(time.strftime("%A, %d %B %Y at %X", time.localtime(prj.date_last_saved)))
        gpfmon.widgets.entDlgProperties_Author.set_text(prj.author)
        gpfmon.widgets.entDlgProperties_Comments.set_text(prj.comments)
        
        ret = gpfmon.widgets.dlgProperties.run()
        if ret == 1:
            gpfmon.globalvars.current.project.name = gpfmon.widgets.entDlgProperties_Name.get_text()
            gpfmon.globalvars.current.project.author = gpfmon.widgets.entDlgProperties_Author.get_text()
            gpfmon.globalvars.current.project.comments = gpfmon.widgets.entDlgProperties_Comments.get_text()
        gpfmon.widgets.dlgProperties.hide()
                        
    # Edit
    def mnuEditCut_activate(self, widget):
        pass
        
    def mnuEditCopy_activate(self, widget):
        pass
        
    def mnuEditCopy_activate(self, widget):
        pass
        
    def mnuEditDelete_activate(self, widget):
        pass

    def mnuPreferences_activate(self, widget):
        gpfmon.widgets.chkPrefsAutosave.set_active(gpfmon.globalvars.preferences.auto_save)
        gpfmon.widgets.chkPrefsSaveProjectOptions.set_active(gpfmon.globalvars.preferences.save_project_options)
        gpfmon.widgets.chkPrefsLoadProjectOptions.set_active(gpfmon.globalvars.preferences.load_project_options)
        gpfmon.widgets.chkPrefsReplaceProjectOptions.set_active(gpfmon.globalvars.preferences.replace_project_options)
        
        ret = gpfmon.widgets.dlgPreferences.run()
        if ret == 1:
            gpfmon.globalvars.preferences.auto_save = gpfmon.widgets.chkPrefsAutosave.get_active()
            gpfmon.globalvars.preferences.save_project_options = gpfmon.widgets.chkPrefsSaveProjectOptions.get_active()
            gpfmon.globalvars.preferences.load_project_options = gpfmon.widgets.chkPrefsLoadProjectOptions.get_active()
            gpfmon.globalvars.preferences.replace_project_options = gpfmon.widgets.chkPrefsReplaceProjectOptions.get_active()
        else:
            pass

        gpfmon.widgets.dlgPreferences.hide()
        
    # Session

# ------------ Toolbar
    def rdoLocal_released(self, widget):
        gpfmon.widgets.get_widget("entHostname").set_sensitive(False)
        gpfmon.widgets.get_widget("btnConnect").set_sensitive(False)
        gpfmon.widgets.get_widget("btnDisconnect").set_sensitive(False)
        gpfmon.widgets.get_widget("btnAttach").set_sensitive(True)
        gpfmon.widgets.get_widget("btnExecute").set_sensitive(True)
        gpfmon.refresh_event_list()
                
    def rdoRemote_released(self, widget):
        gpfmon.widgets.get_widget("entHostname").set_sensitive(True)
        gpfmon.widgets.get_widget("btnConnect").set_sensitive(True)
        gpfmon.widgets.get_widget("btnAttach").set_sensitive(False)
        gpfmon.widgets.get_widget("btnExecute").set_sensitive(False)
#        if gpfmon.globalvars.sshconnection.connected == False:
        if gpfmon.globalvars.sshconnection.isConnected() == False:
            gpfmon.clear_event_list()

    def btnConnect_clicked(self, widget):
        # sanity check
#        if gpfmon.globalvars.sshconnection.connected == False:
        if gpfmon.globalvars.sshconnection.isConnected() == False:
#            dlgSSH = gpfmon.widgets.get_widget("dlgSSH")
            gpfmon.widgets.dlgSSH.show()

    def btnDisconnect_clicked(self, widget):
#        if gpfmon.globalvars.sshconnection.connected == True:
        if gpfmon.globalvars.sshconnection.isConnected() == True:
            # disconnect from the host
            gpfmon.globalvars.sshconnection.disconnect()
            gpfmon.globalvars.current.hostname = "localhost"
            gpfmon.globalvars.current.username = "?"
            
            # clean up event window
            gpfmon.widgets.get_widget("lstEvents").get_model().get_model().get_model().clear()
            gpfmon.globalvars.events = []
            
            # bring back the connect button and local option
            # disable attach button since we're not conncted
            # BUG
#            btn = gpfmon.widgets.get_widget("btnConnect")
#            btn.set_label("gtk-connect")
#            btn.set_use_stock(True)
            gpfmon.widgets.get_widget("rdoLocal").set_sensitive(True)
            gpfmon.widgets.get_widget("btnAttach").set_sensitive(False)
            gpfmon.widgets.get_widget("btnExecute").set_sensitive(False)
            gpfmon.widgets.get_widget("btnConnect").set_sensitive(True)
            gpfmon.widgets.get_widget("btnDisconnect").set_sensitive(False)
            gpfmon.widgets.staStatusbar.pop(0)

    def btnAttach_clicked(self, widget):
#        if gpfmon.globalvars.sshconnection.connected == True:
        if gpfmon.globalvars.sshconnection.isConnected() == True:
#            reply = gpfmon.globalvars.sshconnection.command("ps axw | awk '{print $1 \" \" $5}'").split("\n")
#            reply = gpfmon.globalvars.sshconnection.command("ps axuw | awk '{print $2 \" \" $1 \" \" $11 \" \" $12 \" \" $13 \" \" $14 \" \" $15 \" \" $16 }'").split("\n")
            reply = gpfmon.globalvars.sshconnection.command("ps axuw | awk '{printf $2 \" \" $1 \" \"; for(i=11; i<NF+1; i++) printf $i\" \"; print \"\" }'").split("\n")
            reply = reply[2:]	# get rid of the command line
        else:
#            reply = os.popen("ps axw | awk '{print $1 \" \" $5}'").readlines()
#            reply = os.popen("ps axuw | awk '{print $2 \" \" $1 \" \" $11 \" \" $12 \" \" $13 \" \" $14 \" \" $15 \" \" $16 }'").readlines()
            reply = os.popen("ps axuw | awk '{printf $2 \" \" $1 \" \"; for(i=11; i<NF+1; i++) printf $i\" \"; print \"\" }'").readlines()
            reply = reply[1:]	# get rid of the ps header
        dlgTasklist = gpfmon.widgets.get_widget("dlgTasklist")
        tasklist = gpfmon.widgets.get_widget("lstTasks").get_model()
        lstTasks =  gpfmon.widgets.get_widget("lstTasks")
        if tasklist == None:
            tasklist = gtk.ListStore(gobject.TYPE_INT, gobject.TYPE_STRING, gobject.TYPE_STRING, gobject.TYPE_BOOLEAN)
            tasklist_filter = tasklist.filter_new()
            tasklist_filter.set_visible_column(3)
            tasklist_sort = gtk.TreeModelSort(tasklist_filter)

            pid_column = gtk.TreeViewColumn('PID', gtk.CellRendererText(), text=0)
            pid_column.set_sort_column_id(0)
            user_column = gtk.TreeViewColumn('User', gtk.CellRendererText(), text=1)
            user_column.set_sort_column_id(1)
            proc_column = gtk.TreeViewColumn('Process name', gtk.CellRendererText(), text=2)
            proc_column.set_sort_column_id(2)
            lstTasks.append_column(pid_column)
            lstTasks.append_column(user_column)
            lstTasks.append_column(proc_column)

            renderer = gtk.CellRendererText()
            gpfmon.widgets.cmbTaskFilter.pack_start(renderer, True)
            gpfmon.widgets.cmbTaskFilter.add_attribute(renderer, 'text', 0)
            #gpfmon.widgets.cmbTasks.connect("changed", gpfmon.globalvars.all_signal_handlers["dlgTasklist"].cmbTaskFilter_changed)
        else:
            tasklist_sort = tasklist
            tasklist = tasklist.get_model().get_model()
            tasklist.clear()

        # fill the model and gather owner names
        owners = []
        for line in reply:
            if len(line) == 0: continue
            line = line.strip("\r\n").split(" ", 2)
            iter = tasklist.append()
            tasklist.set(iter,
                        0, int(line[0]),
                        1, line[1],
                        2, line[2],
                        3, True)
            if line[1] not in owners:
                owners.append(line[1])
        
        lstTasks.set_model(tasklist_sort)

        # setup tasklist filter combo box
        tmodel = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_STRING)
        
        gpfmon.widgets.cmbTaskFilter.set_row_separator_func(lambda x, y: x.get_value(y, 0) == "-")
        tmodel.append(["Display all owners", ".+"])
        tmodel.append(["Root only", "root"])
        tmodel.append(["Non-root only", "[^r][^o][^o][^t]"])
        tmodel.append(["-", ".+"])
        for owner in owners:
            tmodel.append([owner, owner])
        gpfmon.widgets.cmbTaskFilter.set_model(tmodel)
        gpfmon.widgets.cmbTaskFilter.set_active(0)

        dlgTasklist.show()

    def btnExecute_clicked(self, widget):
        reference_event = None
        derived_events_ = []
        scenarios_ = []
        ev_spec = None

        if gpfmon.widgets.rdoEvIndividual.get_active():
            ev_spec = gpfmon.EV_SPEC_INDIVIDUAL
        elif gpfmon.widgets.rdoEvDerived.get_active():
            ev_spec = gpfmon.EV_SPEC_DERIVED
        elif gpfmon.widgets.rdoEvScenario.get_active():
            ev_spec = gpfmon.EV_SPEC_SCENARIO        

        # check counting mode
        if gpfmon.globalvars.mode == gpfmon.MODE_NORMAL and \
            ev_spec == gpfmon.EV_SPEC_INDIVIDUAL and \
            len(gpfmon.globalvars.selected_events) < 1:
            gpfmon.showModalErrorDialog("No events were selected for monitoring", "Select events from the list on the 'Events' tab")
            return
            
        # check sampling mode
        if gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING and \
            ev_spec == gpfmon.EV_SPEC_INDIVIDUAL:
            if len(gpfmon.globalvars.selected_events) < 1:
                gpfmon.showModalErrorDialog("Incorrect event set", "When sampling, at least TWO events must be selected. Usually the reference event would be one from the UNHALTED_*_CYCLES group")
                return

            reference_event_index = gpfmon.widgets.cmbSmplReferenceEvent.get_active()
            if reference_event_index < 2:
                gpfmon.showModalErrorDialog("Reference event not set", "When sampling, a reference event must be selected. Usually the reference event would be one from the UNHALTED_*_CYCLES group")
                return
            model = gpfmon.widgets.cmbSmplReferenceEvent.get_model()
            reference_event = model[reference_event_index][1]
            
        # check profile mode
        if gpfmon.globalvars.mode == gpfmon.MODE_PROFILE and \
            ev_spec == gpfmon.EV_SPEC_INDIVIDUAL and \
            len(gpfmon.globalvars.selected_events) != 1:
            gpfmon.showModalErrorDialog("Incorrect set of events", "When profiling, exactly ONE event must be selected. Usually this would be UNHALTED_*_CYCLES")
            return

        # check derived event mode
        if ev_spec == gpfmon.EV_SPEC_DERIVED:
            try:
                model = gpfmon.widgets.tvDerivedEvents.get_model()
                row = model[model.get_iter(gpfmon.widgets.tvDerivedEvents.get_cursor()[0])]
                derived_event = gpfmon.globalvars.derived_events.getElementByIndex(row[1])
                if derived_event == None:
                    raise Exception()
            except:
                gpfmon.showModalErrorDialog("No derived event selected", "When using derived events, at least one must be selected from the 'Derived events' tab")
                return        
        
        # extract binary name
        binary = gpfmon.widgets.get_widget("entPath").get_text()
        # look for pid number for attaching
        if binary[0] == "#":
            binary = "--attach-task %s " % binary[1:]

        print "Command: %s" % binary
        cmd = "%s " % gpfmon.widgets.entPfmonExecutable.get_text()

        # harvest monitoring options
        if gpfmon.globalvars.mode == gpfmon.MODE_NORMAL:
            if gpfmon.widgets.get_widget("mnuSystemwide").get_active() == True:
                cmd += "--system-wide "

        if gpfmon.globalvars.mode == gpfmon.MODE_NORMAL or \
            gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING:
            if gpfmon.widgets.get_widget("mnuDisableCommandOutput").get_active() == True:
                cmd += "--no-cmd-output "
            if gpfmon.widgets.mnuVerbose.get_active() == True:
                cmd += "--verbose "
            if gpfmon.widgets.mnuDebug.get_active() == True:
                cmd += "--debug "
            privlevel = 3 - gpfmon.widgets.cmbPrivLevel.get_active()
            cmd += "-%d " % privlevel

        if gpfmon.widgets.get_widget("mnuFollowAll").get_active() == True:
            cmd += "--follow-all "
        else:
            if gpfmon.widgets.get_widget("mnuFollowFork").get_active() == True:
                cmd += "--follow-fork "
            if gpfmon.widgets.get_widget("mnuFollowVfork").get_active() == True:
                cmd += "--follow-vfork "
            if gpfmon.widgets.get_widget("mnuFollowPthread").get_active() == True:
                cmd += "--follow-pthread "
            if gpfmon.widgets.get_widget("mnuFollowExec").get_active() == True:
                cmd += "--follow-exec "

        # check if umasks were set
        for event in gpfmon.globalvars.selected_events:
            if len(event.umasks) > 0 and len(event.selected_umasks) == 0:
                gpfmon.showModalErrorDialog("Event configuration error", "No umask was specified for %s" % event.name)
                return

        # --- nothing can stop this past this point ---

        # remove the reference event from the selected_events list
#        if gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING and \
#            ev_spec == gpfmon.EV_SPEC_INDIVIDUAL:
#                try:
#                    del gpfmon.globalvars.selected_events[gpfmon.globalvars.selected_events.index(reference_event)]
#                except ValueError:
#                    pass
                # TODO: what about removing the selection from the event list?
                
        if ev_spec == gpfmon.EV_SPEC_DERIVED:
            for ev in gpfmon.globalvars.selected_events:
                ev.monitor = False
                ev.selected_umasks = []
                gpfmon.globalvars.used_counters = sets.Set([])                
            del gpfmon.globalvars.selected_events[:]
            model = gpfmon.widgets.lstEvents.get_model().get_model().get_model()
            for row in model:
                row[1] = False
            # TODO: when adding events, check if there are counters available, otherwise multiplexing is needed
            
            model = gpfmon.widgets.tvDerivedEvents.get_model()
            row = model[model.get_iter(gpfmon.widgets.tvDerivedEvents.get_cursor()[0])]
            derived_event = gpfmon.globalvars.derived_events.getElementByIndex(row[1])
            for ev in gpfmon.globalvars.events:
                for req_ev in derived_event.events[gpfmon.globalvars.current.arch]:
                    if ev.name == req_ev.split(":")[0]:
                        ev.monitor = True
                        ev.selected_umasks = []
                        try:
                            ev.selected_umasks.append("x:[" + req_ev.split(":")[1] + "]:x")
                        except:
                            pass
                        gpfmon.globalvars.selected_events.append(ev)
                        
            derived_events_.append(derived_event)
                        
            # take care of the reference event
            # TODO: fix for all archs, remove hardcode
            if gpfmon.globalvars.current.arch == gpfmon.ARCH_X86_64:
                for ev in gpfmon.globalvars.events:
                    if ev.name == "UNHALTED_CORE_CYCLES":
                        reference_event = ev
            elif gpfmon.globalvars.current.arch == gpfmon.ARCH_IA64:
                for ev in gpfmon.globalvars.events:
                    if ev.name == "CPU_OP_CYCLES_ALL":
                        reference_event = ev

        # don't monitor the reference event por favor
        monitored_events = gpfmon.globalvars.selected_events[:]
        if gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING and \
            ev_spec == gpfmon.EV_SPEC_INDIVIDUAL:

            try:
                del monitored_events[monitored_events.index(reference_event)]
            except ValueError:
                print "reference event wasn't on the list. ok."
        
        # we're starting a new run; set it up
        current_run = gpfmon.Run(
                    command_line=cmd,
                    binary=gpfmon.widgets.entPath.get_text(),
                    mode=gpfmon.globalvars.mode,
                    event_specification=ev_spec,
#                    events=gpfmon.globalvars.selected_events[:],
                    events=monitored_events,
                    derived_events=derived_events_,
                    scenarios=scenarios_)
        current_run.reference_event = reference_event
        gpfmon.globalvars.current.project.addRun(current_run)
        gpfmon.globalvars.current.run = current_run

        # harvest event names and umasks
        if gpfmon.globalvars.mode == gpfmon.MODE_NORMAL or \
            gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING or \
            gpfmon.globalvars.mode == gpfmon.MODE_PROFILE:

            cmd += "-e "

            if gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING:
                cmd += reference_event.name + ","
                
            for event in gpfmon.globalvars.selected_events:
#                if event.monitor and event.name != reference_event.name:
#                if event.monitor:
                if len(current_run.derived_events) > 0 and event.monitor or \
                   len(current_run.derived_events) == 0 and event.monitor and gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING and event.name != reference_event.name or \
                   len(current_run.derived_events) == 0 and event.monitor and gpfmon.globalvars.mode != gpfmon.MODE_SAMPLING:
                    cmd += event.name
                    for u in event.selected_umasks:
                        cmd += ":" + u.split(":")[1].strip(" ").strip("[").strip("]")
                    cmd += ","
                else:
                    print event.name + " shouldn't be here... aie"
            cmd = cmd[0:-1]

        if ev_spec == gpfmon.EV_SPEC_DERIVED:
            for ev in gpfmon.globalvars.selected_events:
                ev.monitor = False
                ev.selected_umasks = []
            del gpfmon.globalvars.selected_events[:]
                
        if gpfmon.globalvars.mode == gpfmon.MODE_NORMAL:
            if gpfmon.widgets.mnuSystemwide.get_active() == False:
                cmd += " " + binary

        if gpfmon.globalvars.mode == gpfmon.MODE_PROFILE:
             cmd += " --short-smpl-periods=%s --long-smpl-periods=%s --resolve-addresses --smpl-entries=%s --smpl-per-function %s" % \
                (gpfmon.widgets.entShortProfPeriod.get_text(), 
                 gpfmon.widgets.entLongProfPeriod.get_text(),
                 gpfmon.widgets.entProfBufsize.get_text(),
                 binary)

        if gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING:
            cmd += " --long-smpl-periods=%s --reset-non-smpl --smpl-module=compact --smpl-entries=%s --with-header %s" % \
                (gpfmon.widgets.entLongSmplPeriod.get_text(),
                 gpfmon.widgets.entSmplBufsize.get_text(),
                 binary)

        datatype = None
        if gpfmon.globalvars.mode == gpfmon.MODE_NORMAL:
            datatype = gpfmon.DATA_NORMAL
        elif gpfmon.globalvars.mode == gpfmon.MODE_SAMPLING:
            datatype = gpfmon.DATA_SAMPLING
#            gpfmon.globalvars.current.run.result.values_per_point = len(gpfmon.globalvars.selected_events)-1
            gpfmon.globalvars.current.run.result.values_per_point = len(gpfmon.globalvars.current.run.events) + len(gpfmon.globalvars.current.run.derived_events)
        elif gpfmon.globalvars.mode == gpfmon.MODE_PROFILE:
            datatype = gpfmon.DATA_PROFILE

        print "Running %s " % cmd

        # clear the output box (for the table processor's sake - SORRY,
        # no multiple commands in the output box this time)
        b = gpfmon.widgets.txtOutput.get_buffer()
        b.delete(b.get_start_iter(), b.get_end_iter())
        
        gpfmon.BackgroundCommand(cmd).start()
        
    def btnAbort_clicked(self, widget):
        # this is quikhak style but whatever, no time toulouse
        gpfmon.globalvars.current.pipe.write("")
        
        # perhaps we should check if pfmon is still hanging around somewhere... ctrl-c might not always work?
        
        # maybe we need to check s/th before we enable the buttons again?
        gpfmon.widgets.btnExecute.set_sensitive(True)
        gpfmon.widgets.btnAttach.set_sensitive(True)
        gpfmon.widgets.btnAbort.set_sensitive(False)        
        gpfmon.globalvars.current.run.aborted = True


# ------------ Tab 1 - Events
    def lstEvents_cursor_changed(self, widget):
        model = widget.get_model()
        event = model.get_value(model.get_iter(widget.get_cursor()[0]), 2)
        gpfmon.widgets.get_widget("lblName").set_text(event.name)
        gpfmon.widgets.get_widget("lblCode").set_text(event.code)
        gpfmon.widgets.get_widget("lblCounters").set_text(event.counters.__str__())
        gpfmon.widgets.get_widget("lblDesc").set_text(event.desc)
        if len(event.umasks) > 0:
            gpfmon.widgets.btnUmasks.set_sensitive(True)
        else:
            gpfmon.widgets.btnUmasks.set_sensitive(False)
        gpfmon.widgets.get_widget("lblPebs").set_text(event.pebs)

    def lstEvents_toggled(self, cell, path, model):
        emptyset = sets.Set([])
        model_sort = gpfmon.widgets.lstEvents.get_model()
        path = model_sort.convert_path_to_child_path(path)
        model_filter = model_sort.get_model()
        path = model_filter.convert_path_to_child_path(path)
        iter = model.get_iter(path)
        toggle = model.get_value(iter, 1)

        if toggle == True:
            event = model.get_value(iter, 2)
            event.available = True	# not necessary?
            gpfmon.globalvars.used_counters.remove(event.assigned_counter)
            for ev in gpfmon.globalvars.events:
                if event.assigned_counter in ev.counters:
                    ev.available = True
            gpfmon.globalvars.selected_events.remove(event)
            event.monitor = False
            event.assigned_counter = -1
            toggle = not toggle
            model.set(iter, 1, toggle)
            rmodel = gpfmon.widgets.cmbSmplReferenceEvent.get_model()
            for element in rmodel:
                if element[0] == event.name:
                    rmodel.remove(element.iter)

        elif toggle == False:
            event = model.get_value(iter, 2)
            print "Toggled event %s" % event.name
            ctr = -1
            for x in gpfmon.globalvars.available_counters:
                if x in event.counters and x not in gpfmon.globalvars.used_counters:
                    ctr = x
                    break
            if ctr != -1:
                event.monitor = True
                gpfmon.globalvars.selected_events.append(event)
                event.assigned_counter = ctr
                gpfmon.globalvars.used_counters.add(ctr)
                for ev in gpfmon.globalvars.events:
                    if ev.counters - gpfmon.globalvars.used_counters == emptyset:
                        ev.available = False
                toggle = not toggle
                model.set(iter, 1, toggle)
                gpfmon.widgets.cmbSmplReferenceEvent.get_model().append([event.name, event])
            else:
                print "No free counters. Sorry"

        gpfmon.update_event_info()
        gpfmon.widgets.lstEvents.check_resize()

    def lstEvents_cell_data_func(self, column, cell, model, iter):
        if model.get_value(iter, 1) == True:
            cell.set_property("cell-background", "orange")
        else:
            event = model.get_value(iter, 2)
            if event.available:
                cell.set_property("cell-background", "white")
            else:
                cell.set_property("cell-background", "gray")

    def btnUmasks_clicked(self, widget):
        # get the model, or make a new one if it's missing
        model = gpfmon.widgets.lstUmasks.get_model()
        if model == None:
            model = gtk.ListStore(gobject.TYPE_BOOLEAN, gobject.TYPE_STRING)
            renderer = gtk.CellRendererToggle()
            renderer.connect('toggled', gpfmon.globalvars.all_signal_handlers["dlgUmasks"].lstUmasks_toggled, model)
            renderer.set_property("activatable", True)
            gpfmon.widgets.lstUmasks.append_column(gtk.TreeViewColumn('Use', renderer, active=False))
            gpfmon.widgets.lstUmasks.append_column(gtk.TreeViewColumn('Umask', gtk.CellRendererText(), text=1))
            gpfmon.widgets.lstUmasks.set_model(model)
        model.clear()

        # set selected umasks according to earlier selections
        e_model = gpfmon.widgets.lstEvents.get_model()
        event = e_model.get_value(e_model.get_iter(gpfmon.widgets.lstEvents.get_cursor()[0]), 2)
        for u in event.umasks:
            iter = model.append()
            model.set(iter,
                0, (u in event.selected_umasks),
                1, u)
        gpfmon.widgets.dlgUmasks.show()

    """
    def button7_clicked(self, widget):
        print "blsvsdfvs"
        model = gpfmon.widgets.lstEvents.get_model()
        modelfilter = model.filter_new()
        modelfilter.set_visible_column(1)
        gpfmon.widgets.lstEvents.set_model(modelfilter)
    """
    def cmbEventFilter_changed(self, widget):
        model = widget.get_model()
        event_regex = model[widget.get_active()][1]
        print event_regex
        e_model_filter = gpfmon.widgets.lstEvents.get_model().get_model()
        e_model = e_model_filter.get_model()
        for row in e_model:
#            print row[0]
            if re.match(event_regex, row[0]):
                row[3] = True
            else:
                row[3] = False
        print "Refiltering..."
        e_model_filter.refilter()

# ------------ Tab 2 - Options
    def rdoNormal_clicked(self, widget):
        gpfmon.globalvars.mode = gpfmon.MODE_NORMAL
        gpfmon.widgets.rdoGraphPie.set_sensitive(False)
        gpfmon.widgets.rdoGraphHStacked.set_sensitive(False)
        gpfmon.widgets.rdoGraphBar.set_sensitive(False)
        gpfmon.widgets.rdoGraphLine.set_sensitive(False)

    def rdoSampling_toggled(self, widget):
        state = widget.get_active()
        if widget.get_active() == True:
            gpfmon.globalvars.mode = gpfmon.MODE_SAMPLING
        gpfmon.widgets.frmSampling.set_sensitive(state)
        gpfmon.widgets.rdoGraphPie.set_sensitive(not state)
        gpfmon.widgets.rdoGraphHStacked.set_sensitive(not state)
        gpfmon.widgets.rdoGraphBar.set_sensitive(not state)
        gpfmon.widgets.rdoGraphLine.set_sensitive(state)
        gpfmon.widgets.rdoGraphLine.set_active(True)

    def rdoProfile_toggled(self, widget):
        state = widget.get_active()
        if widget.get_active() == True:
            gpfmon.globalvars.mode = gpfmon.MODE_PROFILE
        gpfmon.widgets.frmProfile.set_sensitive(state)
        gpfmon.widgets.rdoGraphPie.set_sensitive(state)
        gpfmon.widgets.rdoGraphHStacked.set_sensitive(state)
        gpfmon.widgets.rdoGraphBar.set_sensitive(state)
        gpfmon.widgets.rdoGraphLine.set_sensitive(not state)
        gpfmon.widgets.rdoGraphPie.set_active(True)

    # Follow
    def mnuFollowAll_activate(self, widget):
        # the widget becomes active before entering this function
        if widget.get_active() == True:
            gpfmon.widgets.get_widget("mnuFollowFork").set_active(False)
            gpfmon.widgets.get_widget("mnuFollowVfork").set_active(False)
            gpfmon.widgets.get_widget("mnuFollowPthread").set_active(False)
            gpfmon.widgets.get_widget("mnuFollowExec").set_active(False)
            gpfmon.widgets.get_widget("mnuFollowFork").set_sensitive(False)
            gpfmon.widgets.get_widget("mnuFollowVfork").set_sensitive(False)
            gpfmon.widgets.get_widget("mnuFollowPthread").set_sensitive(False)
            gpfmon.widgets.get_widget("mnuFollowExec").set_sensitive(False)
        else:
            gpfmon.widgets.get_widget("mnuFollowFork").set_sensitive(True)
            gpfmon.widgets.get_widget("mnuFollowVfork").set_sensitive(True)
            gpfmon.widgets.get_widget("mnuFollowPthread").set_sensitive(True)
            gpfmon.widgets.get_widget("mnuFollowExec").set_sensitive(True)

    def cmbTimeFormat_changed(self, widget):
#        gpfmon.globalvars.data2.update_time()
        if gpfmon.globalvars.graph != None:
            gpfmon.globalvars.graph.update_time()
#            gpfmon.globalvars.graph.update_data(gpfmon.globalvars.data2)

# ------------ Tab ? - Derived Events
    def tvDerivedEvents_cursor_changed(self, widget):
        model = widget.get_model()
        row = model[model.get_iter(widget.get_cursor()[0])]
        derived_event = gpfmon.globalvars.derived_events.getElementByIndex(row[1])

        if derived_event != None:
            gpfmon.widgets.lblDerivedEventName.set_text(derived_event.name)
            gpfmon.widgets.lblDerivedEventDescription.set_label(derived_event.description)
            try:
                gpfmon.widgets.lblDerivedEventFormula.set_text(derived_event.formulas[gpfmon.globalvars.current.arch].replace(",", "\n")) # TEMP!
            except:
                gpfmon.widgets.lblDerivedEventFormula.set_markup("<span foreground='#bb2233'>Event unsupported on this architecture</span>")
            gpfmon.widgets.lblDerivedEventArch.set_text(repr([k for k, v in derived_event.formulas.iteritems()]))
        else:
            gpfmon.widgets.lblDerivedEventName.set_text("None")
            gpfmon.widgets.lblDerivedEventDescription.set_label("")
            gpfmon.widgets.lblDerivedEventFormula.set_text("") # TEMP!
            gpfmon.widgets.lblDerivedEventArch.set_text("")
                
# ------------ Tab 3 - Output
    def btnCopy_clicked(self, widget):
        b = gpfmon.widgets.txtOutput.get_buffer()
        selection = b.get_selection_bounds()
        if len(selection) == 0:
            b.select_range(b.get_start_iter(), b.get_end_iter())
        b.copy_clipboard(gtk.clipboard_get(gtk.gdk.SELECTION_CLIPBOARD))
        b.select_range(b.get_start_iter(), b.get_start_iter())

    def btnCut_clicked(self, widget):
        b = gpfmon.widgets.txtOutput.get_buffer()
        b.select_range(b.get_start_iter(), b.get_end_iter())
        b.cut_clipboard(gtk.clipboard_get(gtk.gdk.SELECTION_CLIPBOARD), True)
        
    def btnClear_clicked(self, widget):
        b = gpfmon.widgets.txtOutput.get_buffer()
        b.delete(b.get_start_iter(), b.get_end_iter())

    def chkAutoscroll_toggled(self, widget):
        gpfmon.globalvars.autoscroll = gpfmon.widgets.chkAutoscroll.get_active()
    
    def btnSaveOutput_clicked(self, widget):
        
        dlg = gtk.FileChooserDialog(title = "Save as...", 
                                    parent = gpfmon.widgets.wndMain,
                                    action = gtk.FILE_CHOOSER_ACTION_SAVE,
                                    buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_SAVE, gtk.RESPONSE_OK))
        cmb = gtk.combo_box_new_text()
        cmb.append_text("Save all output to text file")
        cmb.append_text("Save results to CSV")
        cmb.set_active(0)
        dlg.set_extra_widget(cmb)

        response = dlg.run()
        if response == gtk.RESPONSE_OK:
            filename = dlg.get_filename()
            text = ""
            if cmb.get_active_text == "Save all output to a text file":
                buffer = gpfmon.widgets.txtOutput.get_buffer()  
                text = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(),  False)
            elif cmb.get_active_text() == "Save results to a CSV file":
                mode = gpfmon.globalvars.current.run.mode
                result = gpfmon.globalvars.current.run.result
                if mode == gpfmon.MODE_NORMAL:
                    text += "event, samples\n"
                    for key, value in result.iteritems():
                        text += "%s, %s\n" % (key, value)
                elif mode == gpfmon.MODE_SAMPLING:
                    for element in result:
                        text += "%s\n" % re.sub("\s+", ", ", element.raw)
                elif mode == gpfmon.MODE_PROFILE:
                    text += "samples, percent, percent_cumulative, function, library\n"
                    for element in result:
                        text += "%s, %s, %s, %s, %s\n" % (element.samples, element.percent, element.percent_cum, element.function, element.library)
            else:
                raise Exception("I shouldn't be here!")

            try:
                f = open(filename, "w")
                f.write(text)
                f.flush()
                f.close()
            except:
                showModalErrorDialog("Access error", "Saving the file failed")
        dlg.destroy()

    def handlebox2_child_attached(self, widget, child):
        child.set_size_request(-1, -1)
        
    def handlebox2_child_detached(self, widget, child):
        alloc = child.get_allocation()
        child.set_size_request(alloc.width, alloc.height)
                
    def handlebox2_event(self, widget, event):
        if event.type == gtk.gdk._2BUTTON_PRESS:
            print "Double click"
            widget.activate()

# ------------ Tab 4 - Analysis
# ------------ Tab 5 - Profile


    def rdoGraphPie_clicked(self, widget):
        for child in gpfmon.widgets.scrGraphs.get_children():
            gpfmon.widgets.scrGraphs.remove(child)
        gpfmon.globalvars.graph = gpfmon.PieGraph()     
#        gpfmon.globalvars.graph.update_data(gpfmon.globalvars.data2)
        if gpfmon.globalvars.current.run != None and gpfmon.globalvars.current.run.mode == gpfmon.MODE_PROFILE:
            gpfmon.globalvars.graph.update_data(gpfmon.globalvars.current.run.result.getGraphData())
        gpfmon.globalvars.graph.set_property("visible", True)
        gpfmon.widgets.scrGraphs.add_with_viewport(gpfmon.globalvars.graph)

    def rdoGraphHStacked_clicked(self, widget):
        for child in gpfmon.widgets.scrGraphs.get_children():
            gpfmon.widgets.scrGraphs.remove(child)
#        gpfmon.widgets.scrGraphs.remove(gpfmon.globalvars.graph)
        gpfmon.globalvars.graph = gpfmon.HStackedGraph()     
#        gpfmon.globalvars.graph.update_data(gpfmon.globalvars.data2)
        if gpfmon.globalvars.current.run != None and gpfmon.globalvars.current.run.mode == gpfmon.MODE_PROFILE:
            gpfmon.globalvars.graph.update_data(gpfmon.globalvars.current.run.result.getGraphData())
        gpfmon.globalvars.graph.set_property("visible", True)
        gpfmon.widgets.scrGraphs.add_with_viewport(gpfmon.globalvars.graph)

    def rdoGraphBar_clicked(self, widget):
        for child in gpfmon.widgets.scrGraphs.get_children():
            gpfmon.widgets.scrGraphs.remove(child)
#        gpfmon.widgets.scrGraphs.remove(gpfmon.globalvars.graph)
        gpfmon.globalvars.graph = gpfmon.BarGraph()     
#        gpfmon.globalvars.graph.update_data(gpfmon.globalvars.data2)
        if gpfmon.globalvars.current.run != None and gpfmon.globalvars.current.run.mode == gpfmon.MODE_PROFILE:
            gpfmon.globalvars.graph.update_data(gpfmon.globalvars.current.run.result.getGraphData())
        gpfmon.globalvars.graph.set_property("visible", True)
        gpfmon.widgets.scrGraphs.add_with_viewport(gpfmon.globalvars.graph)

    # TODO: add graph factory
    def rdoGraphLine_clicked(self, widget):
        for child in gpfmon.widgets.scrGraphs.get_children():
            gpfmon.widgets.scrGraphs.remove(child)
#        gpfmon.widgets.scrGraphs.remove(gpfmon.globalvars.graph)
        gpfmon.globalvars.graph = gpfmon.LineGraph()
#        gpfmon.globalvars.graph.update_data(gpfmon.globalvars.data2)
        if gpfmon.globalvars.current.run != None and gpfmon.globalvars.current.run.mode == gpfmon.MODE_SAMPLING:
            gpfmon.globalvars.graph.update_data(gpfmon.globalvars.current.run.result.getGraphData())
        gpfmon.globalvars.graph.set_property("visible", True)
        gpfmon.widgets.scrGraphs.add_with_viewport(gpfmon.globalvars.graph)
        
    def chkAlternativeLayout_toggled(self, widget):
        gpfmon.globalvars.graph.queue_draw()        
        
    def chkLog_toggled(self, widget):
        gpfmon.globalvars.graph.queue_draw()        
        
    def btnExport_clicked(self, widget):
        dlg = gtk.FileChooserDialog(title = "Save as...", 
                                    parent = gpfmon.widgets.wndMain,
                                    action = gtk.FILE_CHOOSER_ACTION_SAVE,
                                    buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_SAVE, gtk.RESPONSE_OK))
        model = gtk.ListStore(gobject.TYPE_STRING)
        model.append(["PNG"])
        model.append(["PDF"])
        cmb = gtk.ComboBox(model)
        renderer = gtk.CellRendererText()
        cmb.pack_start(renderer, True)
        cmb.add_attribute(renderer, 'text', 0)
        cmb.set_active(0)
        dlg.set_extra_widget(cmb)
        response = dlg.run()
        if response == gtk.RESPONSE_OK:
            filename = dlg.get_filename()

            if cmb.get_active_text() == "PNG":
                if len(filename) < 4 or filename[-4:] != ".png":
                    filename += ".png"
                gpfmon.globalvars.graph.set_export_png_filename(filename)
                gpfmon.globalvars.graph.set_export_png(True)
            if cmb.get_active_text() == "PDF":
                if len(filename) < 4 or filename[-4:] != ".pdf":
                    filename += ".pdf"
                gpfmon.globalvars.graph.set_export_pdf_filename(filename)
                gpfmon.globalvars.graph.set_export_pdf(True)

            # TODO: check if there is a do_events call needed before this line;
            #       might have race conditions
            gpfmon.globalvars.graph.queue_draw()
        dlg.destroy()

    def scrGraphs_button_press_event(self, widget, event):
        if event.type == gtk.gdk.BUTTON_PRESS and event.button == 3:
            gpfmon.widgets.mnuPopupGraph.popup(None, None, None, event.button, event.time, None)

    def mnuGraphZoomIn_activate(self, widget):
        pass
        
    def mnuGraphZoomOut_activate(self, widget):
        pass
        
    def mnuGraphProperties_activate(self, widget):
        pass
        
# ------------ Other
    def yup(self, widget, whatever):
        gpfmon.widgets.wndSplash.hide()

    def xyz(self, widget):
        print "ext"
        gpfmon.widgets.hbxMessage.hide()
