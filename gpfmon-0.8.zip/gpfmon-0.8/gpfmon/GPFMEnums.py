# event selection mode
(EV_SPEC_INDIVIDUAL,
EV_SPEC_DERIVED,
EV_SPEC_SCENARIO) = range(3)

# run mode
(MODE_NORMAL,
MODE_SAMPLING,
MODE_PROFILE) = range(3)

# time formats for visualisation
(TIME_R_HMSF,
TIME_R_MSF,
TIME_R_MS,
TIME_R_SEC,
TIME_R_MSEC,
TIME_E_HITS,                        # reference event hits (sample no., bas
TIME_A_HMS,
TIME_A_UNIX) = range(8) 

# uname -i
(ARCH_X86_64,
ARCH_IA64,
ARCH_CELL,
ARCH_MIPS,
ARCH_SPARC) = ("x86_64", "ia64", "cell", "mips", "sparc")
