import gpfmon

class DlgAbortSignalHandlers:
    def btnDlgAbortAbort_clicked(self, widget):
        gpfmon.abort_session()
        gpfmon.widgets.dlgAbort.hide()
        
    def btnDlgAbortOK_clicked(self, widget):
        gpfmon.widgets.dlgAbort.hide()
