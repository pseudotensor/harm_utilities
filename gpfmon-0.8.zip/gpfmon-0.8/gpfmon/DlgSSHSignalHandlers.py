import pygtk, gtk, gobject, sets, os, GPFMClasses, gpfmon, re, pickle

class DlgSSHSignalHandlers:
    def btnDlgSSH_Cancel_clicked(self, widget):
        gpfmon.widgets.get_widget("dlgSSH").hide()

    def btnDlgSSH_OK_clicked(self, widget):    
        if len(gpfmon.widgets.entUsername.get_text()) == 0 or\
            len(gpfmon.widgets.entHostname.get_text()) == 0 or\
            len(gpfmon.widgets.entPassword.get_text()) == 0:
            gpfmon.showModalErrorDialog("Data missing", "You need to supply the host name, user name and password in order to connect")
            return - 1
            
        # if the hostname is an ip address, ignore it...
        hostname = gpfmon.widgets.get_widget("entHostname").get_text()
        if not re.match("\d+\.\d+\.\d+\.\d+$", hostname):
            # ...if not, check whether the name will resolve
            reply = os.popen("host %s" % hostname).read()
            if not re.match(".*has address.*", reply) and not re.match(".*domain name pointer.*", reply):
                gpfmon.showModalErrorDialog("Host does not exist or lookup failure", "The host you have entered does not exist")
                return -1
        gpfmon.widgets.get_widget("dlgSSH").hide()
        conn = GPFMClasses.SSHConnection2()
#        hostname = gpfmon.widgets.get_widget("entHostname").get_text()
#        username = gpfmon.widgets.get_widget("entUsername").get_text()
#        password = gpfmon.widgets.get_widget("entPassword").get_text()
        gpfmon.widgets.get_widget("staStatusbar").push(0, "Connecting to %s..." % hostname)
        gpfmon.set_hourglass_cursor(True)
        gpfmon.update_interface()
#        conn.connect(hostname, username, password)

        # TODO: add more elaborate checks (regex)
        #       - illegal chars
        #       - emptiness
        path = gpfmon.widgets.entEnvPath.get_text()
        if len(path) == 0:
            path = "$PATH"
        ldpath = gpfmon.widgets.entEnvLDPath.get_text()
        if len(ldpath) == 0:
            ldpath = "$LD_LIBRARY_PATH"
        pfmon_executable = gpfmon.widgets.entPfmonExecutable.get_text()
        if len(pfmon_executable) == 0:
            pfmon_executable = "pfmon"
        
        profile = gpfmon.SSHProfile("NODESC",
            gpfmon.widgets.entHostname.get_text(),
            gpfmon.widgets.entUsername.get_text(),
            gpfmon.widgets.entPassword.get_text(),
            path,
            ldpath,
            pfmon_executable,
#            gpfmon.widgets.entEnvPath.get_text(),
#            gpfmon.widgets.entEnvLDPath.get_text(),
            gpfmon.widgets.entExecAfterLogin.get_text(),
            gpfmon.widgets.entExecBefore.get_text(),
            gpfmon.widgets.entExecAfter.get_text(),
            gpfmon.widgets.entSSHCmdline.get_text())
        conn.connect(profile)
        
        if conn.isConnected():
            gpfmon.globalvars.sshconnection = conn
            gpfmon.widgets.get_widget("staStatusbar").push(0, "Connected as %s@%s" % (profile.username, profile.hostname))
            gpfmon.globalvars.current.hostname = profile.hostname
            gpfmon.globalvars.current.username = profile.username
            
            # BUG
#            btn = gpfmon.widgets.get_widget("btnConnect")
#            btn.set_label("gtk-disconnect")
#            btn.set_use_stock(True)
            gpfmon.widgets.get_widget("rdoLocal").set_sensitive(False)
            gpfmon.widgets.get_widget("btnAttach").set_sensitive(True)
            gpfmon.widgets.get_widget("btnExecute").set_sensitive(True)
            gpfmon.widgets.get_widget("btnConnect").set_sensitive(False)
            gpfmon.widgets.get_widget("btnDisconnect").set_sensitive(True)

            # this function will disable the buttons if there is no pfmon support
            gpfmon.refresh_event_list()
        else:
            gpfmon.showModalErrorDialog("Unable to connect", "The program was unable to establish a connection")
            gpfmon.widgets.get_widget("staStatusbar").push(0, "Disconnected")
            gpfmon.widgets.get_widget("rdoLocal").set_sensitive(True)
            
            # inform the user of the action
            gpfmon.widgets.get_widget("staStatusbar").push(0, "Disconnected")
            gpfmon.widgets.dlgSSH.show()
        gpfmon.set_hourglass_cursor(False)
        
    # I know you hate me for not using a plain text format...
    # well I guess I'm too lazy when such convenient functions are lying around
    def btnDlgSSH_Save_clicked(self, widget):
        # TODO: remove this once the description text box is done and
        #       add checking for the "Blank" list element there
#        model = gpfmon.widgets.cmbSSHProfile.get_model()
#        if model[gpfmon.widgets.cmbSSHProfile.get_active()][1] < 0:
#            return	# the blank one

        # 1. TODO: show dialog box with name (default: user@host)
        username = gpfmon.widgets.entUsername.get_text()
        hostname = gpfmon.widgets.entHostname.get_text()
        if len(username) == 0 or len(hostname) == 0:
            gpfmon.showModalErrorDialog("Data missing", "You must fill out at least the host name and the user name fields")
            return
        description = "%s@%s" % (username, hostname)

        # 2. TODO: show overwrite prompt, if needed
        i = 0
        for element in gpfmon.globalvars.sshopts:
            if element.description == description:
                break
            i += 1
        
        # 3. append item to model, append item to the global list with profiles
        model = gpfmon.widgets.cmbSSHProfile.get_model()
        newprofile = gpfmon.SSHProfile(description,
            hostname,
            username,
            gpfmon.widgets.entPassword.get_text(),
            gpfmon.widgets.entEnvPath.get_text(),
            gpfmon.widgets.entEnvLDPath.get_text(),
            gpfmon.widgets.entPfmonExecutable.get_text(),
            gpfmon.widgets.entExecAfterLogin.get_text(),
            gpfmon.widgets.entExecBefore.get_text(),
            gpfmon.widgets.entExecAfter.get_text(),
            gpfmon.widgets.entSSHCmdline.get_text())
        
        if i < len(gpfmon.globalvars.sshopts):
            gpfmon.globalvars.sshopts.remove(gpfmon.globalvars.sshopts[i])
        else:
            model.append([newprofile.description, i])
        gpfmon.globalvars.sshopts.insert(i, newprofile)

        # several things can go wrong here
        # TODO: handle the situation with grace
#        try:
        pickle.dump(gpfmon.globalvars.sshopts,
                    open(gpfmon.globalvars.config.file_sshopts, "w"),
                    pickle.HIGHEST_PROTOCOL)
#        except:
#            raise Exception("TODO")
        
    def btnDlgSSH_Delete_clicked(self, widget):
        model = gpfmon.widgets.cmbSSHProfile.get_model()
        id = model[gpfmon.widgets.cmbSSHProfile.get_active()][1]
        if id == -1:
            return

        gpfmon.globalvars.sshopts.pop(id)
        model.remove(gpfmon.widgets.cmbSSHProfile.get_active_iter())
        for item in model:
            if item[1] > id:
                item[1] -= 1
        gpfmon.widgets.cmbSSHProfile.set_active(0)

        pickle.dump(gpfmon.globalvars.sshopts,
                    open(gpfmon.globalvars.config.file_sshopts, "w"),
                    pickle.HIGHEST_PROTOCOL)
        
    def cmbSSHProfile_changed(self, widget):
        model = gpfmon.widgets.cmbSSHProfile.get_model()
        id = model[widget.get_active()][1]
        if id == -1:
            p = gpfmon.SSHProfile()
        else:
            p = gpfmon.globalvars.sshopts[id]
        gpfmon.widgets.entHostname.set_text(p.hostname)
        gpfmon.widgets.entUsername.set_text(p.username)
        gpfmon.widgets.entPassword.set_text(p.password)
        gpfmon.widgets.entEnvPath.set_text(p.path)
        gpfmon.widgets.entEnvLDPath.set_text(p.ldpath)
        gpfmon.widgets.entPfmonExecutable.set_text(p.pfmon_executable)
        gpfmon.widgets.entExecAfterLogin.set_text(p.exec_after_login)
        gpfmon.widgets.entExecBefore.set_text(p.exec_before)
        gpfmon.widgets.entExecAfter.set_text(p.exec_after)
        gpfmon.widgets.entSSHCmdline.set_text(p.ssh_cmdline)

    def get_selected_profile(self):
        model = gpfmon.widgets.cmbSSHProfile.get_model()
        id = model[gpfmon.widgets.cmbSSHProfile.get_active()][1]
        if id == -1:
            return gpfmon.SSHProfile()
        else:
            return gpfmon.globalvars.sshopts[id]
