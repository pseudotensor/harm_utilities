#!/usr/bin/env python

# TODO: add optional color-coded legend (should be fairly universal)
# TODO: ? horizontal bar graph
# TODO: add generic grid drawing
# TODO: add generic labels under the axes

import pygtk, gtk, gtk.glade, gobject, random, math, gpfmon
import cairo
from gpfmon import DataPoint

class W:
    pass

class GraphInfo:
    def __init__(self, info=(0, 0, 0, 0, 0, 0, 0)):
        (self.maxval,
        self.num_samples,
        self.pix_per_sample,
        self.num_ticks_x,
        self.pix_per_tick_x,
        self.num_ticks_y,
        self.pix_per_tick_y) = info
        pass

class Graph(gtk.DrawingArea):
    (TOP,
    YCENTER,
    YAUTO,
    BOTTOM,
    UNDER,
    OVER,
    LEFT,
    XCENTER,
    RIGHT) = (1, 2, 4, 8, 16, 32, 64, 128, 256)
    
    (FONT_TINY,
    FONT_SMALL,
    FONT_MEDIUM,
    FONT_LARGE,
    FONT_HUGE) = (9, 10, 12, 16, 20)

    palette = [ "#ff9900", "#0033cc", "#ba0099", "#abff00",
                "#ff0000", "#00ff00", "#0000ff", "#000000",
                "#b36b00", "#00248f", "#8f006b", "#6bb300",
                "#b32400", "#007d48", "#400099", "#b3a000"]
        
    def __init__(self):
        gtk.DrawingArea.__init__(self)
        self.connect("expose-event", self.expose)
        self.H = 0		# the current height of the graph area
        self.W = 0		# the current width of the graph area
        self.rootx = 0		# the location of the root X coordinate
        self.rooty = 0		# the location of the root Y coordinate
#        self.vmargin = 20	# the margin (whitespace on the sides in px - vertical)
#        self.hmargin = 20	# the margin (whitespace on the sides in px - horizontal)
        self.data = {}		# the data
        self.info = GraphInfo() # used for all but sampling data
        self.infos = []		# used for sampling data
        self.export_pdf = False	# 1-time export flag
        self.export_pdf_filename = None
        self.export_png = False	# 1-time export flag
        self.export_png_filename = None
        
        self.oldH = None
        self.oldW = None
        self.oldhash = None

    def expose(self, widget, event):
        """FIXME
        # first check if we need to draw at all
        newhash = hash(repr(self.data))
        size = self.get_allocation()
        W = size.width
        H = size.height
        if self.oldhash == newhash and self.oldH == H and self.oldW == W and \
            not self.export_png and not self.export_pdf:
            print "nodraw"
            return False
        else:
            self.oldhash = newhash
            self.oldH = H
            self.oldW = W
        """
 
# TODO: FIXME       
#        self.set_size_request(2000, 450)

        # check if export to pdf was requested
        if not self.export_pdf:
            self.context = widget.window.cairo_create()
        else:
            surface = cairo.PDFSurface(self.export_pdf_filename, 800, 450)
            self.context = cairo.Context(surface)

        # request clipping to save time if not exporting
        if not self.export_png and not self.export_pdf:
            self.context.rectangle(event.area.x, event.area.y, event.area.width, event.area.height)
            self.context.clip()
        self.context.set_source_rgb(1, 1, 1)
        self.context.paint()

        # if no data, show nothng; else draw.
        if len(self.data) == 0:
            self.show_no_data(self.context)
#            self.generate_random_data()
        if len(self.data) > 0:
#            self.context.scale(2,2)
            self.draw(self.context)
            self.draw_watermark(self.context)
            if self.export_png:
                print "Writing PNG file (%s)..." % self.export_png_filename
                self.set_export_png(False)
                surface = self.context.get_target()
                surface.write_to_png(self.export_png_filename)
                surface.finish()
            if self.export_pdf:
                print "Writing PDF file (%s)..." % self.export_pdf_filename
                self.set_export_pdf(False)
                self.context.show_page()
#                surface.finish()
                self.queue_draw()
        return False

    # show a nice screen stating that there is nothing to see here
    def show_no_data(self, ctx):
        size = self.get_allocation()
        self.W = size.width
        self.H = size.height
        
        # stripes (let's pray that W > H :\\)
        ctx.rotate(1)
        ctx.set_source_rgb(1.0, 1.0, 0.85)
        rng = self.W/30
        stripe_w = 20
        for i in range(rng):
            ctx.rectangle(0, (i-rng*0.75)*stripe_w*2, self.W*1.2, stripe_w)
        ctx.fill()
        ctx.set_source_rgb(0.90, 0.90, 0.90)
        for i in range(rng):
            ctx.rectangle(0, (i-rng*0.75)*stripe_w*2+stripe_w, self.W*1.2, stripe_w)
        ctx.fill()
        
        # "NO DATA"
        ctx.rotate(-1)
        text = "No data"
        ctx.set_font_size(self.get_font(Graph.FONT_HUGE))
        extents = ctx.text_extents(text)
        ctx.move_to(self.W/2 - extents[2]/2, self.H/2 - extents[1]/2)
        ctx.set_source_rgb(0, 0, 0)
        ctx.show_text(text)
        ctx.stroke()
    
    def draw(self, context):
        raise Exception("This method should be overridden")

    def show_title(self, ctx, title, location=(TOP | XCENTER)):
        ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
        ctx.set_source_rgb(0, 0, 0)
        extents = ctx.text_extents(title)
        width = extents[2]
        if location & Graph.TOP:
            Y = self.vmargin * 0.5
            if Y < 20: Y = 20
        elif location & Graph.BOTTOM:
            Y = self.H - self.vmargin * 0.3
            if Y > (self.H - 20): Y = self.H - 20
        elif location & Graph.YCENTER:
            raise Exception("not implemented yet")            
        if location & Graph.LEFT:
            X = self.hmargin * 0.3
            if X < 20: X = 20
        elif location & Graph.RIGHT:
            # this might be buggy
            X = self.W - self.hmargin * 0.3 - width
        elif location & Graph.XCENTER:
            X = self.W / 2 - width / 2
        ctx.move_to(X, Y)
        ctx.show_text(title)
        ctx.stroke()
        
    def draw_watermark(self, ctx):
        ctx.set_font_size(self.get_font(Graph.FONT_TINY))
        ctx.set_source_rgb(0.4, 0.4, 0.4)
        txt = "gpfmon generated graph"
        extents = ctx.text_extents(txt)
        ctx.move_to(self.W - extents[2] - 15, self.H - 5)
        ctx.show_text(txt)
        ctx.stroke()

    def draw_axis(self, ctx):
        ctx.set_font_size(self.get_font(Graph.FONT_SMALL))
        ctx.set_dash([])
        ctx.set_line_width(1)
        ctx.set_source_rgb(0, 0, 0)
        
        # Axes
        ctx.move_to(self.rootx, self.rooty)
        ctx.line_to(self.W - self.hmargin, self.rooty)
        ctx.move_to(self.rootx, self.rooty)
        ctx.line_to(self.rootx, self.vmargin)
        ctx.stroke()

        # X ticks
        ctx.move_to(self.rootx, self.rooty)
        for i in range(self.info.num_ticks_x + 1):
            ctx.move_to(self.rootx + i*self.info.pix_per_tick_x, self.rooty)
            ctx.rel_line_to(0, 5)
        ctx.stroke()
        
        # Y ticks
        ctx.move_to(self.rootx, self.rooty)
        for i in range(self.info.num_ticks_y + 1):
            ctx.move_to(self.rootx, self.rooty - i*self.info.pix_per_tick_y)
            ctx.rel_line_to(-5, 0)
        ctx.stroke()

        # Y label
        ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
        extents = ctx.text_extents("%")
        ctx.move_to(self.hmargin/2, (self.H + extents[2]) / 2)
        ctx.show_text("%")
        ctx.set_source_rgb(0, 0, 0)

        # Y labels
        for i in range(self.info.num_ticks_y + 1):
            label = self.info.val_per_tick_y * i

            # make the labels a bit more readable... puny humans, can't read zeroes
            if label >= 1000000:
                txt = str(label / 1000000.0) + " M"
            elif label >= 1000:
                txt = str(int(label))
                txt = txt[:-3] + "'" + txt[-3:]
            else:
                txt = str(label)
            
            # draw'em!
            extents = ctx.text_extents(txt)
            ctx.move_to(self.rootx - extents[2] - 10,
                        self.rooty - i*self.info.pix_per_tick_y - extents[1]/2)
            ctx.show_text(txt)
        ctx.stroke()

    def draw_value_labels(self, ctx, location = (TOP | XCENTER)):
        ctx.set_source_rgb(0, 0, 0)
        ctx.set_font_size(self.get_font(Graph.FONT_SMALL))
        i = 0
        for key, value in self.data:
            txt = str(value)
            extents = ctx.text_extents(txt)

            if location & Graph.TOP:
                Y = self.rooty - value * self.info.scaley - extents[3]
            elif location & Graph.BOTTOM:
                raise Exception("not implemented yet")

            if location & Graph.LEFT:
                X = self.rootx + i*self.info.pix_per_sample - extents[2]/2
            elif location & Graph.XCENTER:
                X = self.rootx + (i+0.5)*self.info.pix_per_sample - extents[2]/2
            elif location & Graph.RIGHT:
                raise Exception("not implemented yet")
                
            ctx.move_to(X, Y)
            ctx.show_text(txt)
            i += 1
        ctx.stroke()

    def draw_key_labels(self, ctx, location = BOTTOM | XCENTER):
        ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
        ctx.set_source_rgb(0, 0, 0)            
        i = 0
        # TODO: add spaces between labels and other objects after
        #       vertical (rotated) text has been patented ;-)
        ctx.rotate(-math.pi / 2)
        for key, value in self.data:
            xmargin = ymargin = 10
            
            extents = ctx.text_extents(key)
            X = Y = 0
            height = extents[2]
            width = extents[3]
            if location & Graph.LEFT:
                X = i * self.info.pix_per_sample + width
            elif location & Graph.XCENTER:
                X = i * self.info.pix_per_sample + self.info.pix_per_sample/2.0 + width/2.0
            elif location & Graph.RIGHT:
                X = (i+1) * self.info.pix_per_sample * 1.0 
            else:
                raise Exception("no x alignment specified")
            X += self.rootx
            
            ylocation = location
            
            if location & Graph.YAUTO:
                if height > (value * self.info.scaley):
                    ylocation |= Graph.OVER
                else:
                    ylocation |= Graph.YCENTER

            if ylocation & Graph.TOP:
                Y = self.rooty - self.info.scaley * value + height
            elif ylocation & Graph.YCENTER:
                Y = self.rooty - self.info.scaley * value / 2 + height / 2
            elif ylocation & Graph.BOTTOM:
                Y = self.rooty
            elif ylocation & Graph.OVER:
                Y = self.rooty - self.info.scaley * value - 3*ymargin
            elif ylocation & Graph.UNDER:
                Y = self.rooty + height + ymargin
            else:
                raise Exception("no y alignment specified")
            
            ctx.move_to(-200, 100)
            ctx.move_to(-Y, X)
            ctx.show_text(key)
            i += 1
        ctx.stroke()
        ctx.rotate(math.pi / 2)

    # this calculates DATASET SPECIFIC info - extents, number of samples etc
    def calculate_graph_info(self, maxval, array):
        info = GraphInfo()
        info.maxval = maxval
        info.num_samples = len(array)
        info.pix_per_sample = (self.W - self.rootx - self.hmargin) / info.num_samples

        # TODO: move this if elsewhere
        # this instrospection is ok since piegraph is the only one that
        # doesn't need these calculations
        if self.__class__ != PieGraph:
            # Y axis autoscaling
            order = int(math.log10(info.maxval))	# the order of the data
            coef = math.pow(10, order)			# 10's, 100's, 1000's?
            temp = info.maxval / coef
            temp = int(temp * 10)				# the first 2 digits
            temp += 1
            if temp < 20:
                info.num_ticks_y = temp
                info.val_per_tick_y = coef * .1
            elif temp < 50:
                info.num_ticks_y = int(temp*2*0.1) + 1
                info.val_per_tick_y = 5 * coef * .1
            else:
                info.num_ticks_y = int(temp*0.1) + 1
                info.val_per_tick_y = coef

            # how many pixels per each y tick
            info.pix_per_tick_y = \
                                (self.rooty - self.vmargin) / info.num_ticks_y

            # y scaling factor for the data
            info.scaley = (self.rooty - self.vmargin) / \
                                (info.val_per_tick_y*info.num_ticks_y)

        if self.__class__ == LineGraph:
            # X axis autoscaling
            order = math.floor(math.log10(self.data.timestamps[-1]))	# the order of the data
            coef = math.pow(10, order)			# 10's, 100's, 1000's?
            temp = self.data.timestamps[-1] / coef
            temp = int(temp * 10)				# the first 2 digits
            temp += 1
            if temp < 20:
                info.num_ticks_x = int(temp)
                info.val_per_tick_x = coef * .1
            elif temp < 50:
                info.num_ticks_x = int(temp*2*0.1) + 1
                info.val_per_tick_x = 5 * coef * .1
            else:
                info.num_ticks_x = int(temp*0.1) + 1
                info.val_per_tick_x = coef

            # how many pixels per each x tick
            info.pix_per_tick_x = \
                                (self.W - self.rootx - self.hmargin) / info.num_ticks_x

            # x scaling factor for the data
            info.scalex = (self.W - self.rootx - self.hmargin) / \
                                (info.val_per_tick_x*info.num_ticks_x)
        
        return info

        
    # TODO: optimize this not to recalculate stuff if H and W hasn't changed,
    # (but handle data changes somehow)
    def update_info(self, array):
        size = self.get_allocation()
        self.W = size.width
        self.H = size.height
        self.vmargin = self._vmargin * self.H
        self.hmargin = self._hmargin * self.W
        self.update_info_local()
        
        if issubclass(gpfmon.GraphDataSampling, array.__class__):
            maxtable = []
            for i in range(array.parent.values_per_point):
                maxtable.append(max([x.values[i] for x in array]))
               
            # TODO: obviously this is just temporary. fix me
            self.infos = []
            if gpfmon.widgets.chkAlternativeLayout.get_active() == True:
                # value sets are not independent
                maxval = max(maxtable)
                info = self.calculate_graph_info(maxval, array)
                self.info = info
                for i in range(array.parent.values_per_point):
                    self.infos.append(info)
            else:
                # value sets are independent (implies different axes later on)
                for i in range(array.parent.values_per_point):
                    self.infos.append(self.calculate_graph_info(maxtable[i], array))
                    # temp plug
                    self.info = self.infos[0]
        else:
            maxval = max(array.values)
            self.info = self.calculate_graph_info(maxval, array)

    def get_font(self, font):
        return font*(self.H*0.9/400.0)

    def get_color(self, index):
        colorname = Graph.palette[index][1:]
        r = int(colorname[0:2], 16) / 255.0
        g = int(colorname[2:4], 16) / 255.0
        b = int(colorname[4:], 16) / 255.0
        return (r, g, b)

    def update_data_time(self):
        if data.type == gpfmon.DATA_SAMPLING:
            for item in self.data:
                pass
                
    # this function causes the whole graph to be drawn again.
    # shouldn't be called a lot.
    def update_data(self, data):
        self.data = data
        # pre-calculate time based on the stamp
        self.queue_draw()

    def set_export_pdf(self, export):
        self.export_pdf = export
                
    def set_export_pdf_filename(self, filename):
        self.export_pdf_filename = filename

    def set_export_png(self, export):
        self.export_png = export
    
    def set_export_png_filename(self, filename):
        self.export_png_filename = filename
    
    # give me a nice color triplet based on the integer and range
    def integer2rgb(self, value, max, multi_factor_local=1):
        x = (value*1.0 / max) * 2 * math.pi
        return self.angle2rgb(x, multi_factor=multi_factor_local)

    def angle2rgb(self, angle, start_color=80, multi_factor=1, scaling=0.8):
#        start_color = 80
#        multi_factor = 1
#        scaling = 0.8
        h = ((angle * 360.0 / (2 * math.pi) * multi_factor)*scaling + start_color) % 360.0
        s = 0.8
        v = 0.8 
        
        h /= 60.0
        i = math.floor(h)
        f = h - i
        p = v * (1 - s)
        q = v * (1 - s*f)
        t = v * (1 - s * (1-f))

        r = 0
        g = 0
        b = 0        
        if i == 0:
            r = v
            g = t
            b = p
        elif i == 1:
            r = q
            g = v
            b = p
        elif i == 2:
            r = p
            g = v
            b = t
        elif i == 3:
            r = p
            g = q
            b = v 
        elif i == 4:
            r = t
            g = p
            b = v
        else:
            r = v
            g = p
            b = q
        return (r, g, b)

class HStackedGraph(Graph):
    _vmargin = 0.35
    _hmargin = 0.1
    
    def __init__(self):
        Graph.__init__(self)

    def generate_random_data(self):
        tempresults = gpfmon.ResultProfile(None)
        value = random.randint(350,500)/10.0
        tempresults.append(gpfmon.DataPointProfile(0, value, 0, "first", ""))
        element_sum = value
        for i in range(5):
            rest = 100 - element_sum
            key = "x" + str(random.randint(1,100000))
            value = random.randint(0,int(rest*10))/10.0            
            tempresults.append(gpfmon.DataPointProfile(0, value, 0, key, ""))
            element_sum += value
        self.data = tempresults.getGraphData(fill=True)

    def update_info_local(self):
        self.rootx = self.hmargin
        self.rooty = self.H - self.vmargin
            
    def draw(self, ctx):
        self.update_info(self.data)
        ctx.set_line_width(1)
        scalex = (self.W - 2*self.hmargin) / 100*1.0	# we cheat because we know the sum is 100

        # shadow
        offset = (self.rooty - self.vmargin)*0.03
        ctx.move_to(self.rootx + offset, self.vmargin + offset)
        ctx.rectangle(self.rootx + offset, self.vmargin + offset, 
                    100*scalex + offset, self.rooty-self.vmargin + offset)
        ctx.set_source_rgb(0.8, 0.8, 0.8)
        ctx.fill()

        # boxes
        currentx = self.rootx
        sum = 0

        for key, value in self.data:
            newx = value * scalex
            ctx.move_to(currentx, self.vmargin)
            ctx.rectangle(currentx, self.vmargin,
                        newx, self.rooty-self.vmargin)
            ctx.set_source_rgb(*self.integer2rgb(sum, 100))
            ctx.fill_preserve()
            ctx.set_source_rgb(0, 0, 0)
            ctx.stroke()
            currentx += newx
            sum += value
            
        # legs and labels
        currentx = self.rootx
        ctx.set_source_rgb(0, 0, 0)
        ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
        i = True
        j = len(self.data)

        for key, value in self.data:
            newx = value * scalex
            ctx.move_to(currentx + newx/2, self.rooty - (self.rooty-self.vmargin)/2)
            if i:
                Y = self.vmargin - j * 10 * (self.H/400.0)
            else:
                Y = self.H - self.vmargin + j * 10 * (self.H/400.0)
            ctx.line_to(currentx + newx/2 + 20, Y)
            text = "%s%%: %s" % (value, key)
            extents = ctx.text_extents(text)
            ctx.rel_line_to(extents[2] + 5, 0)
            ctx.rel_move_to(-extents[2], -5)
            ctx.show_text(text)
            ctx.stroke()
            currentx += newx
            i = not i
            j -= 1
            
        self.show_title(ctx, "Process: %s" % gpfmon.widgets.entPath.get_text(), location = Graph.BOTTOM | Graph.LEFT)

class BarGraph(Graph):
    _vmargin = _hmargin = 0.05
    (BY_VALUE,
    BY_KEY) = range(2)
    
    def __init__(self):
        Graph.__init__(self)
        self.__sort = self.BY_VALUE

    def generate_random_data(self):
        tempresults = gpfmon.ResultProfile(None)
        tempresults.append(gpfmon.DataPointProfile(0, random.randint(0, 100), 0, "first", ""))
        rng = random.randint(10, 15)
        for i in range(rng):
            key = str(random.randint(100000, 1000000))
            value = random.randint(0, 100)
            tempresults.append(gpfmon.DataPointProfile(0, value, 0, key, ""))

#        if self.__sort == self.BY_VALUE:
#            self.data.sort(cmp=DataPoint.cmp, reverse=True)
#        elif self.__sort == self.BY_KEY:
#            self.data.sort(cmp=DataPoint.cmp_by_key)
#        print map(lambda x: x.value, self.data)
        self.data = tempresults.getGraphData(fill=True)
    
    def set_sort_order(type):
        if type == self.BY_VALUE:
            self.__sort = self.BY_BALUE
        elif type == self.BY_KEY:
            self.__sort = self.BY_KEY
        else:
            raise Exception("invalid sort order; I shouldn't be here")
    
    def draw(self, ctx):
        self.update_info(self.data)
        ctx.set_line_width(1)
            
        x = self.rootx
        i = 0
#        for point in self.data:
        for key, value in self.data:
            ctx.rectangle(x, self.rooty - (value * self.info.scaley),
                          self.info.pix_per_sample, value * self.info.scaley)
            ctx.set_source_rgb(*self.integer2rgb(i, self.info.num_samples, 5))
            ctx.fill_preserve()
            ctx.set_source_rgb(0, 0, 0)
            ctx.stroke()
            x += self.info.pix_per_sample
            i += 1

        self.draw_value_labels(ctx, location = Graph.TOP | Graph.XCENTER)
        self.draw_key_labels(ctx, location = Graph.YAUTO | Graph.XCENTER)
        self.draw_axis(ctx)

        self.show_title(ctx, "Process: %s" % gpfmon.widgets.entPath.get_text(), location = Graph.TOP | Graph.XCENTER)
        
    # per class info update (i.e. root coordinates)
    def update_info_local(self):
        self.rootx = self.hmargin*2 + 0.5			# stupid cairo
        self.rooty = self.H - self.vmargin + 0.5
        
class PieGraph(Graph):
    _vmargin = _hmargin = 0.10

    def __init__(self):
        Graph.__init__(self)
#        self.data = gpfmon.DataPointList()

    def generate_random_data(self):
        tempresults = gpfmon.ResultProfile(None)
        value = random.randint(150,300)/10.0
        tempresults.append(gpfmon.DataPointProfile(0, value, 0, "first", ""))
        element_sum = value
        for i in range(7):
            rest = 100 - element_sum
            key = "x" + str(random.randint(1,100000))
            value = random.randint(0,int(rest*7))/10.0            
            tempresults.append(gpfmon.DataPointProfile(0, value, 0, key, ""))
            element_sum += value
#        self.data.append(DataPoint("last", 100-element_sum))	# other
#        self.data.sort(cmp=DataPoint.cmp, reverse=True)
#        print map(lambda x: x.value, self.data)
        
        self.data = tempresults.getGraphData(fill=True)
        
    def update_info_local(self):
        self.rootx = self.W/2 + 0.5		# stupid cairo
        self.rooty = self.H/2 + 0.5		# root in this case is the center
        self.R = (self.H - 3 * self.vmargin)/2

    def draw(self, ctx):
        self.update_info(self.data)
#        angles = map(lambda x: x.value/100.0*math.pi*2, self.data)
#        angles = map(lambda (key, value): value/100.0*math.pi*2, self.data)
        angles = map(lambda value: value/100.0*math.pi*2, self.data.values)

        # shadow
        ctx.move_to(self.rootx, self.rooty)
        ctx.arc(self.rootx+self.R*0.04, self.rooty+self.R*0.04, self.R, 0, 2*math.pi)
        ctx.set_source_rgb(0.8, 0.8, 0.8)
        ctx.fill()
        
        # angle borders and fills
        current_pos = 0
        ctx.set_line_width(1)
        for a in angles:
            ctx.move_to(self.rootx, self.rooty)
            ctx.arc(self.rootx, self.rooty, self.R, current_pos, current_pos + a)
            rgb = self.angle2rgb(current_pos)
            ctx.set_source_rgb(*rgb)
            ctx.fill_preserve()
            ctx.set_source_rgb(0.2, 0.2, 0.2)
            ctx.stroke()
            current_pos += a

        # ubercircle
        ctx.arc(self.rootx, self.rooty, self.R/3, 0, 2*math.pi)
        ctx.set_line_width(2)
        ctx.set_source_rgb(1, 1, 1)
        ctx.fill_preserve()
        ctx.set_source_rgb(0, 0, 0)
        ctx.stroke()

        # circle border
        ctx.arc(self.rootx, self.rooty, self.R, 0, 2*math.pi)
        ctx.set_line_width(2)
        ctx.set_source_rgb(0, 0, 0)
        ctx.stroke()

        # legs
        alternative_layout = False
        if gpfmon.widgets.chkAlternativeLayout.get_active():
            alternative_layout = True

        # 1. count the labels on each side, so the spread can be calculated
        ltop_items = 0  # count the number of q3 items, because their order
                        # will have to be reversed to avoid crossing legs
        if alternative_layout == True:
            lside = rside = 0
            current_pos = 0
            for a in angles:
                if (current_pos+a/2) <= math.pi*2*0.25 or (current_pos+a/2) >= math.pi * 2 * 0.75:
                    rside += 1
                else:
                    lside += 1
                    if (current_pos + a/2) >= math.pi*2*0.5:
                        ltop_items += 1
                current_pos += a
            
            loffset = self.H / (lside + 1)
            roffset = self.H / (rside + 1)
            
            # left bottom y, left top y, etc
            rty = 0
            lty = ltop_items*loffset
            lby = rby = self.H

        # 2. draw
        current_pos = 0
        ctx.set_line_width(1)
        i = 0
        for a in angles:
            ctx.move_to(self.rootx + math.cos(current_pos+a/2)*self.R*0.7, 
                        self.rooty + math.sin(current_pos+a/2)*self.R*0.7)
            if alternative_layout == False:
                ctx.arc(self.rootx, self.rooty, self.R*1.2, current_pos+a/2, current_pos+a/2)
                if (current_pos+a/2) <= math.pi*2*0.25 or (current_pos+a/2) >= math.pi * 2 * 0.75:
                    # right side
                    side = 1
                else:
                    # left side
                    side = -1
            else:
                # BAD CODING. yes, I know. it's late
                if (current_pos+a/2) <= math.pi*2*0.25 or (current_pos+a/2) >= math.pi * 2 * 0.75:
                    # right side
                    side = 1
                    if (current_pos+a/2) <= math.pi*2*0.25:
                        rby -= roffset
                        ctx.line_to(self.rootx + self.R*1.2, rby)
                    else:
                        rty += roffset
                        ctx.line_to(self.rootx + self.R*1.2, rty)
                else:
                    # left side
                    side = -1
                    if (current_pos+a/2) <= math.pi*2*0.5:
                        lby -= loffset
                        ctx.line_to(self.rootx - self.R*1.2, lby)
                    else:
                        ctx.line_to(self.rootx - self.R*1.2, lty)
                        lty -= loffset

            ctx.rel_line_to(20 * side, 0)

            # leg label %
            large_font_size = 14
            normal_font_size = 12
            ctx.select_font_face("Sans", 0, 1)
            ctx.set_font_size(self.get_font(Graph.FONT_LARGE))
            x,y = ctx.get_current_point()
            txt = str(self.data.values[i]) + "%"
            extents = ctx.text_extents(txt)
            if side == -1:
                ctx.rel_move_to(-(extents[2]+10), self.get_font(Graph.FONT_LARGE)/2)
            else:
                ctx.rel_move_to(10, self.get_font(Graph.FONT_LARGE)/2)
            ctx.show_text(str(self.data.values[i]) + "%")
            
            # leg label key
            ctx.move_to(x,y)
            ctx.select_font_face("Sans", 0, 0)
            ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
            txt = str(self.data.keys[i])
            extents = ctx.text_extents(txt)
            if side == -1:
                ctx.rel_move_to(-(extents[2]+10), self.get_font(Graph.FONT_LARGE)*1.5)
            else:
                ctx.rel_move_to(10, self.get_font(Graph.FONT_LARGE)*1.5)
            ctx.show_text(txt)
            ctx.stroke()
            current_pos += a
            i += 1

        if alternative_layout == False:
            loc = Graph.BOTTOM | Graph.LEFT
        else:
            loc = Graph.BOTTOM | Graph.XCENTER
        self.show_title(ctx, "Process: %s" % gpfmon.widgets.entPath.get_text(), location = loc)

class LineGraph(Graph):
    _vmargin = 0.1
    _hmargin = 0.1
        
    def __init__(self):
        Graph.__init__(self)
        self.data = gpfmon.DataPointList()
        self.log_scale = False

    def generate_random_data(self):
        tempresults = gpfmon.ResultSampling(None)
        tempresults.value_labels = ["Dummy data label 1", "Some other dummy data label"]
        tempresults.append(gpfmon.DataPointSampling([0, 0], 0, ""))
        tstamp = 0
        for i in range(20):
            tstamp += 0.01*random.randint(1,9)            
            tempresults.append(gpfmon.DataPointSampling( 
                values=[tempresults[-1].values[0] + random.randint(-100, 200), tempresults[-1].values[1] + random.randint(-10, 20)], 
                timestamp=tstamp,
                raw=""))

        self.data = tempresults.getGraphData()
        
    def update_time(self):
        self.data.update_time()
        self.queue_draw()
        
    def update_info_local(self):
        self.rootx = self.hmargin
        self.rooty = self.H - self.vmargin
        self.log_scale = gpfmon.widgets.chkLog.get_active()
        
    def draw(self, context):
        self.update_info(self.data)

        # X Grid
        for i in range(1, self.info.num_ticks_x):
            context.move_to(self.rootx + i*self.info.pix_per_tick_x, self.vmargin)
            context.line_to(self.rootx + i*self.info.pix_per_tick_x, self.rooty)
        context.set_line_width(1)
        context.set_dash([2, 5], 1)
        context.set_source_rgb(0.4, 0.4, 0.8)
        context.stroke()

        if not self.log_scale:
            # the line
            for j in range(self.data.parent.values_per_point):
                context.move_to(self.rootx, self.rooty)
                i = 0
                for element in self.data:
                    context.line_to(self.rootx+self.data.timestamps[i]*self.infos[j].scalex, self.rooty - element.values[j]*self.infos[j].scaley)
                    i += 1
                context.set_line_width(2)
                context.set_dash([])
                context.set_source_rgb(*self.get_color(j))
                context.stroke()
            
            # Y-axis grid
            i = 0
            for i in range(1, self.info.num_ticks_y):
                context.move_to(self.rootx, self.rooty - i*self.info.pix_per_tick_y)
                context.line_to(self.W - self.hmargin, self.rooty - i*self.info.pix_per_tick_y)
            context.set_line_width(1)
            context.set_dash([2, 5], 1)
            context.set_source_rgb(0.4, 0.8, 0.4)
            context.stroke()

        else:
            # Y-log grid
    #        maxval = max([ x.values[0] for x in self.data ])
            rng = int(math.ceil(math.log10(self.info.maxval)))
    #        print rng
            ppt = (self.H - 2*self.vmargin)/rng
    #        print ppt
            for i in range(1, rng+1):
                context.move_to(self.rootx, self.rooty - i*ppt)
                context.line_to(self.W - self.hmargin, self.rooty - i*ppt)
                context.set_line_width(1)
                context.set_dash([2, 5], 1)
                context.set_source_rgb(0.8, 0.2, 0.2)
                context.stroke()

                for j in range(2, 10):
                    pw = math.pow(10, i-1)
                    context.move_to(self.rootx, self.rooty - math.log10(pw*j)*ppt)
                    context.line_to(self.W - self.hmargin, self.rooty - math.log10(pw*j)*ppt)
                context.set_line_width(1)
                context.set_dash([1, 3], 1)
                context.set_source_rgb(0.8, 0.4, 0.4)
                context.stroke()

            # Y log line
            for j in range(self.data.parent.values_per_point):
                context.move_to(self.rootx, self.rooty)
                i = 0
                for element in self.data:
                    context.line_to(self.rootx+self.data.timestamps[i]*self.infos[j].scalex, self.rooty - math.log10(element.values[j]+1)*ppt)
                    i += 1
                context.set_line_width(2)
                context.set_dash([])
                context.set_source_rgb(*self.get_color(j))
                context.stroke()

        self.show_title(context, "Process: %s" % gpfmon.widgets.entPath.get_text(), location = Graph.TOP | Graph.XCENTER)
        self.draw_axis(context)
        self.draw_legend(context)
        
    def draw_legend(self, ctx):
        ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
        ctx.set_line_width(1)
        ctx.set_source_rgb(0, 0, 0)

        # get text extensions for all labels to find the longest
        exttable = []
        num_items = self.data.parent.values_per_point
        for i in range(num_items):
            exttable.append(ctx.text_extents(self.data.parent.value_labels[i]))
        maxwidth = max([x[2] for x in exttable])

        # add margins on the left and right
        width = maxwidth + 2*10
        
        # label height
        height = exttable[0][3] * 2
        
        # the box
        ctx.rectangle(self.W - width - 10, 10, width, height*(num_items+0.5))
        ctx.set_source_rgb(0.95, 0.95, 0.95)
        ctx.fill_preserve()
        ctx.set_source_rgb(0, 0, 0)
        ctx.stroke()
        
        # add labels
        for j in range(num_items):
            ctx.move_to(self.W - width, height*(j+1) + 10)
            ctx.set_source_rgb(*self.get_color(j))
            ctx.show_text(self.data.parent.value_labels[j])
            ctx.stroke()

    # NOTE: this is a duplicated version of draw_axis
    def draw_axis(self, ctx):
        independent = not gpfmon.widgets.chkAlternativeLayout.get_active()
        
#        ctx.set_font_size(self.get_font(Graph.FONT_SMALL))
        ctx.set_dash([])
        ctx.set_line_width(1)
        ctx.set_source_rgb(0, 0, 0)
        
        # X axis
        ctx.move_to(self.rootx, self.rooty)
        ctx.line_to(self.W - self.hmargin, self.rooty)
        ctx.stroke()
        
        # X label
        ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
        text = self.data.timelabel
        extents = ctx.text_extents(text)
#        ctx.move_to(self.W/2 - extents[2]/2, self.H - (self.H - self.rooty)/3)
        # behold the power of mindless optimization!
        ctx.move_to((self.W - extents[2])/2, (self.H*2 + self.rooty)/3+10)
        ctx.show_text(text)
        ctx.set_font_size(self.get_font(Graph.FONT_SMALL))

        # X ticks
        ctx.move_to(self.rootx, self.rooty)
        for i in range(self.infos[0].num_ticks_x + 1):
            ctx.move_to(self.rootx + i*self.infos[0].pix_per_tick_x, self.rooty)
            ctx.rel_line_to(0, 5)
        ctx.stroke()
        
        # X labels
        for i in range(self.infos[0].num_ticks_x + 1):
            label = str(self.infos[0].val_per_tick_x * i)
            extents = ctx.text_extents(label)
            ctx.move_to(self.rootx - extents[2]/2 + i*self.infos[0].pix_per_tick_x,
                        self.rooty - extents[1] + 10)
            ctx.show_text(label)
        ctx.stroke()

        # Y axis
        ctx.move_to(self.rootx, self.rooty)
        ctx.line_to(self.rootx, self.vmargin)
        ctx.set_source_rgb(*self.get_color(0))
        ctx.stroke()

        # Y axis label
        ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
        txt = self.data.parent.value_labels[0]
        extents = ctx.text_extents(txt)
        ctx.move_to(self.hmargin/3, (self.H + extents[2]) / 2)
        ctx.rotate(-0.5*math.pi)
        ctx.show_text(self.data.parent.value_labels[0])
        ctx.rotate(0.5*math.pi)
        ctx.set_font_size(self.get_font(Graph.FONT_SMALL))
        ctx.set_source_rgb(0, 0, 0)

        if not self.log_scale:
            # Y ticks
            ctx.move_to(self.rootx, self.rooty)
            for i in range(self.infos[0].num_ticks_y + 1):
                ctx.move_to(self.rootx, self.rooty - i*self.infos[0].pix_per_tick_y)
                ctx.rel_line_to(-5, 0)
            ctx.stroke()

            # Y labels
            for i in range(self.infos[0].num_ticks_y + 1):
                label = self.infos[0].val_per_tick_y * i

                # make the labels a bit more readable... puny humans, can't read zeroes
                if label >= 1000000:
                    txt = str(label / 1000000.0) + " M"
                elif label >= 1000:
                    txt = str(int(label))
                    txt = txt[:-3] + "'" + txt[-3:]
                else:
                    txt = str(label)
                
                # draw'em!
                extents = ctx.text_extents(txt)
                ctx.move_to(self.rootx - extents[2] - 10,
                            self.rooty - i*self.infos[0].pix_per_tick_y - extents[1]/2)
                ctx.show_text(txt)
            ctx.stroke()
        else:
            # Y log ticks
            rng = int(math.ceil(math.log10(self.info.maxval)))
            ppt = (self.H - 2*self.vmargin)/rng
            for i in range(1, rng+1):
                ctx.move_to(self.rootx, self.rooty - i*ppt)
                ctx.rel_line_to(-5, 0)
            ctx.stroke()

            for i in range(1, rng+1):
                label = math.pow(10, i)
                if label >= 1000000:
                    txt = str(label / 1000000.0) + " M"
                elif label >= 1000:
                    txt = str(int(label))
                    txt = txt[:-3] + "'" + txt[-3:]
                else:
                    txt = str(label)

                extents = ctx.text_extents(txt)
                ctx.move_to(self.rootx - extents[2] - 10,
                            self.rooty - i*ppt - extents[1]/2)
                ctx.show_text(txt)
            ctx.stroke()
                        

        # additional axis
        if self.data.parent.values_per_point == 2 and independent and not self.log_scale:
            # secondary Y axis
            ctx.move_to(self.W - self.hmargin, self.rooty)
            ctx.line_to(self.W - self.hmargin, self.vmargin)
            ctx.set_source_rgb(*self.get_color(1))
            ctx.stroke()
            
            # secondary Y axis label (oh the pain)
            ctx.set_font_size(self.get_font(Graph.FONT_MEDIUM))
            txt = self.data.parent.value_labels[1]
            extents = ctx.text_extents(txt)
            ctx.move_to(self.W - self.hmargin/3, (self.H + extents[2]) / 2)
            ctx.rotate(-0.5*math.pi)
            ctx.show_text(self.data.parent.value_labels[1])
            ctx.rotate(0.5*math.pi)
            ctx.set_font_size(self.get_font(Graph.FONT_SMALL))
            ctx.set_source_rgb(0, 0, 0)

            basex = self.W - self.hmargin
            # secondary Y ticks
            ctx.move_to(basex, self.rooty)
            for i in range(self.infos[1].num_ticks_y + 1):
                ctx.move_to(basex, self.rooty - i*self.infos[1].pix_per_tick_y)
                ctx.rel_line_to(5, 0)
            ctx.stroke()
        
            # Y labels
            for i in range(self.infos[1].num_ticks_y + 1):
                label = self.infos[1].val_per_tick_y * i

                # make the labels a bit more readable... puny humans, can't read zeroes
                if label >= 1000000:
                    txt = str(label / 1000000.0) + " M"
                elif label >= 1000:
                    txt = str(int(label))
                    txt = txt[:-3] + "'" + txt[-3:]
                else:
                    txt = str(label)
                
                # draw'em!
                extents = ctx.text_extents(txt)
                ctx.move_to(basex + 10,
                            self.rooty - i*self.infos[1].pix_per_tick_y - extents[1]/2)
                ctx.show_text(txt)
            ctx.stroke()
