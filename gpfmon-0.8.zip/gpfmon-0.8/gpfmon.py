#!/usr/bin/env python

import os, sys, pygtk, gtk, gtk.glade, gobject, gpfmon, sets, pango, pickle

gtk.gdk.threads_init()

class Empty:
    pass

class Current:
    def __init__(self):
        self.project = gpfmon.GPFMProject()
        self.run = None

        # TODO: this should be initialized to "None"
        self.arch = gpfmon.ARCH_X86_64
        self.hostname = "localhost"
        self.username = "?"
        
        self.options_filename = None
        self.pipe = None

class Globalvars:
    def __init__(self):
        self.available_counters = []		# histogram for available counters
        self.used_counters = sets.Set([])	# set of used counters
        self.events = []			# all events
        self.selected_events = []		# container w/ events selected
        self.sshconnection = gpfmon.SSHConnection2()
        self.remote = self.sshconnection.connected
        self.all_signal_handlers = {}
        self.mode = gpfmon.MODE_NORMAL		# monitoring mode
        self.time = gpfmon.TIME_R_SEC
        self.graph = None			# current graph
        self.sshopts = None			# ssh options
        self.config = Empty()
        
        self.autoscroll = True		# automatic scrolling in the output window
                                        # TODO: remove this from the global vars
        self.derived_events = None	# a DerivedEvents class instance holding
                                        # all derived events read from XML
        self.current = Current()
        self.preferences = None
        
gpfmon.globalvars = Globalvars()
globalvars = gpfmon.globalvars

# disable system password prompt
os.putenv("SSH_ASKPASS", "")

gladefile = "gpfmon_interface.glade"
widgets = gtk.glade.XML(gladefile)
wndMain = widgets.get_widget("wndMain")

# create a list store and point the treeview to it
# columns are as follows:
#	- event name (visible)
#	- monitor it? (visible)
#	- event object
#	- filtering aid - bool column
#	- ?

lstore = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_BOOLEAN, gobject.TYPE_PYOBJECT, gobject.TYPE_BOOLEAN)
tv = widgets.get_widget("lstEvents")
lstore_filter = lstore.filter_new()
lstore_filter.set_visible_column(3)
lstore_sort = gtk.TreeModelSort(lstore_filter)
tv.set_model(lstore_sort)

# setup event list
event_column = gtk.TreeViewColumn('Event name', gtk.CellRendererText(), text=0)
event_column.set_sort_column_id(0)
renderer = gtk.CellRendererToggle()
signal_handlers = gpfmon.SignalHandlers()
renderer.connect('toggled', signal_handlers.lstEvents_toggled, lstore)
monitor_column = gtk.TreeViewColumn('Monitor', renderer, active=1)
monitor_column.set_cell_data_func(renderer, signal_handlers.lstEvents_cell_data_func)
tv.append_column(monitor_column)
tv.append_column(event_column)

# patch up
wndMain.connect("destroy", signal_handlers.xQuit)

# instantiate signal handlers (split for convenience)
gpfmon.globalvars.all_signal_handlers["wndMain"] = signal_handlers
gpfmon.globalvars.all_signal_handlers["dlgSSH"] = gpfmon.DlgSSHSignalHandlers()
gpfmon.globalvars.all_signal_handlers["dlgTasklist"] = gpfmon.DlgTasklistSignalHandlers()
gpfmon.globalvars.all_signal_handlers["dlgUmasks"] = gpfmon.DlgUmasksSignalHandlers()
gpfmon.globalvars.all_signal_handlers["dlgAbort"] = gpfmon.DlgAbortSignalHandlers()
gpfmon.globalvars.all_signal_handlers["dlgPreferences"] = gpfmon.DlgPreferencesSignalHandlers()

# autoconnect signals
widgets.signal_autoconnect(gpfmon.globalvars.all_signal_handlers["wndMain"])
widgets.signal_autoconnect(gpfmon.globalvars.all_signal_handlers["dlgSSH"])
widgets.signal_autoconnect(gpfmon.globalvars.all_signal_handlers["dlgTasklist"])
widgets.signal_autoconnect(gpfmon.globalvars.all_signal_handlers["dlgUmasks"])
widgets.signal_autoconnect(gpfmon.globalvars.all_signal_handlers["dlgAbort"])
widgets.signal_autoconnect(gpfmon.globalvars.all_signal_handlers["dlgPreferences"])

# import widget names into local scope
for w in widgets.get_widget_prefix(''):
    name = w.get_name()
    assert not hasattr(widgets, name)
    setattr(widgets, name, w)
gpfmon.widgets = widgets

gpfmon.config_setup(gpfmon.globalvars.config)

# setup derived event treeview
exp_column = gtk.TreeViewColumn("Derived Event", gtk.CellRendererText(), text=0)
gpfmon.widgets.tvDerivedEvents.append_column(exp_column)
derived_event_model = gtk.TreeStore(gobject.TYPE_STRING, gobject.TYPE_INT)
derived_events = gpfmon.globalvars.derived_events
for category in derived_events.categories:
    parent = derived_event_model.append(None, [category, -1])
    for derived_event in derived_events.getElementsByCategory(category):
        derived_event_model.append(parent, [derived_event.name, derived_event.index])
# TODO: uncomment later when this is moved to a different function
#        if derived_event.formulas.has_key(gpfmon.globalvars.current.arch):
#            derived_event_model.append(parent, [derived_event.name, derived_event.index])
gpfmon.widgets.tvDerivedEvents.set_model(derived_event_model)
 

# setup privlevel combo box (the second column is redundant for now)
pmodel = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_STRING)
pmodel.append(["User level (3, default)", "3"])
pmodel.append(["Level 2", "2"])
pmodel.append(["Level 1", "1"])
pmodel.append(["Kernel level (0)", "0"])
widgets.cmbPrivLevel.set_model(pmodel)
prenderer = gtk.CellRendererText()
widgets.cmbPrivLevel.pack_start(prenderer, True)
widgets.cmbPrivLevel.add_attribute(prenderer, 'text', 0)
widgets.cmbPrivLevel.set_active(0)

# setup timeformat combo box (the second column has the time enum)
tmodel = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_INT)
tmodel.append(["Relative time (hh:mm:ss.fff)", gpfmon.TIME_R_HMSF])
tmodel.append(["Relative time (mm:ss.fff)", gpfmon.TIME_R_MSF])
tmodel.append(["Relative time (mm:ss)", gpfmon.TIME_R_MS])
tmodel.append(["Relative time (seconds)", gpfmon.TIME_R_SEC])
tmodel.append(["Relative time (milliseconds)", gpfmon.TIME_R_MSEC])
tmodel.append(["Reference event hits", gpfmon.TIME_E_HITS])
#tmodel.append(["Absolute time (hh:mm:ss)", gpfmon.globalvars.TIME_A_HMS])
#tmodel.append(["Absolute time (UNIX seconds)", gpfmon.globalvars.TIME_A_UNIX])
widgets.cmbTimeFormat.set_model(tmodel)
trenderer = gtk.CellRendererText()
widgets.cmbTimeFormat.pack_start(trenderer, True)
widgets.cmbTimeFormat.add_attribute(trenderer, 'text', 0)
widgets.cmbTimeFormat.set_active(3)

# setup filter combo box; one field for the text, second for the regex
model = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_STRING)
model.append(["All", ".+"])
try: # pygtk 2.6+
    widgets.cmbEventFilter.set_row_separator_func(lambda x, y: x.get_value(y, 0) == "-")
    model.append(["-", ".+"])
except:
    pass
model.append(["Bus events", "BUS_.+"])
model.append(["L1 events", "L1.+"])
model.append(["L2 events", "L2.+"])
model.append(["L3 events", "L3.+"])
model.append(["Branch related events", "BR_.+"])
model.append(["Floating point related events", "FP_.+"])
model.append(["SIMD related events", "SIMD_.+"])
model.append(["Thread related events", "THREAD_.+"])
model.append(["SI_*", "SI_.+"])
model.append(["FE_*", "FE_.+"])
model.append(["BE_*", "BE_.+"])
widgets.cmbEventFilter.set_model(model)
renderer = gtk.CellRendererText()
widgets.cmbEventFilter.pack_start(renderer, True)
widgets.cmbEventFilter.add_attribute(renderer, 'text', 0)
widgets.cmbEventFilter.set_active(0)
# manually connect it since we the model.append calls earlier would emit a changed signal
widgets.cmbEventFilter.connect("changed", gpfmon.globalvars.all_signal_handlers["wndMain"].cmbEventFilter_changed)

# setup ssh profile combo box; this is getting really annoying
smodel = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_INT)

i = 0
smodel.append(["Blank", -1])	# an empty profile always exists
for element in gpfmon.globalvars.sshopts:
    smodel.append([element.description, i])
    i += 1
widgets.cmbSSHProfile.set_model(smodel)
srenderer = gtk.CellRendererText()
widgets.cmbSSHProfile.pack_start(srenderer, True)
widgets.cmbSSHProfile.add_attribute(srenderer, 'text', 0)
widgets.cmbSSHProfile.set_active(0)
widgets.cmbSSHProfile.connect("changed", gpfmon.globalvars.all_signal_handlers["dlgSSH"].cmbSSHProfile_changed)

# initialize the reference event combo box (for sampling)... GRRRRRR ENOUGH
rmodel = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_PYOBJECT)
rmodel.append(["None", None])
rmodel.append(["-", None])
widgets.cmbSmplReferenceEvent.set_row_separator_func(lambda x, y: x.get_value(y, 0) == "-")
widgets.cmbSmplReferenceEvent.set_model(rmodel)
rrenderer = gtk.CellRendererText()
widgets.cmbSmplReferenceEvent.pack_start(rrenderer, True)
widgets.cmbSmplReferenceEvent.add_attribute(rrenderer, 'text', 0)
widgets.cmbSmplReferenceEvent.set_active(0)

# initialize output text box
gpfmon.widgets.txtOutput.modify_base(gtk.STATE_NORMAL, gtk.gdk.Color(0, 0, 0))
widgets.txtOutput.modify_text(gtk.STATE_NORMAL, gtk.gdk.Color(65535, 65535, 65535))
widgets.txtOutput.modify_font(pango.FontDescription("Luxi Mono 10"))
buffer = gtk.TextBuffer()
buffer.create_tag("result", weight=pango.WEIGHT_BOLD, foreground="#aa3333")
buffer.create_tag("info", weight=pango.WEIGHT_BOLD, foreground="#aa8833")
buffer.create_mark("ye_end", buffer.get_end_iter(), False)
widgets.txtOutput.set_buffer(buffer)

# initialize graph area
gpfmon.globalvars.graph = gpfmon.PieGraph()
gpfmon.globalvars.graph.set_property("visible", True)
widgets.scrGraphs.add_with_viewport(gpfmon.globalvars.graph)

#gpfmon.widgets.vbxNotifications.pack_start(gpfmon.NotificationMessage("this is a <b>test</b>"), expand=False)
#gpfmon.showNotification("<b>INFO:</b> I'm an irritating information bar!")
#gpfmon.showNotification("Welcome warning!", type="warn")
#gpfmon.showNotification("<b>INFO:</b> I'm an irritating error bar!", type="error")

#gpfmon.globalvars.data2 = gpfmon.generate_dummy_sampling_data()
##gpfmon.globalvars.graph.update_data(gpfmon.globalvars.data2)
#d = gpfmon.ArithmeticProcessingPlant.calculate(scenarios[0].formulas[gpfmon.globalvars.current_arch])
#print d.value_labels
#print "d: ", d
#gpfmon.globalvars.data2 = d
#gpfmon.globalvars.graph.update_data(d)

#p = gpfmon.GPFMProject()
#p.save()
#p = gpfmon.GPFMProject.open("gpfmontestsav.dat")
#print p.__class__
#print p

gpfmon.globalvars.preferences = gpfmon.Preferences.load_from_file()

if gpfmon.globalvars.preferences.auto_save:
    gpfmon.load_options(auto=True)

# startup
gpfmon.refresh_event_list()
wndMain.show()
gpfmon.widgets.wndSplash.show()
gobject.timeout_add(2000, gpfmon.widgets.wndSplash.hide)
dlg = gtk.MessageDialog(gpfmon.widgets.wndMain, gtk.DIALOG_MODAL, gtk.MESSAGE_WARNING, gtk.BUTTONS_OK,
"This software is not at its final version. Not everything works: if \
you start getting strange results, restarting the application will usually help. \
If not, feel free to tell me about any reproducible bugs you might find.\n\n\
Andrzej Nowak")
#dlg.run()
#dlg.destroy()
gtk.main()
